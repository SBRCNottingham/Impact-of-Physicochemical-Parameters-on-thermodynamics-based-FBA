%
% Created by Thomas Millat, University of Nottingham
% Email: thomas.millat@nottingham.ac.uk

% CONSTANTS defines some physical constants and conversion factors
% according to the 2014 set recommend by the Committee on Data for Science
% and Technology (CODATA)
%
%   doi: 10.5281/zenodo.22826 

% physical constants in SI units
classdef phc
    properties (Constant)
        clight=2.99792458e8;                % speed of light [m s-1]
        mu0=(4e-7)*pi;                      % vacuum permeability 
                                            % (magnetic constant) [N A-2]
        eps0=1/((4e-7)*pi*(2.99792458e8)^2);% vacuum permittivity [F m-1]
        atommass=1.660539040e-27;           % atomic mass unit [kg]
        faraday=9.64853365e4;               % Farady constant [C mol-1]
        avogadro=6.022140857e23;            % Avogadro constant [mol-1]
        boltzmann=1.38064852e-23;           % Boltzmann constant [J K-1]
        stefanboltzmann=5.670367e-8;        % Stefan-Boltzmann constant 
                                            % [W m-2 K-4]
        gasc=8.3144598;                     % molar gas constant
                                            % [J mol-1 K-1]
        echarge=1.6021766208e-19;           % elementary charge (e) [C]
        magfq=2.067833831e-15;              % magnetic flux quantum [Wb]
        condq=7.7480917310e-5;              % conductance quantum [S]
        planckc=6.626070040e-34;            % Planck constant [J s]
        planckq=6.626070040e-34/(2*pi);     % h/2pi [J s]
        emass=9.10938356e-31;               % electron mass [kg]
        pmass=1.672621898e-27;              % proton mass [kg]
        epmass=1836.15267389;               % proton-electron mass ratio
        fsc=7.2973525664e-3;                % fine-structure constant
        ifsc=137.035999139;                 % inverse fine-structure const.
        gaccel=9.80665;                     % standard acceleration of 
                                            % free fall [m s-2]
        gravc=6.67408e-11;                  % gravitational constant 
                                            % [m3 kg-1 s-2]
        rydberg=10973731.568508;            % Rydberg constant [m-1]
        T0=-273.15;                         % absolute zero temperature [�C]
        eV=1.602176208e-19;                 % electron volt [J]
        molvol=22.413962e-3;                % molar volume of ideal gas
                                            % under standard conditions
                                            % [m3 mol-1]
   end
end