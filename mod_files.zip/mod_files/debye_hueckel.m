function A=debye_hueckel(t,S)
%
% Created by Thomas Millat, University of Nottingham
% Email: thomas.millat@nottingham.ac.uk

% DEBYE-HUECKEL computes the prefactor A for the Debye-Hueckel limiting law
% and its extended version, respectively, assuming an aquaeous medium. The
% activity coefficient is defined in the limiting law as:
%
%       ln gamma = - z^2 A I^1/2 (ln natural logarithm (log in Matlab)
%
% Note that other application might use the definition
%       log10 gamma = - z^2 A10 I^1/2
% where the Debye-Hueckel constant is caluclated as A/ln 10.
%
% The function considers the following factors influencing the prefactor
%
%   1. Temperature (direct effect and indirect effect on density and permittivity)
%   2. density (direct effect)
%   3. permittivity (direct effect)
%   4. salinity (indirect effect on permittivity)
%
% The function calculates the matrix A(t,S)

% Check Number of Input Arguments
% switch nargin
%     case 0
%         t=25; % temperature Celsius
%         S=0;
%         warning('debye_hueckel:argChk','Assuming t=25 and S=0');
%     case 1
%         S=0;
%         warning('debye_hueckel:argChk','Assuming S=0');
%     case 2
%         % all input arguments provided
%     otherwise
%         error('debye_hueckel:argChk','Too many arguments');
% end

% Modified matTFA (Salvy et al. 2018) by Claudio Tomi-Andrino (2019)

% Check arguments
size_t=size(t);
size_S=size(S);
if min(size_t)*min(size_S)>1
    error('debye_hueckel:argChk','Arguments must be vectors');
end
if size_t(2)>1
    t=transpose(t);
end
if size_S(1)>1
    S=transpose(S);
end

% load physical constants
import phc.*

% prefactor
pf=phc.faraday^3/(4*pi*phc.eps0*phc.avogadro)/sqrt(2*phc.eps0*phc.gasc^3);
% density-, temperature-, and salinity-dependent part
t1=t(:,ones(1,length(S)));
A=pf*sqrt(density_sw(t,S)./(permittivityH2OS(t,S).*(t1-phc.T0)).^3);
