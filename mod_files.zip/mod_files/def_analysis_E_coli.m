clc
clear
clear global
restoredefaultpath

%% Modified matTFA (from matTFA, Salvy et al. 2018) by Claudio Tomi-Andrino (2020)


%% Add experimental data
% Experimental data from Ishii et al. 2007
uptake_glucose_exp = 2.93;  % mmol/gDCW-h
growth_rate_exp = 0.2;      % h-1
MW_glucose = 180;           % g/mol
yield_exp = (growth_rate_exp/uptake_glucose_exp)*(1000/MW_glucose); % g DCW/g glucose consumed

% the theoretical biomass yield can also be calculated
Y_X_ATP = 10.3;              % g DCW/mol ATP (Neidhart 1996, Shuler 2002) for aerobic fermentations
ATP_Glucose = 2/MW_glucose;  % moles of ATP per mol of glucose (expressed in gram units)
yield_theoret = Y_X_ATP * ATP_Glucose;       % g DCW/g glucose consumed

% metabolomics: this information will be used as both constraints (in some
% cases) and to compare the predictive capacity (in all cases). Thus, we
% store them here and call them when necessary
metNames_exp = {'succoa_c', 'trp-L_c', 'dctp_c', 'fdp_c', 'fad_c', 'met-L_c', 'ile-L_c', 'tyr-L_c', 'datp_c', 'f6p_c', 'phe-L_c', 'arg-L_c', 'g1p_c', 'his-L_c', 'nadp_c', 'pro-L_c', 'asn-L_c', 'leu-L_c', 'pep_c', 'dhap_c', 'pyr_c', 'amet_c', 'thr-L_c', 'malcoa_c', 'accoa_c', 'val-L_c', 's7p_c', 'pydx5p_c', 'ctp_c', 'nadph_c', 'gly_c', 'ser-L_c', 'ala-L_c', 'asp-L_c', 'lys-L_c', '3pg_c', 'adp_c', 'amp_c', 'gtp_c', 'utp_c', 'gln-L_c', 'nad_c', 'atp_c', 'glu-L_c'};
Conc_values_exp = [0.009359543, 0.010731977, 0.025375612, 0.025929355, 0.026680487, 0.031787628, 0.033148308, 0.034456205, 0.040279403, 0.043890575, 0.056293859, 0.056846432, 0.063547658, 0.078509817, 0.087335543, 0.094154326, 0.111930146, 0.113621109, 0.120087663, 0.12623261, 0.128204905, 0.130297951, 0.147806892, 0.158776506, 0.192901247, 0.200709788, 0.221586771, 0.243517494, 0.259172413, 0.267429669, 0.289555417, 0.308649675, 0.320280616, 0.328512449, 0.334719094, 0.506263157, 0.56225118, 0.570592568, 0.627229356, 0.635722343, 0.641449567, 0.72017617, 1.232156107, 3.47369374]; % metabolite concentration values (mmol)
C_exp = Conc_values_exp./1000; % so we convert from mM to M

% fluxomics (considering there are lumped reactions defined in the inverse
% direction in the GSM; thus, there are repeated flux values with different
% sign)
fluxes_ishii = ['AcCoA -> Ethanol', 'CIT -> ICT', 'CIT -> ICT', 'AcCoA -> Acetate', '2-KG -> SUC + CO2', 'AcCoA -> Ethanol', 'AcCoA + OAA -> CIT', '6-PG -> G3P + PYR', '6-PG -> G3P + PYR', '3PG <-> PEP', 'F1,6P -> DHAP + G3P', 'FUM -> MAL', 'G6P -> 6PG', 'G3P -> 3PG', 'Glucose + PEP -> G6P + PYR', '6PG -> Ru5P + CO2', 'ICT -> 2-KG + CO2', 'ICT -> Glyoxylate + SUC', 'PYR -> Lactate', 'Glyoxylate + AcCoA -> MAL', 'MAL <-> OAA', 'MAL -> PYR + CO2', 'MAL -> PYR + CO2', 'PYR -> AcCoA + CO2', 'F6P -> F1,6P', 'G6P <-> F6P', 'G3P -> 3PG', 'G6P -> 6PG', '3PG <-> PEP', 'PEP + CO2 <-> OAA', 'AcCoA -> Acetate', 'PEP -> PYR', 'Ru5P -> X5P', 'Ru5P -> R5P', 'SUC -> FUM', '2-KG -> SUC + CO2', 'S7P + G3P <-> E4P + F6P', 'R5P + X5P <-> S7P + G3P', 'X5P + E4P <-> F6P + G3P', 'DHAP -> G3P'];
fluxes_13C = [-0.1, 85.9, 85.9, 0, 62.5, -0.1, 85.9, 0, 0, 161.7, 85.3, 77.5, 20.5, 172, 100, 20.5, 70.9, 15, 0, 15, 89.1, 3.4, 3.4, 129.4, 85.3, 78, -172, 20.5, -161.7, 10.6, 0, 47.3, 8.1, -12.4, 77.5, 62.5, 5.6, 5.6, 2.5, 85.3];

%Assuming I = 0.25M (Henry et al. 2007, Salvy et al. 2018) this value can
% be converted to I [mol/kg] by considering a buoyant density of 1.11 kg/L
% (Baldwin et al. 1995). Then, S can be calculated used the expression for
% seawater (Millero 1972)
I = 0.25*1.11;
S = (1000*I)/(19.92+(1.005*I));
clear I

%% Generation of tests
% preparing a legend matrix so that each column corresponds to a parameter,
% the first row to the lower value (0) and the second row the upper value
% (1)
npar = 6; 
nruns = 2^(npar);

d = (0:nruns-1)';
b = de2bi(d);
d = (1:nruns)'; % adapt it to runs 1 to nruns
full_tests = [d b];

clear b

legend_codex = zeros(2,npar);
legend_codex(:,1) = [25;37]; % temperature (oC)
legend_codex(:,2) = [0;0.25]; % ionic strength (M)
legend_codex(:,3) = [0;S]; % salinity (g/kg)
legend_codex(:,4) = [0;1]; % prefactor A (0 - Alberty, 1 - this study)
legend_codex(:,5) = [0;1]; % equation (0 - extended DH, 1 - Davies)
legend_codex(:,6) = [0;1]; % [metabolites] (0 - unconstrained, 1 - constrained)
legend_codex;

clear S

% obtaining array with all the parameter values
full_parameters = zeros(size(full_tests));
full_parameters(:,1) = full_tests(:,1);

for  run_number = 1:nruns
    for column_number = 1:npar 
         full_parameters(run_number,column_number+1) = legend_codex(full_tests(run_number,column_number+1)+1,column_number);
         % I need to do column_number+1 because matlab cannot use 0 as an
         % index, and those are binary values
    end 
end

clear column_number

% extract vectors from full_parameters so that paremeter 1 is column 2,
% parameter 2 is column 3,(...). No need to extract to the run number, 
% since is the same as the row number. Thus I can later call the value of 
% the parameter at the run I am working with. In the original toolbox some 
% parameters were manually included in each function (e.g. temperature); 
par_temperature = full_parameters(:,2);
par_ionic_strength = full_parameters(:,3);
par_salinity = full_parameters(:,4);
par_method_prefactor_A = full_parameters(:,5);  % this will be used to calculate par_calc_prefactor_A
par_equation = full_parameters(:,6);
par_conc_metabolites = full_parameters(:,7);

% now we calculate pfA values and include it as an extra column
par_calc_prefactor_A = zeros(nruns,1);

for  run_number = 1:nruns
    t = par_temperature(run_number);
    T = t-phc.T0;
    S = par_salinity(run_number);
    
    if par_method_prefactor_A(run_number)==0
        par_calc_prefactor_A(run_number)= 1.10708 - (1.54508e-3)*T + (5.95584e-6)*T^2;
    else
        par_calc_prefactor_A(run_number)= debye_hueckel(t,S);
    end
end  
clear t
clear T
clear S

final_parameters(:,1) = full_parameters(:,1);
final_parameters(:,2) = full_parameters(:,2);
final_parameters(:,3) = full_parameters(:,3);
final_parameters(:,4) = full_parameters(:,4);
final_parameters(:,5) = par_calc_prefactor_A; % substitute par_method_prefactor_A with calculated par_calc_prefactor_A
final_parameters(:,6) = full_parameters(:,6);
final_parameters(:,7) = full_parameters(:,7);

% prepare arrays to save results. Since strings cannot be stored in matrices, 
% I will operate with everything and export it altogether at the end 
biomass_flux_yield = zeros(nruns,7);
yield_values = zeros(nruns,5);
yield_deviation = zeros(nruns,4);
comparison_fluxes_13C_FBA = zeros(nruns, 2);
comparison_fluxes_13C_TFA = zeros(nruns, 2);
comparison_fluxes_FBA_TFA = zeros(nruns, 2);
comparison_fluxes_total = zeros(nruns, 4);
failed_run_track = zeros(nruns,2);

biomass_flux_yield(:,1) = d; 
yield_values = d;
yield_deviation = d;
comparison_fluxes_13C_FBA(:,1) = d;
comparison_fluxes_13C_TFA(:,1) = d;
comparison_fluxes_FBA_TFA(:,1) = d;
comparison_fluxes_total(:,1) = d;
comparison_metabolomics(:,1) = d;
failed_run_track(:,1) = d;
clear d
    
%% Load solver
cplex_loaded = load_cplex;
%C:\Program Files\IBM\ILOG\CPLEX_Studio128

if ~cplex_loaded
    error('CPLEX not found')
end

%% Load the COBRA Toolbox
addpath(genpath(fullfile('..','ext')))

%%  Load dependencies
addpath(genpath(fullfile('..','matTFA')))
addpath(genpath(fullfile('..','thermoDatabases')))
addpath(genpath(fullfile('..','models')))
addpath(genpath(fullfile('..','plotting')))

% switch to cplex solver
%changeCobraSolver('ibm_cplex')
changeCobraSolver('cplex_direct') % in theory the one that should be used

%% Load the model
tmp = load(fullfile('..','models','GSmodel_Ecoli.mat'));
tmp_therm = tmp.ttmodel;
clear tmp

tmp = load(fullfile('..','models','iJO1366.mat'));
mymodel_tmp = tmp.iJO1366;
clear tmp

conv = readtable('conv_iJO1366.csv');
conv_cell = table2cell(conv);
clear conv

mymodel = mymodel_tmp;
mymodel.mets = conv_cell(:,1);
mymodel.CompartmentData = tmp_therm.CompartmentData
mymodel.metCompSymbol = conv_cell(:,3);
mymodel.metSEEDID = conv_cell(:,4);

clear tmp_therm

%% Load the thermodynamics database
tmp = load('thermo_data.mat');
ReactionDB = tmp.DB_AlbertyUpdate;
clear tmp

%% save data original mymodel
% at some point some information is modified, affecting the labelling when
% gathering the data further down the code. Thus
original_mets = mymodel.mets;
adjustment_dG_mets(:, 1) = original_mets;
conc_est(:, 1) = original_mets;

original_rxns = mymodel.rxns;
adjustment_dG_rxns(:, 1) = original_rxns;
FBA_fluxes(:, 1) = original_rxns;
FBA_fluxes_trad(:, 1) = original_rxns;

%% Apply some preliminary constraints
uptake_glucose = {'EX_glc__D_e'};
id_uptake_glucose = find_cell(uptake_glucose, mymodel.rxns);
mymodel.lb(id_uptake_glucose) = -uptake_glucose_exp; 
mymodel.ub(id_uptake_glucose) = 0;  

% There are two biomass reactions, one will be totally shut down
% august: changed rxn
%biomass_reaction_2 = {'Ec_biomass_iJO1366_core_53p95M'};
biomass_reaction_2 = {'BIOMASS_Ec_iJO1366_WT_53p95M'};
id_growth_rate_2 = find_cell(biomass_reaction_2, mymodel.rxns);
mymodel.lb(id_growth_rate_2) = 0;
mymodel.ub(id_growth_rate_2) = 0;

% Limit the bounds of the fluxes that are higher than 100 or lower than
% -100 mmol/(gDW * h)
if any(mymodel.lb<-100) || any(mymodel.ub>100)
    mymodel.lb(mymodel.lb<-100) = -100;
    mymodel.ub(mymodel.ub>+100) = +100;
end

%% to store the results
indx_vector_c = [1:nruns];
testArray = sprintfc('%02d', indx_vector_c)';
for run_number = 1:numel(testArray)
S_gamma_model{run_number} = matlab.lang.makeValidName(strcat('gamma_model_',testArray{run_number}));
end       

%% loop to calculate
for run_number = 1:nruns
try
%% set parameter values necessary for other functions

disp(run_number)

global temperature
    temperature = par_temperature(run_number);

global ionic_strength
    ionic_strength = par_ionic_strength(run_number);
    
global equation_method
    equation_method = par_equation(run_number);
    
global prefactor_A
    prefactor_A = par_calc_prefactor_A(run_number);   
     
%% Test simple fba
mymodel_2 = mymodel;
solFBA = optimizeCbModel(mymodel_2); % original 
min_obj = roundsd(0.5*solFBA.f, 2, 'floor');
mymodel_2.lb(mymodel_2.c==1) = min_obj;

% whole set of fluxes calculated in FBA (traditional) added later than
% the other two

try

this_run_FBA_trad(:, 1) = mymodel_2.rxns; % counter: internal_counter_mymodel_original
this_run_FBA_trad(:, 2) = num2cell(solFBA.x);

internal_counter_mymodel = 1;
internal_counter_mymodel_original = 1;

while internal_counter_mymodel_original <= size(this_run_FBA_trad,1)
    if  isequal(FBA_fluxes_trad{internal_counter_mymodel,1},this_run_FBA_trad{internal_counter_mymodel_original,1});
        FBA_fluxes_trad{internal_counter_mymodel,run_number+1} = this_run_FBA_trad{internal_counter_mymodel_original,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_mymodel_original = internal_counter_mymodel_original + 1;
    else
        FBA_fluxes_trad{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_mymodel_original
clear this_run_FBA

catch
    disp('error')
end

%% Perform FVA 
fva = runMinMax(mymodel_2);

% Are there any blocked reactions?
% solver tolerance is 1e-9
SolTol = 1e-9;
id_Blocked_in_FBA = find( (fva(:,1)>-SolTol & fva(:,1)<SolTol) & ...
                          (fva(:,2)>-SolTol & fva(:,2)<SolTol) );
% If there exist block reactions
while ~isempty(id_Blocked_in_FBA)
    % remove them
    mymodel_2 = removeRxns(mymodel_2, mymodel_2.rxns(id_Blocked_in_FBA));
    fva = runMinMax(mymodel_2);
    id_Blocked_in_FBA = find( (fva(:,1)>-SolTol & fva(:,1)<SolTol) & ...
                              (fva(:,2)>-SolTol & fva(:,2)<SolTol) );
end

%% Prepare for TFA
    %need field for description
    prepped_m = prepModelforTFA(mymodel_2, ReactionDB, mymodel_2.CompartmentData);

%% Convert to TFA
    tmp = convToTFA(prepped_m, ReactionDB, [], 'DGo', [], min_obj);

    % Add net flux variables, which are equal to forwards flux - backwards flux
    % NF_rxn = F_rxn - B_rxn
    this_tmodel = addNetFluxVariables(tmp);

%% Solve tFA
    soltFA = solveTFAmodelCplex(this_tmodel);

%% Perform TVA
% this would be unnecessary?
    % Get the variables representing the net fluxes
    NF_ix = getAllVar(this_tmodel,{'NF'});
    tva = runTMinMax(this_tmodel, this_tmodel.varNames(NF_ix));

%% We add some generic data for cofactor concentrations
if par_conc_metabolites(run_number) == 0 % how it was
    metNames = {'adp_c', 'amp_c', 'atp_c'};
    C_lb = [1e-06, 2e-04, 1e-03]';
    C_ub = [7e-04, 3e-04, 5e-02]';
    LC_varNames = {'LC_adp_c', 'LC_amp_c', 'LC_atp_c'};
    % find the indices of these variables in the variable names of the tfa
    id_LC_varNames = find_cell(LC_varNames, this_tmodel.varNames);
    % Set to the model these log-concentration values
    this_tmodel.var_lb(id_LC_varNames) = log(C_lb);
    this_tmodel.var_ub(id_LC_varNames) = log(C_ub);
else
% Data from Ishii in mmol; assumed is the proper units for the toolbox. lb
% is 90% the experimental data, and ub 110%.
    metNames = metNames_exp;
%     C_exp = Conc_values_exp./1000; % so we convert from mM to M
    C_lb = 0.9.*C_exp;
    C_ub = 1.1.*C_exp;
    LC_varNames = {'LC_succoa_c', 'LC_trp-L_c', 'LC_dctp_c', 'LC_fdp_c', 'LC_fad_c', 'LC_met-L_c', 'LC_ile-L_c', 'LC_tyr-L_c', 'LC_datp_c', 'LC_f6p_c', 'LC_phe-L_c', 'LC_arg-L_c', 'LC_g1p_c', 'LC_his-L_c', 'LC_nadp_c', 'LC_pro-L_c', 'LC_asn-L_c', 'LC_leu-L_c', 'LC_pep_c', 'LC_dhap_c', 'LC_pyr_c', 'LC_amet_c', 'LC_thr-L_c', 'LC_malcoa_c', 'LC_accoa_c', 'LC_val-L_c', 'LC_s7p_c', 'LC_pydx5p_c', 'LC_ctp_c', 'LC_nadph_c', 'LC_gly_c', 'LC_ser-L_c', 'LC_ala-L_c', 'LC_asp-L_c', 'LC_lys-L_c', 'LC_3pg_c', 'LC_adp_c', 'LC_amp_c', 'LC_gtp_c', 'LC_utp_c', 'LC_gln-L_c', 'LC_nad_c', 'LC_atp_c', 'LC_glu-L_c'};
    % find the indices of these variables in the variable names of the tfa
    id_LC_varNames = find_cell(LC_varNames, this_tmodel.varNames);
    % Set to the model these log-concentration values
    this_tmodel.var_lb(id_LC_varNames) = log(C_lb);
    this_tmodel.var_ub(id_LC_varNames) = log(C_ub);
end

clear metNames
clear LC_varNames

stored_id_LC_varNames = id_LC_varNames;
clear id_LC_varNames

% Run another tva with the data
%     tva_wData = runTMinMax(this_tmodel, this_tmodel.varNames(NF_ix));

%% Get Thermodynamic displacements
% Add thermo_disp as variables
flagToAddLnThermoDisp = true;
gamma_model = convToTFA(prepped_m, ReactionDB, [], 'DGo', [], min_obj, [], flagToAddLnThermoDisp);
gamma_model = addNetFluxVariables(gamma_model);
gamma_model_backup = gamma_model; % this is to keep a copy for later use when gathering the results
NF_ix_gamma_model = getAllVar(gamma_model,{'NF'});
tva_gamma_model = runTMinMax(gamma_model, gamma_model.varNames(NF_ix_gamma_model));
stored_gamma_model.(S_gamma_model{run_number}) = gamma_model

solTFA = solveTFAmodelCplex(gamma_model);
LnGammaids = getAllVar(gamma_model,{'LnGamma'});
lngammaValues = solTFA.x(getAllVar(gamma_model,{'LnGammaids'}));

%% Gather data
%%%%% adjustment of Gibbs free energy values
% metabolites
this_run_adjustment_dG_mets(:, 1) = gamma_model.mets;
this_run_adjustment_dG_mets(:, 2) = num2cell(gamma_model.metDeltaGFtr);

internal_counter_mymodel = 1;
internal_counter_model_fixed_d_Conc = 1;

while internal_counter_model_fixed_d_Conc <= size(this_run_adjustment_dG_mets,1)
    if  isequal(adjustment_dG_mets{internal_counter_mymodel,1},this_run_adjustment_dG_mets{internal_counter_model_fixed_d_Conc,1});
        adjustment_dG_mets{internal_counter_mymodel,run_number+1} = this_run_adjustment_dG_mets{internal_counter_model_fixed_d_Conc,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_model_fixed_d_Conc = internal_counter_model_fixed_d_Conc + 1;
    else
        adjustment_dG_mets{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_model_fixed_d_Conc
clear this_run_adjustment_dG_mets

% reactions
this_run_adjustment_dG_rxns(:, 1) = gamma_model.rxns;
this_run_adjustment_dG_rxns(:, 2) = num2cell(gamma_model.rxnDeltaGR);

internal_counter_mymodel = 1;
internal_counter_model_fixed_d_Conc = 1;

while internal_counter_model_fixed_d_Conc <= size(this_run_adjustment_dG_rxns,1)
    if  isequal(adjustment_dG_rxns{internal_counter_mymodel,1},this_run_adjustment_dG_rxns{internal_counter_model_fixed_d_Conc,1});
        adjustment_dG_rxns{internal_counter_mymodel,run_number+1} = this_run_adjustment_dG_rxns{internal_counter_model_fixed_d_Conc,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_model_fixed_d_Conc = internal_counter_model_fixed_d_Conc + 1;
    else
        adjustment_dG_rxns{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_model_fixed_d_Conc
clear this_run_adjustment_dG_rxns

%%%%% estimated concentration values for metabolites
% estimated value. They are LC values (ln, called log() in matlab)!

list_varNames = gamma_model.varNames;
flux_varNames = solTFA.x;
data_result_TFA = table(list_varNames,flux_varNames);

this_run_pre_conc_est = data_result_TFA( startsWith(data_result_TFA.list_varNames,'LC_'), : );
this_run_pre_conc_est_cell = table2cell(this_run_pre_conc_est);

LC_names = cellstr(this_run_pre_conc_est_cell(:,1));
pre_conc_est(:,1) = strip(LC_names,'left','L');
pre_conc_est(:,1) = strip(pre_conc_est,'left','C');
pre_conc_est(:,1) = strip(pre_conc_est,'left','_');
ln_pre_conc_values(:,1) = cell2mat(this_run_pre_conc_est_cell(:,2));
mmol_pre_conc_values = exp(ln_pre_conc_values);
pre_conc_est(:,2) = num2cell(mmol_pre_conc_values); % expressed in mmol units

this_run_conc_est(:, 1) = pre_conc_est(:, 1);
this_run_conc_est(:, 2) = pre_conc_est(:, 2); % now we have two columns with the [met] for this run

internal_counter_mymodel = 1;
internal_counter_conc_est = 1;

while internal_counter_conc_est <= size(this_run_conc_est,1)
    if  isequal(conc_est{internal_counter_mymodel,1},this_run_conc_est{internal_counter_conc_est,1});
        conc_est{internal_counter_mymodel,run_number+1} = this_run_conc_est{internal_counter_conc_est,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_conc_est = internal_counter_conc_est + 1;
    else
        conc_est{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear list_varNames
clear flux_varNames
clear data_fluxes_TFA
clear this_run_pre_conc_est
clear this_run_pre_conc_est_cell
clear ln_pre_conc_values
clear mmol_pre_conc_values
clear pre_conc_est

clear internal_counter_mymodel
clear internal_counter_conc_est
clear this_run_conc_est

%%%%% extract flux values
% whole set of fluxes calculated in FBA (WITH FIXED DIRECTIONALITIES) ->
% not anymore!
this_run_FBA(:, 1) = mymodel.rxns;
this_run_FBA(:, 2) = num2cell(solFBA.x);

internal_counter_mymodel = 1;
internal_counter_model_fixed_d = 1;

while internal_counter_model_fixed_d <= size(this_run_FBA,1)
    if  isequal(FBA_fluxes{internal_counter_mymodel,1},this_run_FBA{internal_counter_model_fixed_d,1});
        FBA_fluxes{internal_counter_mymodel,run_number+1} = this_run_FBA{internal_counter_model_fixed_d,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_model_fixed_d = internal_counter_model_fixed_d + 1;
    else
        FBA_fluxes{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_model_fixed_d
clear this_run_FBA

% whole set of fluxes calculated in TFA
this_run_TFA(:, 1) = gamma_model.varNames;
this_run_TFA(:, 2) = num2cell(solTFA.x);
TFA_fluxes(:, 1) = gamma_model_backup.varNames; % backup before removing any reactions, so it should be the same for all the runs

internal_counter_mymodel = 1;
internal_counter_gamma_model = 1;

while internal_counter_gamma_model <= size(this_run_TFA,1)
    if  isequal(TFA_fluxes{internal_counter_mymodel,1},this_run_TFA{internal_counter_gamma_model,1});
        TFA_fluxes{internal_counter_mymodel,run_number+1} = this_run_TFA{internal_counter_gamma_model,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_gamma_model = internal_counter_gamma_model + 1;
    else
        TFA_fluxes{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_gamma_model
clear this_run_TFA

% subset of NF_fluxes in TFA
list_name_reactions = TFA_fluxes(:, 1);
flux_values_reactions = TFA_fluxes(:, run_number+1);
data_fluxes_NF = table(list_name_reactions,flux_values_reactions);

this_run_NF_fluxes = data_fluxes_NF( startsWith(data_fluxes_NF.list_name_reactions,'NF_'), : );
this_run_NF_fluxes_cell = table2cell(this_run_NF_fluxes);

NF_names(:,1) = cellstr(this_run_NF_fluxes_cell(:,1));
NF_fluxes = strip(NF_names,'left','N');
NF_fluxes = strip(NF_fluxes,'left','F');
NF_fluxes = strip(NF_fluxes,'left','_');
NF_fluxes(:,run_number+1) = this_run_NF_fluxes_cell(:,2);

clear flux_values_reactions
clear data_fluxes_NF
clear this_run_NF_fluxes
clear this_run_NF_fluxes_cell

pre_TFA_NF_fluxes = cell2table(TFA_fluxes);
TFA_NF_fluxes = pre_TFA_NF_fluxes( startsWith(list_name_reactions,'NF_'), : );
TFA_NF_fluxes_cell = table2cell(TFA_NF_fluxes);

% equivalent FBA fluxes to TFA's NF subset
eq_FBA_NF(:,1) = NF_fluxes(:,1);

internal_counter_eq_FBA_NF = 1;
internal_counter_NF_fluxes = 1;

while internal_counter_eq_FBA_NF <= size(eq_FBA_NF,1)
    if  isequal(eq_FBA_NF{internal_counter_eq_FBA_NF ,1},NF_fluxes{internal_counter_NF_fluxes ,1});
        id_flux_temp = find_cell(eq_FBA_NF{internal_counter_eq_FBA_NF ,1}, mymodel.rxns);
        eq_FBA_NF{internal_counter_eq_FBA_NF ,run_number+1} = solFBA.x(id_flux_temp);
        internal_counter_eq_FBA_NF = internal_counter_eq_FBA_NF + 1;
        internal_counter_NF_fluxes = internal_counter_NF_fluxes + 1;
        clear id_flux_temp
    else
        eq_FBA_NF{internal_counter_eq_FBA_NF ,run_number+1} = [];
        internal_counter_eq_FBA_NF  = internal_counter_eq_FBA_NF + 1;
    end
end

clear internal_counter_eq_FBA_NF 
clear internal_counter_NF_fluxes 

%% Calculate correlation coefficients
%%% Metabolomics
% subset of estimated concentration values that matches with the available
% metabolomics data from Ishii 2007
id_metNames_exp = find_cell(metNames_exp, original_mets);
match_conc_values = conc_est(id_metNames_exp,:);

this_run_match_conc_values = cell2mat(match_conc_values(:,run_number+1));  % we extract the estimated concentration values for this run
concentration_experimental = C_exp';
correlation_coef_matrix_metabolomics = corrcoef(this_run_match_conc_values,concentration_experimental);
correlation_coef_metabolomics = correlation_coef_matrix_metabolomics(2,1);
comparison_metabolomics(run_number,2) = correlation_coef_metabolomics;

clear id_metNames_exp
clear this_run_match_conc_values
clear correlation_coef_matrix_metabolomics
clear correlation_coef_metabolomics

%%% Fluxomics
% subset of TFA fluxes that can be compared with Ishii's 13C-MFA
names_comparison_fluxes_TFA = {'NF_ACALD', 'NF_ACONTa',  'NF_ACONTb', 'NF_ACKr', 'NF_AKGDH', 'NF_ALCD2x', 'NF_CS', 'NF_EDA', 'NF_EDD', 'NF_ENO', 'NF_FBA', 'NF_FUM', 'NF_G6PDH2r', 'NF_GAPD', 'NF_GLCptspp', 'NF_GND', 'NF_ICDHyr', 'NF_ICL', 'NF_LDH_D', 'NF_MALS', 'NF_MDH', 'NF_ME1', 'NF_ME2', 'NF_PDH', 'NF_PFK', 'NF_PGI', 'NF_PGK', 'NF_PGL', 'NF_PGM', 'NF_PPC', 'NF_PTAr', 'NF_PYK', 'NF_RPE', 'NF_RPI', 'NF_SUCDi', 'NF_SUCOAS', 'NF_TALA', 'NF_TKT1', 'NF_TKT2', 'NF_TPI'}  
id_comparison_fluxes_TFA = find_cell(names_comparison_fluxes_TFA, gamma_model.varNames);
this_run_fluxes_TFA_mmol_gDCW_h = solTFA.x(id_comparison_fluxes_TFA);
fluxes_TFA_mmol_gDCW_h(:,run_number) = cell2mat(num2cell(this_run_fluxes_TFA_mmol_gDCW_h));

name_uptake_glucose = {'NF_EX_glc__D_e'};
id_uptake_glucose_gamma = find_cell(name_uptake_glucose, gamma_model.varNames);
this_run_NF_uptake_glucose = -solTFA.x(id_uptake_glucose_gamma);
this_run_fluxes_TFA_normalized = (this_run_fluxes_TFA_mmol_gDCW_h./this_run_NF_uptake_glucose)*100; % fluxes are normalised in '%' by considering the uptake of glucose, so a comparison is enabled
fluxes_TFA_normalized(:,run_number) = cell2mat(num2cell(this_run_fluxes_TFA_normalized));

correlation_coef_matrix_13C_TFA = corrcoef(fluxes_13C, this_run_fluxes_TFA_normalized);
correlation_coef_13C_TFA = correlation_coef_matrix_13C_TFA(2,1);
comparison_fluxes_13C_TFA(run_number,2) = correlation_coef_13C_TFA;

clear id_comparison_fluxes_TFA
clear this_run_fluxes_TFA_mmol_gDCW_h
clear id_uptake_glucose_gamma
clear correlation_coef_matrix_13C_TFA

% subset of FBA fluxes that can be compared with Ishii's 13C-MFA
names_comparison_fluxes_FBA = {'ACALD', 'ACONTa', 'ACONTb', 'ACKr', 'AKGDH', 'ALCD2x', 'CS', 'EDA', 'EDD', 'ENO', 'FBA', 'FUM', 'G6PDH2r', 'GAPD', 'GLCptspp', 'GND', 'ICDHyr', 'ICL', 'LDH_D', 'MALS', 'MDH', 'ME1', 'ME2', 'PDH', 'PFK', 'PGI', 'PGK', 'PGL', 'PGM', 'PPC', 'PTAr', 'PYK', 'RPE', 'RPI', 'SUCDi', 'SUCOAS', 'TALA', 'TKT1', 'TKT2', 'TPI'} 
id_comparison_fluxes_FBA = find_cell(names_comparison_fluxes_FBA, mymodel.rxns);
this_run_fluxes_FBA_mmol_gDCW_h = solFBA.x(id_comparison_fluxes_FBA);
fluxes_FBA_mmol_gDCW_h(:,run_number) = cell2mat(num2cell(this_run_fluxes_FBA_mmol_gDCW_h));

name_uptake_glucose = {'EX_glc__D_e'};
id_uptake_glucose_model = find_cell(name_uptake_glucose, mymodel.rxns);
this_run_FBA_uptake_glucose = -solFBA.x(id_uptake_glucose_model); % based on mymodel_2, but just after copying from mymodel (later on, mymodel_2 is modified)
this_run_fluxes_FBA_normalized = (this_run_fluxes_FBA_mmol_gDCW_h./this_run_FBA_uptake_glucose)*100; % fluxes are normalised in '%' by considering the uptake of glucose, so a comparison is enabled
fluxes_FBA_normalized(:,run_number) = cell2mat(num2cell(this_run_fluxes_FBA_normalized));

correlation_coef_matrix_13C_FBA = corrcoef(fluxes_13C, this_run_fluxes_FBA_normalized);
correlation_coef_13C_FBA = correlation_coef_matrix_13C_FBA(2,1);
comparison_fluxes_13C_FBA(run_number,2) = correlation_coef_13C_FBA;

clear id_comparison_fluxes_FBA
clear this_run_fluxes_FBA_mmol_gDCW_h
clear id_uptake_glucose_model_fixed_d
clear correlation_coef_matrix_13C_FBA

% equivalent FBA fluxes with TFA's NF subset
correlation_coef_matrix_FBA_TFA = corrcoef(this_run_fluxes_FBA_normalized,this_run_fluxes_TFA_normalized);
correlation_coef_FBA_TFA = correlation_coef_matrix_FBA_TFA(2,1);
comparison_fluxes_FBA_TFA(run_number,2) = correlation_coef_FBA_TFA;

clear correlation_coef_matrix_FBA_TFA
clear this_run_fluxes_FBA_normalized

% collecting all the info 
comparison_fluxes_total(run_number,2) = correlation_coef_13C_FBA;
comparison_fluxes_total(run_number,3) = correlation_coef_13C_TFA;
comparison_fluxes_total(run_number,4) = correlation_coef_FBA_TFA;

clear correlation_coef_13C_FBA
clear correlation_coef_13C_TFA
clear correlation_coef_FBA_TFA

%%% Bioprocessing data
growth_rate_FBA = {'BIOMASS_Ec_iJO1366_core_53p95M'};
%id_growth_rate_FBA = find_cell(growth_rate_FBA, model_fixed_d.rxns);
id_growth_rate_FBA = find_cell(growth_rate_FBA, mymodel.rxns);

growth_rate_TFA = {'NF_BIOMASS_Ec_iJO1366_core_53p95M'};
id_growth_rate_TFA = find_cell(growth_rate_TFA, gamma_model.varNames);

% biomass flux info
biomass_flux_yield(run_number,2) = this_run_FBA_uptake_glucose;
biomass_flux_yield(run_number,3) = solFBA.x(id_growth_rate_FBA);
biomass_flux_yield(run_number,4) = biomass_flux_yield(run_number,3)/biomass_flux_yield(run_number,2);
biomass_flux_yield(run_number,5) = this_run_NF_uptake_glucose;
biomass_flux_yield(run_number,6) = solTFA.x(id_growth_rate_TFA);
biomass_flux_yield(run_number,7) = biomass_flux_yield(run_number,6)/biomass_flux_yield(run_number,5);

clear this_run_FBA_uptake_glucose
clear this_run_NF_uptake_glucose

save def_e_coli_loop

catch
    disp('there was an error')
    failed_run_track(run_number,2) = run_number;
end

end
%toc

save def_e_coli

%% Yields

for run_number = 1:nruns

% yield values
yield_values(run_number,2) = yield_exp;                                                                             % g DCW/ g glucose consumed
yield_values(run_number,3) = yield_theoret;                                                                         % g DCW/ g glucose consumed
yield_values(run_number,4) = (biomass_flux_yield(run_number,3)/biomass_flux_yield(run_number,2)*(1000/MW_glucose)); % yield FBA, g DCW/ g glucose consumed
yield_values(run_number,5) = (biomass_flux_yield(run_number,6)/biomass_flux_yield(run_number,5)*(1000/MW_glucose)); % yield TFA, g DCW/ g glucose consumed

% deviation from experimental yield values
    %not in absolute value!
yield_deviation(run_number,2) = 100*((yield_values(run_number,2)-yield_values(run_number,3))/yield_values(run_number,2)); % % dev yield theoretical from yield_exp
yield_deviation(run_number,3) = 100*((yield_values(run_number,2)-yield_values(run_number,4))/yield_values(run_number,2)); % % dev yield FBA from yield_exp
yield_deviation(run_number,4) = 100*((yield_values(run_number,2)-yield_values(run_number,5))/yield_values(run_number,2)); % % dev yield TFA from yield_exp

end
%% concordance analysis
correlation_coef_13C_TFA = comparison_fluxes_total(:,3);
correlation_coef_metabolomics = comparison_metabolomics(:,2);

% it is better to round to the 3rd floating number (differences are bigger
% at the metabolomics than at the fluxomics level)

round_correlation_coef_13C_TFA = round(correlation_coef_13C_TFA,3)
round_correlation_coef_metabolomics = round(correlation_coef_metabolomics,3)

X = [round_correlation_coef_13C_TFA round_correlation_coef_metabolomics];
W = KendallCoef(X);

%% Joint ranking
% considering the ranks obtained in the previous step, we can now weight
% both criteria: goodnes-of-fit at the fluxomics and at the metabolomics
% levels. Hence, position #1 will receive 0 points and position #64 50
% point.
% 
% according to 'tiedrank', rank are in ascending order (thus, the last one
% would be the run with the best correlation)
RankMatrix = tiedrank(X);
rank_flux = RankMatrix(:,1);
rank_metab = RankMatrix(:,2);
w_rank_flux = 0.7937*rank_flux - 0.7937;
w_rank_metab =  0.7937*rank_metab - 0.7937;
sum_w_rank = w_rank_flux + w_rank_metab;
rank_sum_w_rank = tiedrank(sum_w_rank);

total_ranking = zeros(nruns,9);
total_ranking(:,1) = linspace(1,nruns,nruns);
total_ranking(:,2) = correlation_coef_13C_TFA;
total_ranking(:,3) = correlation_coef_metabolomics;
total_ranking(:,4) = rank_flux;
total_ranking(:,5) = rank_metab;
total_ranking(:,6) = w_rank_flux;
total_ranking(:,7) = w_rank_metab;
total_ranking(:,8) = sum_w_rank;
total_ranking(:,9) = rank_sum_w_rank;

% find the runs with the highest rank_sum_weight
maxval = max(rank_sum_w_rank);
idx = find(rank_sum_w_rank == maxval);

%% Directionalities pattern variation TFA (match w/ 13C-MFA data)
fluxes_TFA_normalized_total = [fluxes_TFA_normalized fluxes_13C'] % adding known 13C fluxes as run #65
fluxes_TFA_normalized_pattern = fluxes_TFA_normalized_total;
total_number_index = size(fluxes_TFA_normalized_total,1)*size(fluxes_TFA_normalized_total,2);

for index_TFA = 1:total_number_index
    if fluxes_TFA_normalized_pattern(index_TFA) > 0
        fluxes_TFA_normalized_pattern(index_TFA) = 1;
    elseif fluxes_TFA_normalized_pattern(index_TFA) < 0
        fluxes_TFA_normalized_pattern(index_TFA) = -1;
    else
        fluxes_TFA_normalized_pattern(index_TFA) = 0;
    end
end

% fluxes going forward
fluxes_TFA_normalized_pattern_green = changem(fluxes_TFA_normalized_pattern, NaN, [0]);
fluxes_TFA_normalized_pattern_green = changem(fluxes_TFA_normalized_pattern_green, NaN, [-1]);

% fluxes going reverse
fluxes_TFA_normalized_pattern_red = changem(fluxes_TFA_normalized_pattern, NaN, [0]);
fluxes_TFA_normalized_pattern_red = changem(fluxes_TFA_normalized_pattern_red, NaN, [1]);

% fluxes with value of 0
fluxes_TFA_normalized_pattern_white = changem(fluxes_TFA_normalized_pattern, NaN, [-1]);
fluxes_TFA_normalized_pattern_white = changem(fluxes_TFA_normalized_pattern_white, NaN, [1]);

y_values = linspace(1,nruns+1,nruns+1)';     % run number
x_values = linspace(1,size(fluxes_13C,2),size(fluxes_13C,2))';
x_list = [num2cell(x_values) names_comparison_fluxes_TFA'];
[X,Y] = meshgrid(x_values,y_values);

z_values_g = fluxes_TFA_normalized_pattern_green(x_values, y_values);
z_values_r = fluxes_TFA_normalized_pattern_red(x_values, y_values);
z_values_w = fluxes_TFA_normalized_pattern_white(x_values, y_values);

Z_g = z_values_g.';
stem3(X,Y,Z_g,'MarkerFaceColor','g')
hold on

Z_r = z_values_r.';
stem3(X,Y,Z_r,'MarkerFaceColor','r', 'LineStyle', 'none')
hold on

Z_w = z_values_w.';
stem3(X,Y,Z_w,'MarkerFaceColor','w')
hold on

title('Pattern of reaction directionalities');
set(gca,'fontname','arial') 
xlabel('Reaction number (subset)')
ylabel('Run number')

clear h
%% export results
adjustment_dG_mets_table = cell2table(adjustment_dG_mets);
writetable(adjustment_dG_mets_table,'adjustment_dG_mets_table.txt','Delimiter',' ');  
type 'adjustment_dG_mets_table.txt';

adjustment_dG_rxns_table = cell2table(adjustment_dG_rxns);
writetable(adjustment_dG_rxns_table,'adjustment_dG_rxns_table.txt','Delimiter',' ');  
type 'adjustment_dG_rxns_table.txt';

conc_est_table = cell2table(conc_est);
writetable(conc_est_table,'conc_est_table.txt','Delimiter',' ');  
type 'conc_est_table.txt';

match_conc_values_table = cell2table(match_conc_values);
writetable(match_conc_values_table,'match_conc_values_table.txt','Delimiter',' ');  
type 'match_conc_values_table.txt';

comparison_metabolomics_table = array2table(comparison_metabolomics,...
    'VariableNames',{'Test_number' 'Correlation_coefficient'});
writetable(comparison_metabolomics_table,'comparison_metabolomics_table.txt','Delimiter',' ');  
type 'comparison_metabolomics_table.txt';

FBA_fluxes_table = cell2table(FBA_fluxes);
writetable(FBA_fluxes_table,'FBA_fluxes_table.txt','Delimiter',' ');  
type 'FBA_fluxes_table.txt';

fluxes_FBA_mmol_gDCW_h_table = array2table(fluxes_FBA_mmol_gDCW_h)
writetable(fluxes_FBA_mmol_gDCW_h_table,'fluxes_FBA_mmol_gDCW_h_table.txt','Delimiter',' ');  
type 'fluxes_FBA_mmol_gDCW_h_table.txt';

fluxes_FBA_normalized_table = array2table(fluxes_FBA_normalized)
writetable(fluxes_FBA_normalized_table,'fluxes_FBA_normalized_table.txt','Delimiter',' ');  
type 'fluxes_FBA_normalized_table.txt';

TFA_fluxes_table = cell2table(TFA_fluxes);
writetable(TFA_fluxes_table,'TFA_fluxes_table.txt','Delimiter',' ');  
type 'TFA_fluxes_table.txt';

fluxes_TFA_mmol_gDCW_h_table = array2table(fluxes_TFA_mmol_gDCW_h)
writetable(fluxes_TFA_mmol_gDCW_h_table,'fluxes_TFA_mmol_gDCW_h_table.txt','Delimiter',' ');  
type 'fluxes_TFA_mmol_gDCW_h_table.txt';

fluxes_TFA_normalized_table = array2table(fluxes_TFA_normalized)
writetable(fluxes_TFA_normalized_table,'fluxes_TFA_normalized_table.txt','Delimiter',' ');  
type 'fluxes_TFA_normalized_table.txt';

comparison_fluxes_total_table = array2table(comparison_fluxes_total,...
    'VariableNames',{'Test_number' 'correlation_coef_13C_FBA' 'correlation_coef_13C_TFA' 'correlation_coef_FBA_TFA'});
writetable(comparison_fluxes_total_table,'comparison_fluxes_table.txt','Delimiter',' ');  
type 'comparison_fluxes_table.txt';

biomass_flux_yield_table = array2table(biomass_flux_yield,...
    'VariableNames',{'Test_number' 'FBA_Uptake_Glucose' 'FBA_Growth_Rate' 'FBA_Y' 'TFA_Uptake_Glucose' 'TFA_Growth_Rate' 'TFA_Y'});
writetable(biomass_flux_yield_table,'biomass_yield_table.txt','Delimiter',' ');  
type 'biomass_yield_table.txt';

yield_values_table = array2table(yield_values,...
    'VariableNames',{'Test_number' 'Experimental' 'Theoretical' 'FBA' 'TFA'})
writetable(yield_values_table,'yield_values_table.txt','Delimiter',' ');  
type 'yield_values_table.txt';

yield_deviation_table = array2table(yield_deviation,...
    'VariableNames',{'Test_number' 'dev_theoretical' 'dev_FBA' 'dev_TFA'}) % deviations are in %
writetable(yield_deviation_table,'yield_deviation_table.txt','Delimiter',' ');  
type 'yield_deviation_table.txt';

total_ranking_table = array2table(total_ranking,...
    'VariableNames',{'Run_number' 'correlation_coef_13C_TFA' 'correlation_coef_metabolomics' 'rank_flux' 'rank_metab' 'w_rank_flux' 'w_rank_metab' 'sum_w_rank' 'rank_sum_w_rank'}) % deviations are in %
writetable(total_ranking_table,'total_ranking_table.txt','Delimiter',' ');  
type 'total_ranking_table.txt';

save def_e_coli_fin_1

%% Now we analyse the optimal solutions at different level, looking at how different they are 
% in principle, there are 'num_succ_runs' succesful runs (i.e. solutions).
% We need to identify the non-redundant ones (nnred)
num_succ_runs = size(failed_run_track,1)- nnz(failed_run_track(:,2));
index_succ = zeros(num_succ_runs,2);
index_succ(:,1) = 1:num_succ_runs;
j = 1;
for i = 1:size(failed_run_track,1)
    tmp = failed_run_track(i,2)
    if tmp == 0 % i.e. it did not fail
        index_succ(j,2) = failed_run_track(i,1) % take position as index
        j = j+1 
        clear tmp
    end    
end
clear i
clear j

% 1) FBA fluxes
succ_FBA_fluxes = num2cell(zeros(size(FBA_fluxes,1),num_succ_runs+1));
succ_FBA_fluxes(:,1) = FBA_fluxes(:,1);
% 2) TFA fluxes
succ_TFA_fluxes = num2cell(zeros(size(TFA_NF_fluxes_cell,1),num_succ_runs+1));
succ_TFA_fluxes(:,1) = TFA_NF_fluxes_cell(:,1);
% 3) TFA fluxes for central C metabolism (normalized)
succ_TFA_normalized = num2cell(zeros(size(fluxes_TFA_normalized,1),num_succ_runs+1));
succ_TFA_normalized(:,1) = names_comparison_fluxes_TFA';
% 4) estimated concentration values
succ_conc_est = num2cell(zeros(size(conc_est,1),num_succ_runs+1));
succ_conc_est(:,1) = conc_est(:,1);
% 5) concentration values matching experimental data
succ_match_conc = num2cell(zeros(size(match_conc_values,1),num_succ_runs+1));
succ_match_conc(:,1) = match_conc_values(:,1);

% need to extract them from the new variables
for i = 1:num_succ_runs
    tmp_index = index_succ(i,2)
    succ_FBA_fluxes(:,i+1) = (FBA_fluxes(:,tmp_index+1));
    succ_TFA_fluxes(:,i+1) = (TFA_NF_fluxes_cell(:,tmp_index+1));
    succ_TFA_normalized(:,i+1) = num2cell(fluxes_TFA_normalized(:,tmp_index));
    succ_conc_est(:,i+1) = (conc_est(:,tmp_index+1));
    succ_match_conc(:,i+1) = (match_conc_values(:,tmp_index+1));
end

% round values to minimise the effect of mathematical artefacts. It is also
% important to replace empty cells with 0s
empties = cellfun('isempty',succ_FBA_fluxes);
succ_FBA_fluxes(empties) = {0};
round_succ_FBA_fluxes = cell2mat(succ_FBA_fluxes(:,2:end));
round_succ_FBA_fluxes = round(round_succ_FBA_fluxes,5,'significant');
round_succ_FBA_fluxes = [succ_FBA_fluxes(:,1) num2cell(round_succ_FBA_fluxes)];
clear empties
empties = cellfun('isempty',succ_TFA_fluxes);
succ_TFA_fluxes(empties) = {0};
round_succ_TFA_fluxes = cell2mat(succ_TFA_fluxes(:,2:end));
round_succ_TFA_fluxes = round(round_succ_TFA_fluxes,5,'significant');
round_succ_TFA_fluxes = [succ_TFA_fluxes(:,1) num2cell(round_succ_TFA_fluxes)];
clear empties
empties = cellfun('isempty',succ_TFA_normalized);
succ_TFA_normalized(empties) = {0};
round_succ_TFA_normalized = cell2mat(succ_TFA_normalized(:,2:end));
round_succ_TFA_normalized = round(round_succ_TFA_normalized,5,'significant');
round_succ_TFA_normalized = [succ_TFA_normalized(:,1) num2cell(round_succ_TFA_normalized)];
clear empties
empties = cellfun('isempty',succ_conc_est);
succ_conc_est(empties) = {0};
round_succ_conc_est = cell2mat(succ_conc_est(:,2:end));
round_succ_conc_est = round(round_succ_conc_est,5,'significant');
round_succ_conc_est = [succ_conc_est(:,1) num2cell(round_succ_conc_est)];
clear empties
empties = cellfun('isempty',succ_match_conc);
succ_match_conc(empties) = {0};
round_succ_match_conc = cell2mat(succ_match_conc(:,2:end));
round_succ_match_conc = round(round_succ_match_conc,5,'significant');
round_succ_match_conc = [succ_match_conc(:,1) num2cell(round_succ_match_conc)];
clear empties

% substitute numerical artifacts by 0
upper_b = 1e-7;
lower_b = -1e-7;
% 1)
d_round_succ_FBA_fluxes = cell2mat(round_succ_FBA_fluxes(:,2:end));
mod_round_succ_FBA_fluxes = zeros(size(d_round_succ_FBA_fluxes,1),(size(d_round_succ_FBA_fluxes,2)));
for i = 1:size(d_round_succ_FBA_fluxes,1)
    for j = 1:size(d_round_succ_FBA_fluxes,2)
        if d_round_succ_FBA_fluxes(i,j) <= upper_b && d_round_succ_FBA_fluxes(i,j) > lower_b 
            mod_round_succ_FBA_fluxes(i,j) = 0;
        else
            mod_round_succ_FBA_fluxes(i,j) = d_round_succ_FBA_fluxes(i,j);
        end
    end
end
mod_round_succ_FBA_fluxes = num2cell(mod_round_succ_FBA_fluxes);
mod_round_succ_FBA_fluxes = [round_succ_FBA_fluxes(:,1) mod_round_succ_FBA_fluxes];
% 2)
d_round_succ_TFA_fluxes = cell2mat(round_succ_TFA_fluxes(:,2:end));
mod_round_succ_TFA_fluxes = zeros(size(d_round_succ_TFA_fluxes,1),(size(d_round_succ_TFA_fluxes,2)));
for i = 1:size(d_round_succ_TFA_fluxes,1)
    for j = 1:size(d_round_succ_TFA_fluxes,2)
        if d_round_succ_TFA_fluxes(i,j) <= upper_b && d_round_succ_TFA_fluxes(i,j) > lower_b 
            mod_round_succ_TFA_fluxes(i,j) = 0;
        else
            mod_round_succ_TFA_fluxes(i,j) = d_round_succ_TFA_fluxes(i,j);
        end
    end
end
mod_round_succ_TFA_fluxes = num2cell(mod_round_succ_TFA_fluxes);
mod_round_succ_TFA_fluxes = [round_succ_TFA_fluxes(:,1) mod_round_succ_TFA_fluxes];
% 3)
d_round_succ_TFA_normalized = cell2mat(round_succ_TFA_normalized(:,2:end));
mod_round_succ_TFA_normalized = zeros(size(d_round_succ_TFA_normalized,1),(size(d_round_succ_TFA_normalized,2)));
for i = 1:size(d_round_succ_TFA_normalized,1)
    for j = 1:size(d_round_succ_TFA_normalized,2)
        if d_round_succ_TFA_normalized(i,j) <= upper_b && d_round_succ_TFA_normalized(i,j) > lower_b 
            mod_round_succ_TFA_normalized(i,j) = 0;
        else
            mod_round_succ_TFA_normalized(i,j) = d_round_succ_TFA_normalized(i,j);
        end
    end
end
mod_round_succ_TFA_normalized = num2cell(mod_round_succ_TFA_normalized);
mod_round_succ_TFA_normalized = [round_succ_TFA_normalized(:,1) mod_round_succ_TFA_normalized];
% 4)
d_round_succ_conc_est = cell2mat(round_succ_conc_est(:,2:end));
mod_round_succ_conc_est = d_round_succ_conc_est;
mod_round_succ_conc_est(d_round_succ_conc_est(:,:) < upper_b) = 0;
mod_round_succ_conc_est = num2cell(mod_round_succ_conc_est);
mod_round_succ_conc_est = [round_succ_conc_est(:,1) mod_round_succ_conc_est];

% 5)
d_round_succ_match_conc = cell2mat(round_succ_match_conc(:,2:end));
mod_round_succ_match_conc = d_round_succ_match_conc;
mod_round_succ_match_conc(d_round_succ_match_conc(:,:) < upper_b) = 0;
mod_round_succ_match_conc = num2cell(mod_round_succ_match_conc);
mod_round_succ_match_conc = [round_succ_match_conc(:,1) mod_round_succ_match_conc];

% Select non-redundant solutions
%%% 1) Two solutions are assumed to be the same when the flux values are the
% same. In order to reduce the effect of numerical artifacts, let's round the number to the 5th decimal
num_mod_round_succ_FBA_fluxes = cell2mat(mod_round_succ_FBA_fluxes(:,2:end));

% generate new matrices without rows that are always 0
mean_solFBA_all = zeros(size(num_mod_round_succ_FBA_fluxes,1),1);
for i = 1:size(mean_solFBA_all,1)
    mean_solFBA_all(i,1) = mean(num_mod_round_succ_FBA_fluxes(i,:));
end
flag_solFBA_all = ones(size(num_mod_round_succ_FBA_fluxes,1),1);
for i = 1:size(flag_solFBA_all,1)
    if mean_solFBA_all(i,1) == 0
        flag_solFBA_all(i,1) = 0;
    end         
end
clean_solFBA_all = zeros(nnz(flag_solFBA_all),size(num_mod_round_succ_FBA_fluxes,2));
j = 1;
for i=1:size(num_mod_round_succ_FBA_fluxes,1)
    if flag_solFBA_all(i,1) == 1
        clean_solFBA_all(j,:) = num_mod_round_succ_FBA_fluxes(i,:);
        j = j + 1;
    end
end
clear j

%%% Now we analyse the similarities
% number of succesful runs
succ_runs = size(clean_solFBA_all,2)
num_combinations = 0;
for p = 1:succ_runs
num_combinations = num_combinations + p;
end
clear p

list_comb = zeros(num_combinations,2); % combination of this list against itself
p = 1;
r = 1;
while p <= succ_runs
    for q = p:succ_runs
        list_comb(r,1) = p;
        list_comb(r,2) = q;
        r = r + 1;
    end
p = p + 1;
end
clear p
clear q
clear r

% now we calculate the Jaccard index for every combination
p = 1;
for p = 1:num_combinations
    X = [clean_solFBA_all(:,list_comb(p,1)) clean_solFBA_all(:,list_comb(p,2))]';
    JD = pdist(X,'jaccard');
    JI = 1 - JD;
    list_comb(p,3) = JI;
        
    clear X
    clear JD
    clear JI
end
clear p

% average and std dev of similarities
p = 1;
for p = 1:num_combinations
    list_comb(p,4) = mean(list_comb(p,3));
    list_comb(p,5) = std(list_comb(p,3));
end
clear p

% calculate pairs of unique average-std dev values
stats_list_comb(:,1) = unique(list_comb(:,4),'stable');
stats_list_comb(:,2) = unique(list_comb(:,5),'stable');

%%% I need a symmetric matrix to identify identical vectors (i.e. tests that
% produce the same flux/metabolic space solution) -> average of JIs (not
% actual flux values!)
ave_matrix = zeros(succ_runs,succ_runs);
for i = 1:size(list_comb,1)
    ave_matrix(list_comb(i,1),list_comb(i,2)) = list_comb(i,4);
    ave_matrix(list_comb(i,2),list_comb(i,1)) = list_comb(i,4);
end
space_solutions = unique(ave_matrix(:,:),'rows','stable');
identification_test = zeros(succ_runs,size(space_solutions,1)); % rows are the test number, column the case of space solution
for i = 1:size(space_solutions,1)
    for j = 1:succ_runs
        tmp = space_solutions(i,:) - ave_matrix(j,:);
        if tmp == 0
            identification_test(j,i) = 1;
        end
        clear tmp
    end
end
identification_test_FBA = [index_succ(1:succ_runs,2) identification_test]

clear num_mod_round_succ_FBA_fluxes
clear mean_solFBA_all
clear flag_solFBA_all
clear clean_solFBA_all
clear succ_runs
clear num_combinations
clear list_comb
clear stats_list_comb
clear ave_matrix
clear space_solutions
clear identification_test

%
%%% 2) Two solutions are assumed to be the same when the flux values are the
% same. In order to reduce the effect of numerical artifacts, let's round the number to the 5th decimal
num_mod_round_succ_TFA_fluxes = cell2mat(mod_round_succ_TFA_fluxes(:,2:end));
 
% generate new matrices without rows that are always 0
mean_solTFA_all = zeros(size(num_mod_round_succ_TFA_fluxes,1),1);
for i = 1:size(mean_solTFA_all,1)
    mean_solTFA_all(i,1) = mean(num_mod_round_succ_TFA_fluxes(i,:));
end
flag_solTFA_all = ones(size(num_mod_round_succ_TFA_fluxes,1),1);
for i = 1:size(flag_solTFA_all,1)
    if mean_solTFA_all(i,1) == 0
        flag_solTFA_all(i,1) = 0;
    end         
end
clean_solTFA_all = zeros(nnz(flag_solTFA_all),size(num_mod_round_succ_TFA_fluxes,2));
j = 1;
for i=1:size(num_mod_round_succ_TFA_fluxes,1)
    if flag_solTFA_all(i,1) == 1
        clean_solTFA_all(j,:) = num_mod_round_succ_TFA_fluxes(i,:);
        j = j + 1;
    end
end
clear j
 
%%% Now we analyse the similarities
% number of succesful runs
succ_runs = size(clean_solTFA_all,2)
num_combinations = 0;
for p = 1:succ_runs
num_combinations = num_combinations + p;
end
clear p
 
list_comb = zeros(num_combinations,2); % combination of this list against itself
p = 1;
r = 1;
while p <= succ_runs
    for q = p:succ_runs
        list_comb(r,1) = p;
        list_comb(r,2) = q;
        r = r + 1;
    end
p = p + 1;
end
clear p
clear q
clear r
 
% now we calculate the Jaccard index for every combination
p = 1;
for p = 1:num_combinations
    X = [clean_solTFA_all(:,list_comb(p,1)) clean_solTFA_all(:,list_comb(p,2))]';
    JD = pdist(X,'jaccard');
    JI = 1 - JD;
    list_comb(p,3) = JI;
        
    clear X
    clear JD
    clear JI
end
clear p
 
% average and std dev of similarities
p = 1;
for p = 1:num_combinations
    list_comb(p,4) = mean(list_comb(p,3));
    list_comb(p,5) = std(list_comb(p,3));
end
clear p
 
% calculate pairs of unique average-std dev values
stats_list_comb(:,1) = unique(list_comb(:,4),'stable');
stats_list_comb(:,2) = unique(list_comb(:,5),'stable');
 
%%% I need a symmetric matrix to identify identical vectors (i.e. tests that
% produce the same flux/metabolic space solution) -> average of JIs (not
% actual flux values!)
ave_matrix = zeros(succ_runs,succ_runs);
for i = 1:size(list_comb,1)
    ave_matrix(list_comb(i,1),list_comb(i,2)) = list_comb(i,4);
    ave_matrix(list_comb(i,2),list_comb(i,1)) = list_comb(i,4);
end
space_solutions = unique(ave_matrix(:,:),'rows','stable');
identification_test = zeros(succ_runs,size(space_solutions,1)); % rows are the test number, column the case of space solution
for i = 1:size(space_solutions,1)
    for j = 1:succ_runs
        tmp = space_solutions(i,:) - ave_matrix(j,:);
        if tmp == 0
            identification_test(j,i) = 1;
        end
        clear tmp
    end
end
pre_identification_test_TFA = [index_succ(1:succ_runs,2) identification_test];
identification_test_TFA = zeros(size(pre_identification_test_TFA,1),2);
identification_test_TFA(:,1) = pre_identification_test_TFA(:,1);
for i = 1:(size(pre_identification_test_TFA,2)-1)
    j = 0;
    for j = 1:size(pre_identification_test_TFA,1)
        if pre_identification_test_TFA(j,i+1) == 1
           identification_test_TFA(j,2) = i
        end
    end    
end
 
clear num_mod_round_succ_TFA_fluxes
clear mean_solTFA_all
clear flag_solTFA_all
clear clean_solTFA_all
clear succ_runs
clear num_combinations
clear list_comb
clear stats_list_comb
clear ave_matrix
clear space_solutions
clear identification_test
clear pre_identification_test_TFA
% 
%%% 3) Two solutions are assumed to be the same when the flux values are the
% same. In order to reduce the effect of numerical artifacts, let's round the number to the 5th decimal
num_mod_round_succ_TFA_normalized = cell2mat(mod_round_succ_TFA_normalized(:,2:end));
 
% generate new matrices without rows that are always 0
mean_solTFA_normalized_all = zeros(size(num_mod_round_succ_TFA_normalized,1),1);
for i = 1:size(mean_solTFA_normalized_all,1)
    mean_solTFA_normalized_all(i,1) = mean(num_mod_round_succ_TFA_normalized(i,:));
end
flag_solTFA_normalized_all = ones(size(num_mod_round_succ_TFA_normalized,1),1);
for i = 1:size(flag_solTFA_normalized_all,1)
    if mean_solTFA_normalized_all(i,1) == 0
        flag_solTFA_normalized_all(i,1) = 0;
    end         
end
clean_solTFA_normalized_all = zeros(nnz(flag_solTFA_normalized_all),size(num_mod_round_succ_TFA_normalized,2));
j = 1;
for i=1:size(num_mod_round_succ_TFA_normalized,1)
    if flag_solTFA_normalized_all(i,1) == 1
        clean_solTFA_normalized_all(j,:) = num_mod_round_succ_TFA_normalized(i,:);
        j = j + 1;
    end
end
clear j
 
%%% Now we analyse the similarities
% number of succesful runs
succ_runs = size(clean_solTFA_normalized_all,2)
num_combinations = 0;
for p = 1:succ_runs
num_combinations = num_combinations + p;
end
clear p
 
list_comb = zeros(num_combinations,2); % combination of this list against itself
p = 1;
r = 1;
while p <= succ_runs
    for q = p:succ_runs
        list_comb(r,1) = p;
        list_comb(r,2) = q;
        r = r + 1;
    end
p = p + 1;
end
clear p
clear q
clear r
 
% now we calculate the Jaccard index for every combination
p = 1;
for p = 1:num_combinations
    X = [clean_solTFA_normalized_all(:,list_comb(p,1)) clean_solTFA_normalized_all(:,list_comb(p,2))]';
    JD = pdist(X,'jaccard');
    JI = 1 - JD;
    list_comb(p,3) = JI;
        
    clear X
    clear JD
    clear JI
end
clear p
 
% average and std dev of similarities
p = 1;
for p = 1:num_combinations
    list_comb(p,4) = mean(list_comb(p,3));
    list_comb(p,5) = std(list_comb(p,3));
end
clear p
 
% calculate pairs of unique average-std dev values
stats_list_comb(:,1) = unique(list_comb(:,4),'stable');
stats_list_comb(:,2) = unique(list_comb(:,5),'stable');
 
%%% I need a symmetric matrix to identify identical vectors (i.e. tests that
% produce the same flux/metabolic space solution) -> average of JIs (not
% actual flux values!)
ave_matrix = zeros(succ_runs,succ_runs);
for i = 1:size(list_comb,1)
    ave_matrix(list_comb(i,1),list_comb(i,2)) = list_comb(i,4);
    ave_matrix(list_comb(i,2),list_comb(i,1)) = list_comb(i,4);
end
space_solutions = unique(ave_matrix(:,:),'rows','stable');
identification_test = zeros(succ_runs,size(space_solutions,1)); % rows are the test number, column the case of space solution
for i = 1:size(space_solutions,1)
    for j = 1:succ_runs
        tmp = space_solutions(i,:) - ave_matrix(j,:);
        if tmp == 0
            identification_test(j,i) = 1;
        end
        clear tmp
    end
end
pre_identification_test_TFA_normalized = [index_succ(1:succ_runs,2) identification_test];
identification_test_TFA_normalized = zeros(size(pre_identification_test_TFA_normalized,1),2);
identification_test_TFA_normalized(:,1) = pre_identification_test_TFA_normalized(:,1);
for i = 1:(size(pre_identification_test_TFA_normalized,2)-1)
    j = 0;
    for j = 1:size(pre_identification_test_TFA_normalized,1)
        if pre_identification_test_TFA_normalized(j,i+1) == 1
           identification_test_TFA_normalized(j,2) = i;
        end
    end    
end
 
clear num_mod_round_succ_TFA_fluxes_normalized
clear mean_solTFA_normalized_all
clear flag_solTFA_normalized_all
clear clean_solTFA_normalized_all
clear succ_runs
clear num_combinations
clear list_comb
clear stats_list_comb
clear ave_matrix
clear space_solutions
clear identification_test
clear pre_identification_test_TFA_normalized

% 
%%%4) Two solutions are assumed to be the same when the concentration values % are the same. In order to reduce the effect of numerical artifacts, let's round the number to the 5th decimal
num_mod_round_succ_conc_est = cell2mat(mod_round_succ_conc_est(:,2:end));
 
% generate new matrices without rows that are always 0
mean_conc_est_all = zeros(size(num_mod_round_succ_conc_est,1),1);
for i = 1:size(mean_conc_est_all,1)
    mean_conc_est_all(i,1) = mean(num_mod_round_succ_conc_est(i,:));
end
flag_conc_est_all = ones(size(num_mod_round_succ_conc_est,1),1);
for i = 1:size(flag_conc_est_all,1)
    if mean_conc_est_all(i,1) == 0
        flag_conc_est_all(i,1) = 0;
    end         
end
clean_conc_est_all = zeros(nnz(flag_conc_est_all),size(num_mod_round_succ_conc_est,2));
j = 1;
for i=1:size(num_mod_round_succ_conc_est,1)
    if flag_conc_est_all(i,1) == 1
        clean_conc_est_all(j,:) = num_mod_round_succ_conc_est(i,:);
        j = j + 1;
    end
end
clear j
 
%%% Now we analyse the similarities
% number of succesful runs
succ_runs = size(clean_conc_est_all,2)
num_combinations = 0;
for p = 1:succ_runs
num_combinations = num_combinations + p;
end
clear p
 
list_comb = zeros(num_combinations,2); % combination of this list against itself
p = 1;
r = 1;
while p <= succ_runs
    for q = p:succ_runs
        list_comb(r,1) = p;
        list_comb(r,2) = q;
        r = r + 1;
    end
p = p + 1;
end
clear p
clear q
clear r
 
% now we calculate the Jaccard index for every combination
p = 1;
for p = 1:num_combinations
    X = [clean_conc_est_all(:,list_comb(p,1)) clean_conc_est_all(:,list_comb(p,2))]';
    JD = pdist(X,'jaccard');
    JI = 1 - JD;
    list_comb(p,3) = JI;
        
    clear X
    clear JD
    clear JI
end
clear p
 
% average and std dev of similarities
p = 1;
for p = 1:num_combinations
    list_comb(p,4) = mean(list_comb(p,3));
    list_comb(p,5) = std(list_comb(p,3));
end
clear p
 
% calculate pairs of unique average-std dev values
stats_list_comb(:,1) = unique(list_comb(:,4),'stable');
stats_list_comb(:,2) = unique(list_comb(:,5),'stable');
 
%%% I need a symmetric matrix to identify identical vectors (i.e. tests that
% produce the same flux/metabolic space solution) -> average of JIs (not
% actual flux values!)
ave_matrix = zeros(succ_runs,succ_runs);
for i = 1:size(list_comb,1)
    ave_matrix(list_comb(i,1),list_comb(i,2)) = list_comb(i,4);
    ave_matrix(list_comb(i,2),list_comb(i,1)) = list_comb(i,4);
end
space_solutions = unique(ave_matrix(:,:),'rows','stable');
identification_test = zeros(succ_runs,size(space_solutions,1)); % rows are the test number, column the case of space solution
for i = 1:size(space_solutions,1)
    for j = 1:succ_runs
        tmp = space_solutions(i,:) - ave_matrix(j,:);
        if tmp == 0
            identification_test(j,i) = 1;
        end
        clear tmp
    end
end
pre_identification_conc_est = [index_succ(1:succ_runs,2) identification_test];
identification_conc_est = zeros(size(pre_identification_conc_est,1),2);
identification_conc_est(:,1) = pre_identification_conc_est(:,1);
for i = 1:(size(pre_identification_conc_est,2)-1)
    j = 0;
    for j = 1:size(pre_identification_conc_est,1)
        if pre_identification_conc_est(j,i+1) == 1
           identification_conc_est(j,2) = i
        end
    end    
end
 
clear num_mod_round_succ_conc_est
clear mean_conc_est_all
clear flag_conc_est_all
clear clean_conc_est_all
clear succ_runs
clear num_combinations
clear list_comb
clear stats_list_comb
clear ave_matrix
clear space_solutions
clear identification_test
clear pre_identification_conc_est
 

% 
%%%5) Two solutions are assumed to be the same when the concentration values % are the same. In order to reduce the effect of numerical artifacts, let's round the number to the 5th decimal
num_mod_round_succ_match_conc = cell2mat(mod_round_succ_match_conc(:,2:end));
 
% generate new matrices without rows that are always 0
mean_match_conc_all = zeros(size(num_mod_round_succ_match_conc,1),1);
for i = 1:size(mean_match_conc_all,1)
    mean_match_conc_all(i,1) = mean(num_mod_round_succ_match_conc(i,:));
end
flag_match_conc_all = ones(size(num_mod_round_succ_match_conc,1),1);
for i = 1:size(flag_match_conc_all,1)
    if mean_match_conc_all(i,1) == 0
        flag_match_conc_all(i,1) = 0;
    end         
end
clean_match_conc_all = zeros(nnz(flag_match_conc_all),size(num_mod_round_succ_match_conc,2));
j = 1;
for i=1:size(num_mod_round_succ_match_conc,1)
    if flag_match_conc_all(i,1) == 1
        clean_match_conc_all(j,:) = num_mod_round_succ_match_conc(i,:);
        j = j + 1;
    end
end
clear j
 
%%% Now we analyse the similarities
% number of succesful runs
succ_runs = size(clean_match_conc_all,2)
num_combinations = 0;
for p = 1:succ_runs
num_combinations = num_combinations + p;
end
clear p
 
list_comb = zeros(num_combinations,2); % combination of this list against itself
p = 1;
r = 1;
while p <= succ_runs
    for q = p:succ_runs
        list_comb(r,1) = p;
        list_comb(r,2) = q;
        r = r + 1;
    end
p = p + 1;
end
clear p
clear q
clear r
 
% now we calculate the Jaccard index for every combination
p = 1;
for p = 1:num_combinations
    X = [clean_match_conc_all(:,list_comb(p,1)) clean_match_conc_all(:,list_comb(p,2))]';
    JD = pdist(X,'jaccard');
    JI = 1 - JD;
    list_comb(p,3) = JI;
        
    clear X
    clear JD
    clear JI
end
clear p
 
% average and std dev of similarities
p = 1;
for p = 1:num_combinations
    list_comb(p,4) = mean(list_comb(p,3));
    list_comb(p,5) = std(list_comb(p,3));
end
clear p
 
% calculate pairs of unique average-std dev values
stats_list_comb(:,1) = unique(list_comb(:,4),'stable');
stats_list_comb(:,2) = unique(list_comb(:,5),'stable');
 
%%% I need a symmetric matrix to identify identical vectors (i.e. tests that
% produce the same flux/metabolic space solution) -> average of JIs (not
% actual flux values!)
ave_matrix = zeros(succ_runs,succ_runs);
for i = 1:size(list_comb,1)
    ave_matrix(list_comb(i,1),list_comb(i,2)) = list_comb(i,4);
    ave_matrix(list_comb(i,2),list_comb(i,1)) = list_comb(i,4);
end
space_solutions = unique(ave_matrix(:,:),'rows','stable');
identification_test = zeros(succ_runs,size(space_solutions,1)); % rows are the test number, column the case of space solution
for i = 1:size(space_solutions,1)
    for j = 1:succ_runs
        tmp = space_solutions(i,:) - ave_matrix(j,:);
        if tmp == 0
            identification_test(j,i) = 1;
        end
        clear tmp
    end
end
pre_identification_match_conc = [index_succ(1:succ_runs,2) identification_test];
identification_match_conc = zeros(size(pre_identification_match_conc,1),2);
identification_match_conc(:,1) = pre_identification_match_conc(:,1);
for i = 1:(size(pre_identification_match_conc,2)-1)
    j = 0;
    for j = 1:size(pre_identification_match_conc,1)
        if pre_identification_match_conc(j,i+1) == 1
           identification_match_conc(j,2) = i
        end
    end    
end
 
clear num_mod_round_succ_match_conc
clear mean_match_conc_all
clear flag_match_conc_all
clear clean_match_conc_all
clear succ_runs
clear num_combinations
clear list_comb
clear stats_list_comb
clear ave_matrix
clear space_solutions
clear identification_test
clear pre_identification_match_conc
 
% matrix unifying results
uni_non_redundant = zeros(size(identification_test_FBA,1),6);
uni_non_redundant(:,1) = identification_test_FBA(:,1); % test number
uni_non_redundant(:,2) = identification_test_FBA(:,2);
uni_non_redundant(:,3) = identification_test_TFA(:,2);
uni_non_redundant(:,4) = identification_test_TFA_normalized(:,2);
uni_non_redundant(:,5) = identification_conc_est(:,2);
uni_non_redundant(:,6) = identification_match_conc(:,2);

% also and parameter level from binary codification
for i =1:size(uni_non_redundant,1)
    tmp_run = uni_non_redundant(i,1)
    for j = 1:size(full_tests)
        tmp_test = full_tests(j,1)
        if tmp_run == tmp_test
            uni_non_redundant(i,7) = correlation_coef_13C_TFA(j,1);
            uni_non_redundant(i,8) = correlation_coef_metabolomics(j,1);
            uni_non_redundant(i,9) = full_tests(j,2);
            uni_non_redundant(i,10) = full_tests(j,3);
            uni_non_redundant(i,11) = full_tests(j,4);
            uni_non_redundant(i,12) = full_tests(j,5);
            uni_non_redundant(i,13) = full_tests(j,6);
            uni_non_redundant(i,14) = full_tests(j,7);
        end
    end
end

% [coeff,score,latent] = pca(uni_non_redundant)
% Xcentered = score*coeff'
% biplot(coeff(:,1:2),'scores',score(:,1:2),'varlabels',{'v_1','v_2','v_3','v_4','v_5','v_6'}); 

%% Clustering
%  t_match_conc = cell2mat(mod_round_succ_match_conc(:,2:end))
 Y = pdist(t_match_conc)
 Z = linkage(Y)
 
 %% pattern analysis for non redundant central C TFA fluxes
 
 %% calculate centrality for non redundant TFA solutions
 num_nnred_TFA = unique(identification_test_TFA(:,2));
 % pick a flux distribution representing each non redundant solution
 % 1st column: run number; 2nd column: run position when ignoring failed
 % ones
 rep_sol = []
 for i = 1:size(num_nnred_TFA,1)
     tmp_sol = num_nnred_TFA(i,1);
     identification_test_TFA(:,2) == tmp_sol;
     tmp_inx = ans;
     find(tmp_inx==1);
     tmp_inw = ans;
     rep_sol = [rep_sol; identification_test_TFA(tmp_inw(1,1),1)];
 end
 clear tmp_sol
 clear identification_test_TFA
 clear tmp_inx
 clear tmp_inw
 
 
 %% NEED to 'recover' the gamma_model. What happens when a run fails, how does it affect the stored_gamma and the indexing?
 % recover the correct run by means of index_succ, which shows the ordering
 % without considering failed runs
 rep_sol_codex = (zeros(size(rep_sol,1),2));
 rep_sol_codex(:,1) = (rep_sol);
 for i = 1:size(rep_sol_codex,1)
     tmp_rep = rep_sol(i,1)
     for j = 1:size(index_succ,1)
         tmp_succ = index_succ(j,2)
         if tmp_rep == tmp_succ
             rep_sol_codex(i,2) = index_succ(j,1);
         end
     end
 end
fns = fieldnames(stored_gamma_model);
clear i

indx_pg = [rep_sol_codex(:,2)];
testArray = sprintfc('%02d', indx_pg)';
for i = 1:numel(testArray)
node_pagerank{i} = matlab.lang.makeValidName(strcat('node_pagerank_',testArray{i}));
end    
clear i

%%
 for num_model = 1:size(rep_sol_codex,1)
    num_gamma_model = rep_sol_codex(num_model,2);
    gamma_model = stored_gamma_model.(fns{num_gamma_model});
    TFA_NF_fluxes_cell_this = TFA_NF_fluxes_cell(:,(rep_sol_codex(num_model,1))+1);
     
    % First, it is necessary to obtain a 'clean' binary S
    % list of active rxns (non zero NF)
%     varNames = gamma_model.varNames;
%     NF_rxns_flag = startsWith(varNames, 'NF_');
    NF_rxns_num = size(TFA_NF_fluxes_cell_this,1);

    NF_rxns_list = num2cell(zeros(NF_rxns_num, 5));
    NF_rxns_list(:,1) = strip(TFA_NF_fluxes_cell(:,1),'left','N');
    NF_rxns_list(:,1) = strip(NF_rxns_list(:,1),'left','F');
    NF_rxns_list(:,1) = strip(NF_rxns_list(:,1),'left','_');
    NF_rxns_list(:,2) = (TFA_NF_fluxes_cell_this);
    % we consider numbers e-14 to be numerical artifact, so change it to 0
    tmp = cell2mat(NF_rxns_list(:,2));

    for i = 1:NF_rxns_num
        if tmp(i) > 0
            if tmp(i) < 1e-13
                tmp(i) = 0;
            end
        elseif tmp(i) < 0
            if tmp(i) > -1e-13
                tmp(i) = 0;
            end
        end
    end

    NF_rxns_list(:,3) = num2cell(tmp);
    clear tmp

    % In an edge list for a directed graph, the edge goes from the first node
    % to the second. Since some NF are negative, a correction factor will be
    % necessary later when generating the binary S (saved independently)
    tmp = cell2mat(NF_rxns_list(:,4));

    for i = 1:NF_rxns_num
        if tmp(i) > 0
            tmp(i) = 1;
        elseif tmp(i) < 0
            tmp(i) = -1;
        else
            tmp(i) = 0;
        end
    end

    NF_rxns_list(:,4) = num2cell(tmp);
    NF_rxns_list(:,5) = printRxnFormula(gamma_model);
    clear tmp

    % now we start modifying the stoichiometric matrix
    S = gamma_model.S;
    S_corr_direc = S;

    for i = 1:NF_rxns_num
        if cell2mat(NF_rxns_list(i,5)) == -1
            S_corr_direc(:,i) = -1*S_corr_direc(:,i);
        end
    end
    clear i
    % we need to remove rxns that are not active
    null_rxns = ones(NF_rxns_num,1);

    for i = 1:NF_rxns_num
        if cell2mat(NF_rxns_list(i,5)) == 0
            null_rxns(i,:) = 0;
        end
    end
    clear i
    list_rxns(:,1) = gamma_model.rxns;
    list_rxns(:,2) = num2cell(null_rxns);
    list_rxns(:,3) = num2cell(1:size(list_rxns,1)); % keep track of the original num
    
    % export active rxns
    S_corr_direc_non_null_rxns = zeros(size(S_corr_direc,1),nnz(null_rxns));

    j = 1;
    for i = 1:NF_rxns_num
        if null_rxns(i) == 1 %therefore active, either FW or RV
            S_corr_direc_non_null_rxns(:,j) = S_corr_direc(:,i);
            list_rxns_active(j,1) = list_rxns(i,1);
            list_rxns_active(j,2) = list_rxns(i,2); 
            list_rxns_active(j,3) = list_rxns(i,3);
            j = j + 1;
        end
    end
    clear i
    clear j

    % identify metabolites that do not participate in any of the active
    % reactions. If a met is inactive, then the sum of the row must be zero
    num_met_S_corr_direc_non_null_rxns = size(S_corr_direc_non_null_rxns,1);
    num_rxn_S_corr_direc_non_null_rxns = size(S_corr_direc_non_null_rxns,2);
    active_met_S_corr_direc_non_null_rxns = zeros(num_met_S_corr_direc_non_null_rxns,1);

    for i = 1:num_met_S_corr_direc_non_null_rxns
        active_met_S_corr_direc_non_null_rxns(i,1) = nnz(S_corr_direc_non_null_rxns(i,:));
    end
    clear i

    % we need to remove mets that are not active
    null_mets = ones(num_met_S_corr_direc_non_null_rxns,1);

    for i = 1:num_met_S_corr_direc_non_null_rxns
        if active_met_S_corr_direc_non_null_rxns(i,1) == 0 % therefore inactive
            null_mets(i,:) = 0;
        end
    end
    clear i

    list_mets(:,1) = gamma_model.mets;
    list_mets(:,2) = num2cell(null_mets);

    % export S with both active rxns and mets
    S_clean = zeros(nnz(null_mets),nnz(null_rxns));

    j = 1;
    for i = 1:num_met_S_corr_direc_non_null_rxns
        if null_mets(i) == 1 %therefore active
            S_clean(j,:) = S_corr_direc_non_null_rxns(i,:);
            list_mets_active(j,1) = list_mets(i,1);
            list_mets_active(j,2) = list_mets(i,2);  
            j = j + 1;
        end
    end
     clear i
     clear j

    list_mets_final = list_mets_active
    
    test_active_rxns = ones(1,size(S_clean,2));
    for i = 1:num_rxn_S_corr_direc_non_null_rxns
        test_active_rxns(1,i) = nnz(S_clean(:,i));
    end
    nnz(test_active_rxns)
    clear i

    test_active_mets = ones(size(S_clean,1),1);
    for i = 1:size(S_clean,1)
        test_active_mets(i,1) = nnz(S_clean(i,:));
    end
    nnz(test_active_mets)
    clear i

    % more cleaning
    % for the sake of simplicity, we could remove all
    % demand/transport/spontaneous reactions (but we are not; all fields
    % will be '1', and there nothing will be changed here)
for i = 1:size(list_rxns_active, 1)
   list_rxns_active(i,4) = num2cell(~endsWith(list_rxns_active(i,1),'abcpp','IgnoreCase',false)); % tagged with 0 (changed vector with '~')
   list_rxns_active(i,5) = num2cell(~endsWith(list_rxns_active(i,1),'pp','IgnoreCase',false));
   list_rxns_active(i,6) = num2cell(1);
   list_rxns_active(i,7) = num2cell(~endsWith(list_rxns_active(i,1),'tex','IgnoreCase',false));
   list_rxns_active(i,8) = num2cell(~endsWith(list_rxns_active(i,1),'tonex','IgnoreCase',false));
   list_rxns_active(i,9) = num2cell(~endsWith(list_rxns_active(i,1),'tpp','IgnoreCase',false));
   list_rxns_active(i,10) = num2cell(~startsWith(list_rxns_active(i,1),'DM_','IgnoreCase',false));
end
clear i

    j = 1;
    for i = 1:size(S_clean,2)
        if cell2mat(list_rxns_active(i,4)) == 1 && cell2mat(list_rxns_active(i,5)) == 1 && cell2mat(list_rxns_active(i,6)) == 1 && cell2mat(list_rxns_active(i,7)) == 1 && cell2mat(list_rxns_active(i,8)) == 1 && cell2mat(list_rxns_active(i,9)) == 1 && cell2mat(list_rxns_active(i,10)) == 1 
            S_clean_1b(:,j) = S_clean(:,i);
            list_rxns_active_1b(j,1) = list_rxns_active(i,1);
            list_rxns_active_1b(j,2) = list_rxns_active(i,2); 
            list_rxns_active_1b(j,3) = list_rxns_active(i,3);
            j = j + 1;
        end
    end
    clear i
    clear j
    
    S_clean_final = S_clean_1b;
    
    try
        list_rxns_final = list_rxns_active_1b;
    end
    
    % for the sake of simplicity, flag and remove extracellular, periplasmic
    % and currency metabolites, as well as the ones that are not active in the
    % previous matrix

    for i = 1:size(list_mets_active, 1)
       list_mets_active(i,3) = num2cell(~endsWith(list_mets_active(i,1),'_e','IgnoreCase',false));
       list_mets_active(i,4) = num2cell(~endsWith(list_mets_active(i,1),'_p','IgnoreCase',false));
    end

    list_mets_active(:,5) = num2cell(ones((size(list_mets_active, 1)),1));
    for i = 1:size(list_mets_active, 1)
       list_mets_active(i,3) = num2cell(~endsWith(list_mets_active(i,1),'_e','IgnoreCase',false));
       list_mets_active(i,4) = num2cell(~endsWith(list_mets_active(i,1),'_p','IgnoreCase',false));
       % label with 0 if fulfils the condition
       side_compounds = {'2dmmql8_c'; '2fe1s_c'; '2fe2s_c'; '3fe4s_c'; '3hcpalm9eACP_c'; '3hmrsACP_c'; '3ocpalm9eACP_c'; '3omrsACP_c'; '4fe4s_c'; '6hmhpt_c'; '6hmhptpp_c'; 'ACP_c'; 'adocbl_c'; 'adp_c'; 'ahdt_c'; 'amp_c'; 'aps_c'; 'atp_c'; 'bmoco_c'; 'bmoco1gdp_c'; 'bmocogdp_c'; 'ca2_c'; 'cbl1_c'; 'cbp_c'; 'cdp_c'; 'cl_c'; 'cmp_c'; 'co2_c'; 'coa_c'; 'cobalt2_c'; 'cpmp_c'; 'ctp_c'; 'cu2_c'; 'ddcaACP_c'; 'dhpmp_c'; 'dnad_c'; 'dpcoa_c'; 'dscl_c'; 'egmeACP_c'; 'epmeACP_c'; 'fad_c'; 'fadh2_c'; 'fe2_c'; 'fe3_c'; 'flxr_c'; 'flxso_c'; 'fmn_c'; 'gdp_c'; 'glyc_c'; 'glycogenn1_c'; 'gmeACP_c'; 'gmp_c'; 'grxox_c'; 'grxrd_c'; 'gtp_c'; 'h_c'; 'h2o_c'; 'h2o2_c'; 'h2s_c'; 'hco3_c'; 'hdeACP_c'; 'hemeO_c'; 'hgmeACP_c'; 'hpmeACP_c'; 'iscs_c'; 'iscssh_c'; 'iscu_c'; 'iscu-2fe2s_c'; 'iscu-2fe2s2_c'; 'iscu-4fe4s_c'; 'k_c'; 'lipopb_c'; 'malACP_c'; 'meoh_c'; 'mg2_c'; 'mn2_c'; 'moadamp_c'; 'moadcoo_c'; 'moadcosh_c'; 'mobd_c'; 'moco_c'; 'mococdp_c'; 'mocogdp_c'; 'mpt_c'; 'mptamp_c'; 'mql8_c'; 'myrsACP_c'; 'na1_c'; 'nad_c'; 'nadh_c'; 'nadp_c'; 'nadph_c'; 'nh4_c'; 'ni2_c'; 'nicrnt_c'; 'o2_c'; 'ocACP_c'; 'octapb_c'; 'octeACP_c'; 'ogmeACP_c'; 'opmeACP_c'; 'palmACP_c'; 'pap_c'; 'paps_c'; 'pi_c'; 'pimACP_c'; 'pmeACP_c'; 'ppi_c'; 'pppi_c'; 'q8_c'; 'q8h2_c'; 'quln_c'; 'scl_c'; 'sheme_c'; 'so3_c'; 'so4_c'; 't3c9palmeACP_c'; 'tdeACP_c'; 'thf_c'; 'trdox_c'; 'trdrd_c'; 'udp_c'; 'ump_c'; 'zn2_c'; 'thmmp_c'; 'thmpp_c'; 'dtdp_c'; 'dttp_c'; 'dtmp_c'; 'imp_c'; 'pydx5p_c'; 'pdx5p_c'; 'pydxn_c'; 'gthrd_c'; 'gthox_c'; 'pyam5p_c'; 'pydam_c'; 'pydx_c'};
       j = 1;
       for j = 1:size(side_compounds,1)
        if cell2mat(strfind(list_mets_active(i,1),side_compounds(j,1))) == 1
            list_mets_active(i,5) = num2cell(0);
        end
       end   
    end
    clear i
    
    try
    j = 1;
    for i = 1:size(S_clean_1b,1)
        if cell2mat(list_mets_active(i,3)) == 1 && cell2mat(list_mets_active(i,4)) == 1 && cell2mat(list_mets_active(i,5)) == 1 %therefore intracellular
            S_clean_1c(j,:) = S_clean_1b(i,:);
            list_mets_active_1b(j,1) = list_mets_active(i,1);
            list_mets_active_1b(j,2) = list_mets_active(i,2); 
            j = j + 1;
        end
    end
    clear i
    clear j
    list_mets_final = list_mets_active_1b;

    % now check for active rxns
    % another cycle checking for active reactions is then necessary
    num_rxn_S_clean_1c = size(S_clean_1c,2);
    active_rxn_S_clean_1c = zeros(1,num_rxn_S_clean_1c);
    for i = 1:num_rxn_S_clean_1c
        active_rxn_S_clean_1c(1,i) = nnz(S_clean_1c(:,i));
    end
    clear i
    
    null_rxns_1c = ones(num_rxn_S_clean_1c,1);
    for i = 1:num_rxn_S_clean_1c
        if active_rxn_S_clean_1c(1,i) == 0
            null_rxns_1c(i,:) = 0; % inactive
        end
    end

    if nnz(~null_rxns_1c) == 0 
        disp('no more cleaning steps are necessary')
        S_clean_final = S_clean_1c;
    else
        disp('more cleaning steps ARE necessary')
        %return
    end

    % cleaning again
    S_clean_2 = zeros(size(S_clean_1c,1),nnz(null_rxns_1c));

    j = 1;
    for i = 1:size(null_rxns_1c,1)
        if null_rxns_1c(i) == 1 %therefore active
            S_clean_2(:,j) = S_clean_1c(:,i);
            list_rxns_active_2(j,1) = list_rxns_active_1b(i,1);
            list_rxns_active_2(j,2) = list_rxns_active_1b(i,2);
            list_rxns_active_2(j,3) = list_rxns_active_1b(i,3);
            j = j + 1;
        end
    end
    clear i
    clear j
    % if list_rxns_active_2 was generated, then overwrite the previous list  
    try
        list_rxns_final = list_rxns_active_2; 
    end
    test_active_rxns_2 = ones(1,size(S_clean_2,2));
    for i = 1:size(S_clean_2,2)
        test_active_rxns_2(1,i) = nnz(S_clean_2(:,i));
    end
    nnz(test_active_rxns_2)
    clear i

    test_active_mets_2 = ones(size(S_clean_2,1),1);
    for i = 1:size(S_clean_2,1)
        test_active_mets_2(i,1) = nnz(S_clean_2(i,:));
    end
    nnz(test_active_mets_2)
    clear i

    if nnz(test_active_rxns_2) ~= size(test_active_rxns_2,2) || nnz(test_active_mets_2) ~= size(test_active_mets_2,1)
        disp('more cleaning steps ARE necessary')
        S_clean_2b = zeros((nnz(test_active_mets_2)),size(S_clean_2,2));
        j = 1;
        for i = 1:size(test_active_mets_2,1)
            if test_active_mets_2(i) ~= 0 %therefore active
                S_clean_2b(j,:) = S_clean_2(i,:);
                list_mets_active_2(j,1) = list_mets_active_1b(i,1);
                list_mets_active_2(j,2) = list_mets_active_1b(i,2);   
                j = j + 1;
            end
        end
        clear i
        test_active_rxns_2b = ones(1,size(S_clean_2b,2));
        for i = 1:size(S_clean_2b,2)
            test_active_rxns_2b(1,i) = nnz(S_clean_2b(:,i));
        end
        nnz(test_active_rxns_2b)

        test_active_mets_2b = ones(size(S_clean_2b,1),1);
        for i = 1:size(S_clean_2b,1)
            test_active_mets_2b(i,1) = nnz(S_clean_2b(i,:));
        end
        nnz(test_active_mets_2b)
        clear i
    else
        S_clean_final = S_clean_2;
    end
    
    try
        if nnz(test_active_rxns_2b) ~= size(test_active_rxns_2b,2) || nnz(test_active_mets_2b) ~= size(test_active_mets_2b,1)
            disp('more cleaning steps ARE necessary')
            %return
        else
            S_clean_final = S_clean_2b;
        end
    
    catch
    end
    
    % if list_mets_active_2 was generated, then overwrite the previous list 
    try
     list_mets_final = list_mets_active_2;    
    end

    % in Palsson's framework, biomass is not modelled as a sink (as opposed to
    % Fell's), so biomass precursors are generated and 'going nowhere'. Thus,
    % the biomass reaction will be modified and a pseudometabolite 'biomass'
    % created. We need to add an extra row and a sij for it:
    S_clean_final_biomass = [S_clean_final; zeros(1,size(S_clean_final,2))];
    pre_id_biomass_rxn = strcmp({'Ec_biomass_iJO1366_WT_53p95M'}, list_rxns_active_2(:,1));
    id_biomass_rxn = find(pre_id_biomass_rxn > 0);
    S_clean_final_biomass(size(S_clean_final_biomass,1),id_biomass_rxn) = 1;

    % Obtain adjacency matrix
    % at this point I have a clean matrix with corrected directionalities (so
    % that thermodynamically speaking, the negative stoichiometric coefficients
    % denote the subtrates, and the positives the products). Need to generate a
    % binary matrix (only 0/1 entries are allowed) to finally calculate the
    % adjacency matrix (Ax)

    % for an undirected graph, Ax can be calculated as the product of S_bin *
    % (S_bin)^t. This yields a symmetric Ax. The problem is that for directed
    % graphs (as our case) Ax is not necessarily symmetric. Since matlab does
    % not offer a way to translate S into Ax, we have to improvise. We are
    % going to 'sweep' each row of S_clean to find the indeces of substrates
    % and products and use them as 'coordinates' for Ax. In this sense, there
    % is no real need for a binary matrix, 

    % using 'find' function to obtain the indices
    % Edges = (source node, target node)
    % the index for the substrate denotes the row number of the edge, whereas
    % the index for the product denotes the column number (in Ax)
    % the number of combinations (for reactions with more than 1S and 1P)
    % equals the product of negative and positive stoichiometric coefficients
    % the 'edge' number (1 normally) has to be added up to the previous value
    % (0 default), because there may be more than one edge between two nodes

    % the adjacency matrix will have dimensions of (number of metabolites,
    % number of metabolites). We are going to 'sweep' each row of S to 
    % find the indeces of substrates and products and use them as 'coordinates' 
    % for Ax (where the met with the negative stoichiometric coefficient is the
    % substrate, and therefore the source node, and denotes the 'row'
    % coordinate, and the product is the met with the positive coeff, and
    % therefore the target node and denotes the 'column' coordinate)
    % the total number of edges corresponding to 1 reaction equals number of S
    % * number of P

    % it will be easier just to get an edge list to directly build G (no binary
    % matrix necessary)
    adjacency_matrix = zeros(size(S_clean_final_biomass,1),size(S_clean_final_biomass,1));

    for i = 1:size(S_clean_final_biomass,2)
        tmp_column = S_clean_final_biomass(:,i);
        tmp_subs = find(tmp_column < 0);
        tmp_prods = find(tmp_column > 0);

        for si = 1:size(tmp_subs,1)
            for pi = 1:size(tmp_prods,1)
                adjacency_matrix(tmp_subs(si,1),tmp_prods(pi,1)) = adjacency_matrix(tmp_subs(si,1),tmp_prods(pi,1)) + 1;
            end
        end

        clear tmp_column
        clear tmp_subs
        clear tmp_prods
        clear tmp_num_comb    
    end

    % Plot PageRank
    node_names = list_mets_active_2(:,1);
    node_names(size(node_names,1)+1) = {'biomass'};
    G = digraph(adjacency_matrix,node_names,'omitselfloops');
    n = numnodes(G);
    D = outdegree(G,node_names); % let's calculate the outdegree to obtain nodesize proportional to it
    D_mod = D + 3; % since some nodes have and outdegree of 0 (and size cannot be 0), we shift all the values by 1
   
    P = plot(G,'Layout','layered');
    P.ArrowSize = 5;
    P.EdgeColor = [0.201 0.201 0.201];
    P.LineWidth = G.Edges.Weight;
    P.MarkerSize = D_mod;
    pagerank_weight = centrality(G,'pagerank','Importance',G.Edges.Weight);
    P.NodeCData = pagerank_weight;
    P.NodeLabel = node_names;
    
    %%%% need MATLAB 2017b 
%     % only label compounds in the top 10% 
%     [val,indx_top10] = maxk(pagerank_weight,round(0.10*size(pagerank_weight,1)))
%     nm = num2cell(zeros(size(node_names,1),size(node_names,2)));
%     nm(:,1) = cellstr('.');
%     for i = 1:size(indx_top10,1)
%         tmp_i = indx_top10(i,1);
%         tmp_name = node_names(tmp_i,1);
%         nm(tmp_i) = tmp_name;
%     end
%     P.NodeLabel = nm;
%     %%%%%%
%     
    % Sequential colour palette
    % we exclude biomass for colouring purposes (label it in black)
    pseudo_pagerank_weight = pagerank_weight(1:end-1);
    c1 = [225 243 246]; 
    c2 = [4 112 47]; 
    depth = 2*n;
    colour_sequential = colorGradient(c1,c2,depth);
    colour_sequential(:,4) = linspace(min(pseudo_pagerank_weight),max(pseudo_pagerank_weight),depth);
    colour_original = colour_sequential(:,1:3)
    clear c1
    clear c2
    clear depth

    % we need to play around with the data to make sure there is a correct link
    % between centrality value and colour from the gradient!
    tmp_abs_differences = zeros(size(node_names,1)-1,1);
    pagerank_color_codex = zeros(size(pseudo_pagerank_weight,1),2);

    for i = 1:(n-1)
        tmp_abs_differences = abs(pseudo_pagerank_weight(i) - colour_sequential(:,4));
        [~,I] = min(tmp_abs_differences);
        color_position = I(1,1); % in case there are more than one (which would be neighbours), take the first
        pagerank_color_codex(i,1) = pseudo_pagerank_weight(i);
        pagerank_color_codex(i,2) = color_position;
        clear tmp_pagerank_weight
        clear I
        clear color_position
    end

    colour_sequential_corrected = zeros(n-1,3);
    for i = 1:(n-1)
        tmp_index = pagerank_color_codex(i,2)
        colour_sequential_corrected(i,:) = colour_sequential(tmp_index,1:3);
    end

    colour_sequential_corrected_biomass = [colour_sequential_corrected; 0 0 0];
    colour_sequential_corrected_sorted = sort(colour_sequential_corrected,'descend');

    P.NodeColor = colour_sequential_corrected_biomass;
    colormap(colour_original);
    % colorbar
    title('PageRank')
    % 
    h = colorbar;
    set(h, 'ylim', [min(pseudo_pagerank_weight) max(pseudo_pagerank_weight)])

    % identify nodes with no predecessors
    original_nodes = [];

    for i = 1:n
        preIDs = predecessors(G,node_names(i));
        if isempty(preIDs)  
            original_nodes = [original_nodes; node_names(i)];
        end
        clear preIDs
    end
 
    this_pagerank = node_names(1:end-1);
    this_pagerank(:,2) = num2cell(pseudo_pagerank_weight);
    stored_node_pagerank.(node_pagerank{num_model}) = this_pagerank
    clear this_pagerank
 end
 end











