function [D]=density_sw(t,S)
%
% Created by Thomas Millat, University of Nottingham
% Email: thomas.millat@nottingham.ac.uk

% DENSITY_SW computes the density of salt water as a function of salinity
% and temperature
%
% This function applies an internationally accepted equation of state of
% sea water published by Siedler and Peters 1986 (Siedler1986). Here, we 
% use the equation of state for a pressure of one standard atmosphere which
% corrects the pure water reference by salinity contributions.
%
%   D = Dw
%      + (a1+a2*t+a3*t^2+a4*t^3+a5*t^4)*S
%      + (b1+b2*t+b3*t^2)*S^(3/2)
%      + c1*S^2
%
%   with the pure water reference value
%
%   Dw = d1+d2*t+d3*t^2+d4*t^3+d5*t^4+d6*t^5
%
% Range of validity:
%   0<=S<=42
%   -2<=T<=40
%
% The function calculates the matrixes D(t,S) and Dw(t)

% Check Number of Input Arguments
% switch nargin
%     case 0
%         t=25;
%         S=0;
%         warning('density_sw:argChk','Assuming t=25 and S=0');
%     case 1
%         S=0;
%         warning('density_sw:argChk','Assuming S=0');
%     case 2
%         % all arguments provided
%     otherwise
%         error('density_sw:argChk','Too many input arguments')
% end

% Check input arguments
size_t=size(t);
size_S=size(S);
if min(size_t)*min(size_S)>1
    error('density_sw:argChk','Arguments must be vectors');
end
if size_t(2)>1
    t=transpose(t);
end
if size_S(1)>1
    S=transpose(S);
end

% constants
a(1)=8.24493e-1;
a(2)=-4.0899e-3;
a(3)=7.6438e-5;
a(4)=-8.2467e-7;
a(5)=5.3875e-9;

b(1)=-5.72466e-3;
b(2)=1.0227e-4;
b(3)=-1.6546e-6;

c(1)=4.8314e-4;

% reference value for pure water
DH2O=densityH2O(t);

% create matrices
t=t(:,ones(1,length(S)));
DH2O=DH2O(:,ones(1,length(S)));
S=S(ones(length(t),1),:);

% Salinity correction
st1=(a(1)+a(2).*t+a(3).*(t.^2)+a(4).*(t.^3)+a(5).*(t.^4)).*S;
st2=(b(1)+b(2).*t+b(3).*(t.^2)).*sqrt(S.^3);
st3=c(1).*(S.^2);

D=DH2O+st1+st2+st3;