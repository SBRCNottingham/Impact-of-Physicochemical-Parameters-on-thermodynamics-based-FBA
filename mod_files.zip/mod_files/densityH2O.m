function [D,D1,D2]=densityH2O(t)
%
% Created by Thomas Millat, University of Nottingham
% Email: thomas.millat@nottingham.ac.uk

% DENSITY_SW computes the density of pure water as a function of 
% temperature
%
% This function applies an internationally accepted equation of state of
% sea water published by Siedler and Peters 1986 (Siedler1986). Here, we 
% use the equation of state for a pressure of one standard atmosphere which
% corrects the pure water reference by salinity contributions.
%
%   Dw = d1+d2*t+d3*t^2+d4*t^3+d5*t^4+d6*t^5
%
% Range of validity:
%   -2<=T<=40
%
% The function calculates the vector Dw(t)

% Check Number of Input Arguments
switch nargin
    case 0
        t=25;
        warning('density_sw:argChk','Assuming t=25 deg Celsius');
    case 1
        % all arguments provided
        size_t=size(t);
        if min(size_t)>1
            error('density_sw:argChk','Arguments must be vectors');
        elseif size_t(2)>1
            t=transpose(t);
        end
    otherwise
        error('density_sw:argChk','Too many input arguments')
end

% constants

d(1)=999.842594;
d(2)=6.793952e-2;
d(3)=-9.095290e-3;
d(4)=1.001685e-4;
d(5)=-1.120083e-6;
d(6)=6.536332e-9;

% density for pure water
D=d(1)+(d(2)+(d(3)+(d(4)+(d(5)+d(6).*t).*t).*t).*t).*t;

% first derivatie with respect to temperature
D1=d(2)+(2*d(3)+(3*d(4)+(4*d(5)+5*d(6).*t).*t).*t).*t;

% second derivative with respect to temperature
D2=2*d(3)+(6*d(4)+(12*d(5)+20*d(6).*t).*t).*t;