function [eps,eps1,eps2]=permittivityH2O(t)
% PERMITTIVITYH2O computes the temperature-dependent static permittivity
% (dielectric constant) for pure water and the first and second derivative
% with respect to temperature t. Note that the fitting function uses the
% temperature in deg Celsius instead of the absolute temperature T
%
% The program encodes a fit function to experimental data suggested in
% Meissner (2004), IEEE T. Geosci. Remote
%
%           3.70886e4 - 8.2168e1*t
%   eps(t)=------------------------
%                4.21854e2+t

% Check Input Arguments
switch nargin
    case 0
        t=25;
        warning('permittivityH2O:argChk','Assuming t=25');
    case 1
        size_t=size(t);
        if min(size_t)>1
            error('permittivityH2O:argChk','Argument must be a vector');
        elseif size_t(2)>1
            t=transpose(t);
        end
    otherwise
        error('permittivityH2O:argChk','Too many arguments');
end

% constants
a(1)=3.70886e4;
a(2)=8.2168e1;
a(3)=4.21854e2;

% static permittivity
nom=a(1)-a(2).*t;
denom=a(3)+t;
eps=nom./denom;

% first derivative with respect to temperature
nom1=a(2)*a(3)-a(1);
denom1=denom.^2;
eps1=nom1./denom1;

% second derivatice with respect to temperature
nom2=-2*(a(2)*a(3)-a(1));
denom2=denom.^3;
eps2=nom2./denom2;

% end of function
end