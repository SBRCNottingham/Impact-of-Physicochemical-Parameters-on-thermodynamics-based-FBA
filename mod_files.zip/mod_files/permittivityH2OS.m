function epss=permittivityH2OS(t,S)
% PERMITTIVITYH2O computes the temperature-dependent static permittivity
% (dielectric constant) for water with dissolved salt. The temperature is
% given in Celsius.
%
% The program encodes a fit function to experimental data suggested in
% Meissner (2004), IEEE T. Geosci. Remote, for sea water. It corrects the
% permittivity of pure water for the given salinity in parts per thousand
%
%   epss(T)= eps(t) * exp[b0*s + b1*s^2 + b2*t*s]

% Check Number of Input Arguments
switch nargin
    case 0
        t=25;
        S=0;
        warning('permittivityH2O:argChk','Assuming t=25 and S=0');
    case 1
        S=0;
        warning('permittivityH2O:argChk','Assuming S=0');
    case 2
        % ok
    otherwise
        error('permittivityH2O:argChk','Too many arguments');
end

% Check Input Arguments
size_t=size(t);
size_S=size(S);
if min(size_t)*min(size_S)>1
    error('permittivityH2O:argChk','Arguments must be vectors');
end
if size_t(2)>1
    t=transpose(t);
end
if size_S(1)>1
    S=transpose(S);
end

% constants
b(1)=-3.56417e-3;
b(2)=4.74868e-6;
b(3)=1.15574e-5;

% calculate permittivity of pure water
epss=permittivityH2O(t);
% calculate permittivity of salt water
% create matrices
epss=epss(:,ones(1,max(size_S)));
t=t(:,ones(1,max(size_S)));
S=S(ones(1,max(size_t)),:);
corr=exp(b(1).*S+b(2).*(S.^2)+b(3).*S.*t);
epss=epss.*corr;

