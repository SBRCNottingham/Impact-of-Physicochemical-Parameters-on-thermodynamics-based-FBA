%% Claudio Tomi-Andrino 2019

% Two different ways to calculate the prefactor A have been considered in
% this study: (i) Alberty and (ii) Thomas

t_lin = linspace(25,75,50);
T_lin = t_lin-phc.T0;
S_lin = zeros(1,50);
A_i = 1.10708 - (1.54508e-3)*T_lin + (5.95584e-6)*T_lin.^2;

X = t_lin;
Y = S_lin;
Z = A_i;

figure
plot3(X,Y,Z,'r')

hold on

% Assuming I = 0.25M (Henry et al. 2007, Salvy et al. 2018) this value can
% be converted to I [mol/kg] by considering a buoyant density of 1.11 kg/L
% (Baldwin et al. 1995). Then, S can be calculated used the expression for
% seawater (Millero 1972)

I = 0.25*1.11;
S = (1000*I)/(19.92+(1.005*I));

% generating vectors for t and S; assuming t_max of 50 oC and S_max of
% twice the salinity, taking 50 values in the range
t_lin = linspace(25,75,50);
S_lin = linspace(0,2*S,50);
A_ii = debye_hueckel(t_lin,S_lin);

[X,Y] = meshgrid(t_lin,S_lin);
Z = A_ii;
C = X.*Y;
surf(X,Y,Z,C)
colorbar

hold on

%title('My title')
xlabel('Temperature (^{o}C)')
ylabel('Salinity (g/kg)')
zlabel('Prefactor A (kg/mol^{1/2})')


