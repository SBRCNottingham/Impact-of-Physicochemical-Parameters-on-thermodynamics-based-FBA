function [D,D1,D2]=densityH2O(t)
%
% Created by Thomas Millat, University of Nottingham
% Email: thomas.millat@nottingham.ac.uk

% DENSITY_H2O computes the density of pure water as a function of the
% temperature
%
% This function represents the pure water reference point in the 
% calculation of the density of sea water (function density_sw)
% as defined in Siedler and Peters (1986). 
%
%	Properties of sea water
%	Siedler, G. and Peters, H.
%	in Oceanography, Sunderman, J. (Ed.), pp 233-264, (1986)
%	Springer Verlag (Berlin)
%
% The density of pure water is defined according to Bigg (1967)
%
%	Density of water in SI units over the range 0-40°C
%	Bigg, P.H.
%	Br. J. Appl. Phys. 18 (4), 521-525 (1967)
%	DOI: 10.1088/0508-3443/18/4/315
%
% as a temperature-dependent polynomial function
%
%   Dw = d1+d2*t+d3*t^2+d4*t^3+d5*t^4+d6*t^5
%
% Range of validity:
%   -2<=T<=40
%
% The function calculates the vectors D(t), its first derivative
% D1 and its second derivative D2

% Check Number of Input Arguments
switch nargin
    case 0
        t=25;
        warning('density_sw:argChk','Assuming t=25 deg Celsius');
    case 1
        % all arguments provided
        size_t=size(t);
        if min(size_t)>1
            error('density_sw:argChk','Arguments must be vectors');
        elseif size_t(2)>1
            t=transpose(t);
        end
    otherwise
        error('density_sw:argChk','Too many input arguments')
end

% constants

d(1)=999.842594;
d(2)=6.793952e-2;
d(3)=-9.095290e-3;
d(4)=1.001685e-4;
d(5)=-1.120083e-6;
d(6)=6.536332e-9;

% density for pure water
D=d(1)+(d(2)+(d(3)+(d(4)+(d(5)+d(6).*t).*t).*t).*t).*t;

% first derivatie with respect to temperature
D1=d(2)+(2*d(3)+(3*d(4)+(4*d(5)+5*d(6).*t).*t).*t).*t;

% second derivative with respect to temperature
D2=2*d(3)+(6*d(4)+(12*d(5)+20*d(6).*t).*t).*t;

% end of function densityH2O
end