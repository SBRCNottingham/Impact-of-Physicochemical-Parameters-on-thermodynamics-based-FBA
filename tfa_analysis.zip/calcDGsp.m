function deltaGf = calcDGsp(name,index,pH,ionicStr,dataset,ReactionDB)
% calculate the transformed Gibbs energy of formation of specie with given
% pH and ionic strength using formula given by Goldberg and Tewari, 1991
% equation 4.4-10 in Alberty's book

% Script based on matTFA by Salvy et al. 2018
% (https://doi.org/10.1093/bioinformatics/bty499)
% Modified by Claudio Tomi-Andrino (2020)

% global data;
global ionic_strength
global temperature
global prefactor_A
global equation_method

if strcmp(ReactionDB.thermo_units,'kJ/mol')
    GAS_CONSTANT = 8.314472/1000; % kJ/(K mol)
    Adjustment = 1;
else
    GAS_CONSTANT = 1.9858775/1000; % Kcal/(K mol)
    Adjustment = 4.184;
end
t = temperature;
TEMPERATURE = t-phc.T0; % K
RT = GAS_CONSTANT*TEMPERATURE;

I = ionic_strength;

pfA = prefactor_A;

if equation_method == 0
    q1 = Debye_Huckel_B;
    q2 = 0;
else
    q1 = 1;
    q2 = 1;
end


if strcmp(dataset,'Alberty')
    
    evalc(strcat('specie = data.',name,'sp'));
    deltaGo = specie{index}{1}
    zsq = (specie{index}{3})^2
    nH = specie{index}{4}
                 
    term1 = (nH*RT*log(10^(-pH)));
    term2 =(pfA*(zsq-nH)*((sqrt(I)/(1+q1*sqrt(I)))-(q2*0.3*I)))/Adjustment;
    deltaGf = deltaGo - (term1 + term2); 
  
    % how it was deltaGf = deltaGo - (nH*RT*log(10^(-pH))) - (2.91482*(zsq-nH)*sqrt(I)/(1+Debye_Huckel_B*sqrt(I)))
    % didn't have Adjustmnent this one?
    
elseif strcmp(dataset,'GCM')
    
    ind = getIndex(ReactionDB.compound.ID,name);
    [deltaGo,charge,nH] = calcDGspA(name,ReactionDB);
    zsq = charge^2;
    
    term1 = (nH*RT*log(10^(-pH)));
    term2 =(pfA*(zsq-nH)*((sqrt(I)/(1+q1*sqrt(I)))-(q2*0.3*I)))/Adjustment;
    deltaGf = deltaGo - (term1 + term2); 
    
%     term1 = (nH*RT*log(10^(-pH)));
%     term2 = (2.91482*(zsq-nH)*sqrt(I)/(1+Debye_Huckel_B*sqrt(I)))/Adjustment;
%     deltaGf = deltaGo - (term1 + term2);

end
        
end