clc
clear all
clear global
restoredefaultpath

tic

%% Script based on matTFA by Salvy et al. 2018
% (https://doi.org/10.1093/bioinformatics/bty499)
% Modified by Claudio Tomi-Andrino (2020)
% script to analyse the impact of varying thermodynamic parameters in
% for a thermophile (T. thermophilus)
% described in L. T. Cordova et al. (M. Eng 2017) (13C-MFA data) and Lee et
% al. (Microbial cell factories 2014), GSM

%% Some experimental data
% Experimental data from L. T. Cordova et al. (M. Eng 2017)
uptake_glucose_exp = 3.7;  % mmol/gDCW-h
growth_rate_exp = 0.22;      % h-1
MW_glucose = 180;           % g/mol
yield_exp = (growth_rate_exp/uptake_glucose_exp)*(1000/MW_glucose); % g DCW/g glucose consumed

% the theoretical biomass yield can also be calculated
Y_X_ATP = 10.3;              % g DCW/mol ATP (Neidhart 1996, Shuler 2002) for aerobic fermentations
ATP_Glucose = 2/MW_glucose;  % moles of ATP per mol of glucose (expressed in gram units)
yield_theoret = Y_X_ATP * ATP_Glucose;       % g DCW/g glucose consumed

% fluxomics (considering there are lumped reactions defined in the inverse
% direction in the GSM; thus, there are repeated flux values with different
% sign)
fluxes_cordova = ["GAP <=> 3PG + ATP + NADH (net)", "3PG <=> PEP (net)", "3PG <=> PEP (net)", "DHAP <=> GAP (net)", "Cit <=> ICit (net)", "Fum <=> Mal (net)", "SucCoA <=> Suc + ATP (net)", "NH3.ext -> NH3", "OAC + Glu -> Asp + AKG", "Ru5P <=> X5P (net)", "Ru5P <=> R5P (net)", "Ac-> Ac.ext", "Glyox + AcCoA -> Mal", "ICit <=> Glyox + Suc (net)", "G6P -> 6PG + NADPH", "KDPG -> Pyr + GAP", "G6P -> 6PG + NADPH", "G6P -> 6PG + NADPH", "6PG -> KDPG", "Mal -> Pyr + CO2 + NADPH", "AcCoA <=> Ac + ATP (net)", "0.615 Ala + 0.354 Arg + 0.185 Asn + 0.185 Asp + 0.110 Cys + 0.301 Glu + 0.301 Gln + 0.594 Gly + 0.104 His + 0.158 Ile + 0.554 Leu + 0.298 Lys + 0.089 Met + 0.200 Phe + 0.331 Pro + 0.295 Ser + 0.309 Thr + 0.068 Trp + 0.198 Tyr + 0.395 Val + 0.273 G6P + 0.071 F6P + 0.186 GAP + 0.522 3PG + 0.051 PEP + 0.083 Pyr + 0.087 AKG + 0.230 OAC + 0.489 R5P + 3.510 AcCoA + 34.402 ATP + 6.985 NADPH + 0.338 MEETHF � 42.882 Biomass + 1.050 NADH", "OAC + ATP -> PEP + CO2", "PEP + CO2 -> OAC", "AKG -> SucCoA + CO2 + NADH", "Suc <=> Fum + FADH2 (net)", "Mal <=> OAC + NADH (net)", "OAC + AcCoA -> Cit", "Cit <=> ICit (net)", "ICit -> AKG + CO2 + NADPH", "ICit -> AKG + CO2 + NADPH", "F6P + ATP <=> FBP (net)", "FBP <=> DHAP + GAP (net)", "G6P <=> F6P (net)", "PEP <=> Pyr + ATP (net)", "GAP <=> 3PG + ATP + NADH (net)", "O2.ext -> O2", "CO2 -> CO2.ext"];
fluxes_13C = [-180.3, -168.1, -168.1, -92.5, -84.5, -75.2, -71.0, -59.5, -10.3, -4.6, -4.6, -0.2, 0.0, 0.0, 0.3, 0.3, 0.3, 0.3, 0.3, 1.1, 6.3, 7.7, 28.1, 50.5, 71.7, 71.7, 74.2, 84.5, 84.5, 84.5, 84.5, 92.5, 92.5, 97.6, 138.1, 180.3, 243.9, 270.4]'; 

% We assume both I = 0.25M (Henry et al. 2007, Salvy et al. 2018), 
% calculated in the sript for E. coli (13.74) plus the value of 0.50 M, 
% which can be converted to I [mol/kg] by considering a buoyant density of 
% 1.11 kg/L (Baldwin et al. 1995). Then, S can be calculated used the 
% expression for seawater (Millero 1972)
I = 0.50*1.11;
S = (1000*I)/(19.92+(1.005*I));
clear I

%% Generation of tests
% preparing a legend matrix so that each column corresponds to a parameter,
% the first row to the lower value (0) and the second row the upper value
% (1)
npar = 5; 
nruns = 2^(npar);

d = (0:nruns-1)';
b = de2bi(d);
d = (1:nruns)'; % adapt it to runs 1 to nruns
full_tests = [d b];

clear b

legend_codex = zeros(2,npar);
legend_codex(:,1) = [25;72]; % temperature (oC)
legend_codex(:,2) = [0.25;0.50]; % ionic strength (M)
legend_codex(:,3) = [13.74;S]; % salinity (g/kg)
legend_codex(:,4) = [0;1]; % prefactor A (0 - Alberty, 1 - this study)
legend_codex(:,5) = [0;1]; % equation (0 - extended DH, 1 - Davies)
legend_codex;

clear S

% obtaining array with all the parameter values
full_parameters = zeros(size(full_tests));
full_parameters(:,1) = full_tests(:,1);

for  run_number = 1:nruns
    for column_number = 1:npar 
         full_parameters(run_number,column_number+1) = legend_codex(full_tests(run_number,column_number+1)+1,column_number);
         % I need to do column_number+1 because matlab cannot use 0 as an
         % index, and those are binary values
    end 
end

clear column_number

% extract vectors from full_parameters so that paremeter 1 is column 2,
% parameter 2 is column 3,(...). No need to extract to the run number, 
% since is the same as the row number. Thus I can later call the value of 
% the parameter at the run I am working with. In the original toolbox some 
% parameters were manually included in each function (e.g. temperature); 
par_temperature = full_parameters(:,2);
par_ionic_strength = full_parameters(:,3);
par_salinity = full_parameters(:,4);
par_method_prefactor_A = full_parameters(:,5);  % this will be used to calculate par_calc_prefactor_A
par_equation = full_parameters(:,6);

% now we calculate pfA values and include it as an extra column
par_calc_prefactor_A = zeros(nruns,1);

for  run_number = 1:nruns
    t = par_temperature(run_number);
    T = t-phc.T0;
    S = par_salinity(run_number);
    
    if par_method_prefactor_A(run_number)==0
        par_calc_prefactor_A(run_number)= 1.10708 - (1.54508e-3)*T + (5.95584e-6)*T^2;
    else
        par_calc_prefactor_A(run_number)= debye_hueckel(t,S);
    end
end  
clear t
clear T
clear S

final_parameters(:,1) = full_parameters(:,1);
final_parameters(:,2) = full_parameters(:,2);
final_parameters(:,3) = full_parameters(:,3);
final_parameters(:,4) = full_parameters(:,4);
final_parameters(:,5) = par_calc_prefactor_A; % substitute par_method_prefactor_A with calculated par_calc_prefactor_A
final_parameters(:,6) = full_parameters(:,6);

% prepare arrays to save results. Since strings cannot be stored in matrices, 
% I will operate with everything and export it altogether at the end 
biomass_flux_yield = zeros(nruns,7);
yield_values = zeros(nruns,5);
yield_deviation = zeros(nruns,4);
comparison_fluxes_13C_FBA = zeros(nruns, 2);
comparison_fluxes_13C_TFA = zeros(nruns, 2);
comparison_fluxes_FBA_TFA = zeros(nruns, 2);
comparison_fluxes_total = zeros(nruns, 4);
failed_run_track = zeros(nruns,2);

biomass_flux_yield(:,1) = d; 
yield_values = d;
yield_deviation = d;
comparison_fluxes_13C_FBA(:,1) = d;
comparison_fluxes_13C_TFA(:,1) = d;
comparison_fluxes_FBA_TFA(:,1) = d;
comparison_fluxes_total(:,1) = d;
comparison_metabolomics(:,1) = d;
failed_run_track(:,1) = d;
clear d
    
%% Load solver
cplex_loaded = load_cplex;
%C:\Program Files\IBM\ILOG\CPLEX_Studio128

if ~cplex_loaded
    error('CPLEX not found')
end

%% Load the COBRA Toolbox
addpath(genpath(fullfile('..','ext')))

%%  Load dependencies
addpath(genpath(fullfile('..','matTFA')))
addpath(genpath(fullfile('..','thermoDatabases')))
addpath(genpath(fullfile('..','models')))
addpath(genpath(fullfile('..','plotting')))

% switch to cplex solver
% changeCobraSolver('ibm_cplex')
changeCobraSolver('cplex_direct') % in theory the one that should be used

%% Load the model
tmp = load(fullfile('..','models','Thermus_thermophilus_HB27_iTT548_adapted_June_19.mat'));
mymodel = tmp.model;
clear tmp

%% Load the thermodynamics database
tmp = load('thermo_data.mat');
ReactionDB = tmp.DB_AlbertyUpdate;
clear tmp

%% save data original mymodel
% at some point some information is modified, affecting the labelling when
% gathering the data further down the code. Thus
original_mets = mymodel.mets;
adjustment_dG_mets(:, 1) = original_mets;
conc_est(:, 1) = original_mets;

original_rxns = mymodel.rxns;
adjustment_dG_rxns(:, 1) = original_rxns;
FBA_fluxes(:, 1) = original_rxns;

%% Apply some preliminary constraints
biomass_reaction = {'R001'}; 
id_biomass_reaction = find_cell(biomass_reaction, mymodel.rxns);
mymodel.lb(id_biomass_reaction) = 0.50*growth_rate_exp; % give some margin
mymodel.ub(id_biomass_reaction) = 0.60; % value predicted with glucose uptake of 11.11 (GSM paper)
mymodel.c(id_biomass_reaction) = 1;

uptake_glucose = {'R786'};
id_uptake_glucose = find_cell(uptake_glucose, mymodel.rxns);
mymodel.lb(id_uptake_glucose) = -1.1*uptake_glucose_exp; 
mymodel.ub(id_uptake_glucose) = 0;

% Limit the bounds of the fluxes that are higher than 100 or lower than
% -100 mmol/(gDW * h)
if any(mymodel.lb<-100) || any(mymodel.ub>100)
    mymodel.lb(mymodel.lb<-100) = -100;
    mymodel.ub(mymodel.ub>+100) = +100;
end


%% loop to calculate
for run_number = 1:nruns
try
%% set parameter values necessary for other functions
global temperature
    temperature = par_temperature(run_number);

global ionic_strength
    ionic_strength = par_ionic_strength(run_number);
    
global equation_method
    equation_method = par_equation(run_number);
    
global prefactor_A
    prefactor_A = par_calc_prefactor_A(run_number);   
     
%% Test simple fba
solFBA = optimizeCbModel(mymodel); % original 
min_obj = roundsd(0.5*solFBA.f, 2, 'floor');
mymodel.lb(mymodel.c==1) = min_obj;
first_FBA = solFBA;

%% Perform FVA 
fva = runMinMax(mymodel);

% Are there any blocked reactions?
% solver tolerance is 1e-9
SolTol = 1e-9;
id_Blocked_in_FBA = find( (fva(:,1)>-SolTol & fva(:,1)<SolTol) & ...
                          (fva(:,2)>-SolTol & fva(:,2)<SolTol) );
% If there exist block reactions
while ~isempty(id_Blocked_in_FBA)
    % remove them
    mymodel = removeRxns(mymodel, mymodel.rxns(id_Blocked_in_FBA));
    fva = runMinMax(mymodel);
    id_Blocked_in_FBA = find( (fva(:,1)>-SolTol & fva(:,1)<SolTol) & ...
                              (fva(:,2)>-SolTol & fva(:,2)<SolTol) );
end

        %% Store FVA results
        list_rxns_fva = mymodel.rxns;

        if run_number == 1
            n_rxns = size(list_rxns_fva,1);
            stored_fva = zeros(n_rxns, 2*nruns);
        end

        min_fva_position = 2*run_number - 1;
        max_fva_position = 2*run_number;

        stored_fva(:,min_fva_position) = fva(:,1);
        stored_fva(:,max_fva_position) = fva(:,2);

%% Prepare for TFA
    %need field for description
    prepped_m = prepModelforTFA(mymodel, ReactionDB, mymodel.CompartmentData);

%% Convert to TFA
    tmp = convToTFA(prepped_m, ReactionDB, [], 'DGo', [], min_obj);

    % Add net flux variables, which are equal to forwards flux - backwards flux
    % NF_rxn = F_rxn - B_rxn
    this_tmodel = addNetFluxVariables(tmp);

%% Solve tFA
    soltFA = solveTFAmodelCplex(this_tmodel);

%% Perform TVA
% this would be unnecessary?
    % Get the variables representing the net fluxes
    NF_ix = getAllVar(this_tmodel,{'NF'});
    tva = runTMinMax(this_tmodel, this_tmodel.varNames(NF_ix));

%% We add some generic data for cofactor concentrations
% applying the constrains as originally proposed in Salvy et al 2018
% (except for AMP, which is not in this metaboli network)
metNames = {'adp_c', 'atp_c'};
C_lb = [1e-06, 1e-03]';
C_ub = [7e-04,5e-02]';
LC_varNames = {'LC_adp_c', 'LC_atp_c'};
% find the indices of these variables in the variable names of the tfa
id_LC_varNames = find_cell(LC_varNames, this_tmodel.varNames);
% Set to the model these log-concentration values
this_tmodel.var_lb(id_LC_varNames) = log(C_lb);
this_tmodel.var_ub(id_LC_varNames) = log(C_ub);

clear metNames
clear LC_varNames

stored_id_LC_varNames = id_LC_varNames;
clear id_LC_varNames

% Run another tva with the data
%     tva_wData = runTMinMax(this_tmodel, this_tmodel.varNames(NF_ix));

%% Get Thermodynamic displacements
% Add thermo_disp as variables
flagToAddLnThermoDisp = true;
gamma_model = convToTFA(prepped_m, ReactionDB, [], 'DGo', [], min_obj, [], flagToAddLnThermoDisp);
gamma_model = addNetFluxVariables(gamma_model);
gamma_model_backup = gamma_model; % this is to keep a copy for later use when gathering the results
NF_ix_gamma_model = getAllVar(gamma_model,{'NF'});
tva_gamma_model = runTMinMax(gamma_model, gamma_model.varNames(NF_ix_gamma_model));

solTFA = solveTFAmodelCplex(gamma_model);
LnGammaids = getAllVar(gamma_model,{'LnGamma'});

% how it was: 
% lngammaValues = solTFA.x(getAllVar(gamma_model,{'LnGammaids'}));

lngammaValues = solTFA.x(LnGammaids);

        %% Store TVA results
        list_rxns_tva = this_tmodel.rxns;

        if run_number == 1 
            n_rxns = size(list_rxns_tva,1);
            stored_tva = zeros(n_rxns, 2*nruns); 
        end

        min_tva_position = 2*run_number - 1;
        max_tva_position = 2*run_number;

        stored_tva(:,min_tva_position) = tva(:,1);
        stored_tva(:,max_tva_position) = tva(:,2);
%% Sampling
% Sampling fluxes & concentrations
% Sampling fluxes is well established as it is an LP problem, and COBRA
% has the appropriate functions for it. However, the TFA formulation is
% MILP problem. Therefore, because there exists no MILP sampler, we need
% make the model LP, by eliminating the bi-directional reactions.

% We check if our model has bi-directional reactions
id_BD = find(tva_gamma_model(:,1)<-1e-9 & tva_gamma_model(:,2)>1e-9);
% Define a minimum flux value
minFluxValue = 1e-6;
if ~isempty(id_BD)
    % if there exist bi-directional reactions for which we have no further
    % information, we need to eliminate them. One way to select a set of
    % directionalities is to just set them sequentially.
    % Assign a minimal lower bound to growth
    gamma_model.var_lb(gamma_model.f==1) = minFluxValue;
    model_fixed_d = assignReactionDirectionalities(gamma_model, minFluxValue, min_obj, ReactionDB);
end

% Get the optimal FBA growth
solFBA = solveFBAmodelCplex(model_fixed_d);

% Settings of the sampler (COBRA)
soloptions.nWarmupPoints = 500;
soloptions.nFiles = 1;
soloptions.nPointsPerFile = 5000;
soloptions.nStepsPerPoint = 100;
soloptions.nPointsReturned = 5000;
soloptions.NvZeroTolerance = 1e-8;
soloptions.nFilesSkipped = 0;
soloptions.removeLoopsFlag = false;
soloptions.removeLoopSamplesFlag = true;

        % readjustment (Claudio TA)
        length_b = size(model_fixed_d.b,1);
        model_fixed_d.csense = model_fixed_d.csense(1:length_b,:);

% Sample Fluxes
[modelSamplingFluxes, FluxSamples] = sampleCbModel_LCSB(model_fixed_d, 'FBA_model_samples', soloptions);

% Sample Concentrations
model_fixed_d_Conc = prepModelForConcSampling(model_fixed_d, solFBA.x);
model_fixed_d_Conc.A = [];
model_fixed_d_Conc = rmfield(model_fixed_d_Conc,'A');

        % readjustment (Claudio TA)
        csense_mod = [model_fixed_d_Conc.csense; model_fixed_d_Conc.csense; model_fixed_d_Conc.csense];
        length_b = size(model_fixed_d_Conc.b,1);
        model_fixed_d_Conc.csense = csense_mod(1:length_b,:);

[modelSamplingConcs, ConcSamples] = sampleCbModel_LCSB(model_fixed_d_Conc, 'ConcSampling', soloptions);

%% Gather data
%%%%% adjustment of Gibbs free energy values
% metabolites
this_run_adjustment_dG_mets(:, 1) = model_fixed_d_Conc.mets;
this_run_adjustment_dG_mets(:, 2) = num2cell(model_fixed_d_Conc.metDeltaGFtr);

internal_counter_mymodel = 1;
internal_counter_model_fixed_d_Conc = 1;

while internal_counter_model_fixed_d_Conc <= size(this_run_adjustment_dG_mets,1)
    if  isequal(adjustment_dG_mets{internal_counter_mymodel,1},this_run_adjustment_dG_mets{internal_counter_model_fixed_d_Conc,1});
        adjustment_dG_mets{internal_counter_mymodel,run_number+1} = this_run_adjustment_dG_mets{internal_counter_model_fixed_d_Conc,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_model_fixed_d_Conc = internal_counter_model_fixed_d_Conc + 1;
    else
        adjustment_dG_mets{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_model_fixed_d_Conc
clear this_run_adjustment_dG_mets

% reactions
this_run_adjustment_dG_rxns(:, 1) = model_fixed_d_Conc.rxns;
this_run_adjustment_dG_rxns(:, 2) = num2cell(model_fixed_d_Conc.rxnDeltaGR);

internal_counter_mymodel = 1;
internal_counter_model_fixed_d_Conc = 1;

while internal_counter_model_fixed_d_Conc <= size(this_run_adjustment_dG_rxns,1)
    if  isequal(adjustment_dG_rxns{internal_counter_mymodel,1},this_run_adjustment_dG_rxns{internal_counter_model_fixed_d_Conc,1});
        adjustment_dG_rxns{internal_counter_mymodel,run_number+1} = this_run_adjustment_dG_rxns{internal_counter_model_fixed_d_Conc,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_model_fixed_d_Conc = internal_counter_model_fixed_d_Conc + 1;
    else
        adjustment_dG_rxns{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_model_fixed_d_Conc
clear this_run_adjustment_dG_rxns

%%%%% estimated concentration values for metabolites
% estimated value. They are LC values (ln, called log() in matlab)!

list_varNames = gamma_model.varNames;
flux_varNames = solTFA.x;
data_result_TFA = table(list_varNames,flux_varNames);

this_run_pre_conc_est = data_result_TFA( startsWith(data_result_TFA.list_varNames,'LC_'), : );
this_run_pre_conc_est_cell = table2cell(this_run_pre_conc_est);

LC_names = cellstr(this_run_pre_conc_est_cell(:,1));
pre_conc_est(:,1) = strip(LC_names,'left','L');
pre_conc_est(:,1) = strip(pre_conc_est,'left','C');
pre_conc_est(:,1) = strip(pre_conc_est,'left','_');
ln_pre_conc_values(:,1) = cell2mat(this_run_pre_conc_est_cell(:,2));
mmol_pre_conc_values = exp(ln_pre_conc_values);
pre_conc_est(:,2) = num2cell(mmol_pre_conc_values); % expressed in mmol units

this_run_conc_est(:, 1) = pre_conc_est(:, 1);
this_run_conc_est(:, 2) = pre_conc_est(:, 2); % now we have two columns with the [met] for this run

internal_counter_mymodel = 1;
internal_counter_conc_est = 1;

while internal_counter_conc_est <= size(this_run_conc_est,1) & internal_counter_mymodel <= size(conc_est,1)
    if  isequal(conc_est{internal_counter_mymodel,1},this_run_conc_est{internal_counter_conc_est,1});
        conc_est{internal_counter_mymodel,run_number+1} = this_run_conc_est{internal_counter_conc_est,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_conc_est = internal_counter_conc_est + 1;
    else
        conc_est{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear list_varNames
clear flux_varNames
clear data_fluxes_TFA
clear this_run_pre_conc_est
clear this_run_pre_conc_est_cell
clear ln_pre_conc_values
clear mmol_pre_conc_values
clear pre_conc_est

clear internal_counter_mymodel
clear internal_counter_conc_est
clear this_run_conc_est

%%%%% extract flux values
% whole set of fluxes calculated in FBA
this_run_FBA(:, 1) = model_fixed_d.rxns;
this_run_FBA(:, 2) = num2cell(solFBA.x);

internal_counter_mymodel = 1;
internal_counter_model_fixed_d = 1;

while internal_counter_model_fixed_d <= size(this_run_FBA,1)
    if  isequal(FBA_fluxes{internal_counter_mymodel,1},this_run_FBA{internal_counter_model_fixed_d,1});
        FBA_fluxes{internal_counter_mymodel,run_number+1} = this_run_FBA{internal_counter_model_fixed_d,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_model_fixed_d = internal_counter_model_fixed_d + 1;
    else
        FBA_fluxes{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_model_fixed_d
clear this_run_FBA

% whole set of fluxes calculated in TFA
this_run_TFA(:, 1) = gamma_model.varNames;
this_run_TFA(:, 2) = num2cell(solTFA.x);
TFA_fluxes(:, 1) = gamma_model_backup.varNames; % backup before removing any reactions, so it should be the same for all the runs

internal_counter_mymodel = 1;
internal_counter_gamma_model = 1;

while internal_counter_gamma_model <= size(this_run_TFA,1)
    if  isequal(TFA_fluxes{internal_counter_mymodel,1},this_run_TFA{internal_counter_gamma_model,1});
        TFA_fluxes{internal_counter_mymodel,run_number+1} = this_run_TFA{internal_counter_gamma_model,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_gamma_model = internal_counter_gamma_model + 1;
    else
        TFA_fluxes{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_gamma_model
clear this_run_TFA

% subset of NF_fluxes in TFA
list_name_reactions = TFA_fluxes(:, 1);
flux_values_reactions = TFA_fluxes(:, run_number+1);
data_fluxes_NF = table(list_name_reactions,flux_values_reactions);

this_run_NF_fluxes = data_fluxes_NF( startsWith(data_fluxes_NF.list_name_reactions,'NF_'), : );
this_run_NF_fluxes_cell = table2cell(this_run_NF_fluxes);

NF_names(:,1) = cellstr(this_run_NF_fluxes_cell(:,1));
NF_fluxes = strip(NF_names,'left','N');
NF_fluxes = strip(NF_fluxes,'left','F');
NF_fluxes = strip(NF_fluxes,'left','_');
NF_fluxes(:,run_number+1) = this_run_NF_fluxes_cell(:,2);

clear list_name_reactions
clear flux_values_reactions
clear data_fluxes_NF
clear this_run_NF_fluxes
clear this_run_NF_fluxes_cell

% equivalent FBA fluxes to TFA's NF subset
eq_FBA_NF(:,1) = NF_fluxes(:,1);

internal_counter_eq_FBA_NF = 1;
internal_counter_NF_fluxes = 1;

while internal_counter_eq_FBA_NF <= size(eq_FBA_NF,1)
    if  isequal(eq_FBA_NF{internal_counter_eq_FBA_NF ,1},NF_fluxes{internal_counter_NF_fluxes ,1});
        id_flux_temp = find_cell(eq_FBA_NF{internal_counter_eq_FBA_NF ,1}, model_fixed_d.rxns);
        eq_FBA_NF{internal_counter_eq_FBA_NF ,run_number+1} = solFBA.x(id_flux_temp);
        internal_counter_eq_FBA_NF = internal_counter_eq_FBA_NF + 1;
        internal_counter_NF_fluxes = internal_counter_NF_fluxes + 1;
        clear id_flux_temp
    else
        eq_FBA_NF{internal_counter_eq_FBA_NF ,run_number+1} = [];
        internal_counter_eq_FBA_NF  = internal_counter_eq_FBA_NF + 1;
    end
end

clear internal_counter_eq_FBA_NF 
clear internal_counter_NF_fluxes 

%% Calculate correlation coefficients
%%% Fluxomics
% subset of TFA fluxes that can be compared with Cordova's 13C-MFA 
% different structure from the E. coli one, since in this case some fluxes
% in the 13C-MFA have been removed for the TFA, which affects the mapping

names_comparison_fluxes_TFA = {"NF_R010", "NF_R011", "NF_R012", "NF_R008", "NF_R021", "NF_R027", "NF_R025", "NF_R771", "NF_R198", "NF_R033", "NF_R034", "NF_R722", "NF_R420", "NF_R425", "NF_R029", "NF_R041", "NF_R710", "NF_R713", "NF_R714", "NF_R660", "NF_R016", "NF_R001", "NF_R014", "NF_R621", "NF_R024", "NF_R026", "NF_R028", "NF_R019", "NF_R020", "NF_R022", "NF_R023", "NF_R006", "NF_R007", "NF_R005", "NF_R013", "NF_R009", "NF_R718", "NF_R721"};  
id_comparison_fluxes_TFA = find_cell(names_comparison_fluxes_TFA, gamma_model.varNames)
this_run_fluxes_TFA_mmol_gDCW_h = solTFA.x(id_comparison_fluxes_TFA);
fluxes_TFA_mmol_gDCW_h(:,run_number) = cell2mat(num2cell(this_run_fluxes_TFA_mmol_gDCW_h));

name_uptake_glucose = {'NF_R786'};
id_uptake_glucose_gamma = find_cell(name_uptake_glucose, gamma_model.varNames);
this_run_NF_uptake_glucose = abs(solTFA.x(id_uptake_glucose_gamma));
this_run_fluxes_TFA_normalized = (this_run_fluxes_TFA_mmol_gDCW_h./this_run_NF_uptake_glucose)*100; % fluxes are normalised in "%" by considering the uptake of glucose, so a comparison is enabled
fluxes_TFA_normalized(:,run_number) = cell2mat(num2cell(this_run_fluxes_TFA_normalized));

correlation_coef_matrix_13C_TFA = corrcoef(fluxes_13C, this_run_fluxes_TFA_normalized);
correlation_coef_13C_TFA = correlation_coef_matrix_13C_TFA(2,1);
comparison_fluxes_13C_TFA(run_number,2) = correlation_coef_13C_TFA;

clear id_comparison_fluxes_TFA
clear this_run_fluxes_TFA_mmol_gDCW_h
clear id_uptake_glucose_gamma
clear correlation_coef_matrix_13C_TFA

% subset of FBA fluxes that can be compared with Cordova's 13C-MFA
names_comparison_fluxes_FBA = {"R010", "R011", "R012", "R008", "R021", "R027", "R025", "R771", "R198", "R033", "R034", "R722", "R420", "R425", "R029", "R041", "R710", "R713", "R714", "R660", "R016", "R001", "R014", "R621", "R024", "R026", "R028", "R019", "R020", "R022", "R023", "R006", "R007", "R005", "R013", "R009", "R718", "R721"}; 
id_comparison_fluxes_FBA = find_cell(names_comparison_fluxes_FBA, model_fixed_d.rxns);
this_run_fluxes_FBA_mmol_gDCW_h = solFBA.x(id_comparison_fluxes_FBA);
fluxes_FBA_mmol_gDCW_h(:,run_number) = cell2mat(num2cell(this_run_fluxes_FBA_mmol_gDCW_h));

name_uptake_glucose = {'R786'};
id_uptake_glucose_model_fixed_d = find_cell(name_uptake_glucose, model_fixed_d.rxns);
this_run_FBA_uptake_glucose = abs(solFBA.x(id_uptake_glucose_model_fixed_d));
this_run_fluxes_FBA_normalized = (this_run_fluxes_FBA_mmol_gDCW_h./this_run_FBA_uptake_glucose)*100; % fluxes are normalised in "%" by considering the uptake of glucose, so a comparison is enabled
fluxes_FBA_normalized(:,run_number) = cell2mat(num2cell(this_run_fluxes_FBA_normalized));

correlation_coef_matrix_13C_FBA = corrcoef(fluxes_13C, this_run_fluxes_FBA_normalized);
correlation_coef_13C_FBA = correlation_coef_matrix_13C_FBA(2,1);
comparison_fluxes_13C_FBA(run_number,2) = correlation_coef_13C_FBA;

clear id_comparison_fluxes_FBA
clear this_run_fluxes_FBA_mmol_gDCW_h
clear id_uptake_glucose_model_fixed_d
clear correlation_coef_matrix_13C_FBA

% equivalent FBA fluxes with TFA's NF subset
correlation_coef_matrix_FBA_TFA = corrcoef(this_run_fluxes_FBA_normalized,this_run_fluxes_TFA_normalized);
correlation_coef_FBA_TFA = correlation_coef_matrix_FBA_TFA(2,1);
comparison_fluxes_FBA_TFA(run_number,2) = correlation_coef_FBA_TFA;

clear correlation_coef_matrix_FBA_TFA
clear this_run_fluxes_FBA_normalized

% collecting all the info 
comparison_fluxes_total(run_number,2) = correlation_coef_13C_FBA;
comparison_fluxes_total(run_number,3) = correlation_coef_13C_TFA;
comparison_fluxes_total(run_number,4) = correlation_coef_FBA_TFA;

clear correlation_coef_13C_FBA
clear correlation_coef_13C_TFA
clear correlation_coef_FBA_TFA

%%% Bioprocessing data
growth_rate_FBA = {'R001'};
id_growth_rate_FBA = find_cell(growth_rate_FBA, model_fixed_d.rxns);

growth_rate_TFA = {'NF_R001'};
id_growth_rate_TFA = find_cell(growth_rate_TFA, gamma_model.varNames);

% biomass flux info
biomass_flux_yield(run_number,2) = this_run_FBA_uptake_glucose;
biomass_flux_yield(run_number,3) = solFBA.x(id_growth_rate_FBA);
biomass_flux_yield(run_number,4) = biomass_flux_yield(run_number,3)/biomass_flux_yield(run_number,2);
biomass_flux_yield(run_number,5) = this_run_NF_uptake_glucose;
biomass_flux_yield(run_number,6) = solTFA.x(id_growth_rate_TFA);
biomass_flux_yield(run_number,7) = biomass_flux_yield(run_number,6)/biomass_flux_yield(run_number,5);

clear this_run_FBA_uptake_glucose
clear this_run_NF_uptake_glucose

% variability analysis
id_rxns_stored_fva = find_cell(names_comparison_fluxes_FBA, list_rxns_fva)';
match_stored_fva = stored_fva(id_rxns_stored_fva,:);

id_rxns_stored_tva = find_cell(names_comparison_fluxes_FBA, list_rxns_tva)';
match_stored_tva = stored_tva(id_rxns_stored_tva,:);


catch
    disp('there was an error')
    failed_run_track(run_number,2) = run_number;
end

end
toc

%% Yields

for run_number = 1:nruns

% yield values
yield_values(run_number,2) = yield_exp;                                                                             % g DCW/ g glucose consumed
yield_values(run_number,3) = yield_theoret;                                                                         % g DCW/ g glucose consumed
yield_values(run_number,4) = (biomass_flux_yield(run_number,3)/biomass_flux_yield(run_number,2)*(1000/MW_glucose)); % yield FBA, g DCW/ g glucose consumed
yield_values(run_number,5) = (biomass_flux_yield(run_number,6)/biomass_flux_yield(run_number,5)*(1000/MW_glucose)); % yield TFA, g DCW/ g glucose consumed

% deviation from experimental yield values
    %not in absolute value!
yield_deviation(run_number,2) = 100*((yield_values(run_number,2)-yield_values(run_number,3))/yield_values(run_number,2)); % % dev yield theoretical from yield_exp
yield_deviation(run_number,3) = 100*((yield_values(run_number,2)-yield_values(run_number,4))/yield_values(run_number,2)); % % dev yield FBA from yield_exp
yield_deviation(run_number,4) = 100*((yield_values(run_number,2)-yield_values(run_number,5))/yield_values(run_number,2)); % % dev yield TFA from yield_exp

end

%% Directionalities pattern variation TFA (match w/ 13C-MFA data)
fluxes_TFA_normalized_total = [fluxes_TFA_normalized fluxes_13C] % adding known 13C fluxes as run #65
fluxes_TFA_normalized_pattern = fluxes_TFA_normalized_total;
total_number_index = size(fluxes_TFA_normalized_total,1)*size(fluxes_TFA_normalized_total,2);

for index_TFA = 1:total_number_index
    if fluxes_TFA_normalized_pattern(index_TFA) > 0
        fluxes_TFA_normalized_pattern(index_TFA) = 1;
    elseif fluxes_TFA_normalized_pattern(index_TFA) < 0
        fluxes_TFA_normalized_pattern(index_TFA) = -1;
    else
        fluxes_TFA_normalized_pattern(index_TFA) = 0;
    end
end

% fluxes going forward
fluxes_TFA_normalized_pattern_green = changem(fluxes_TFA_normalized_pattern, NaN, [0]);
fluxes_TFA_normalized_pattern_green = changem(fluxes_TFA_normalized_pattern_green, NaN, [-1]);

% fluxes going reverse
fluxes_TFA_normalized_pattern_red = changem(fluxes_TFA_normalized_pattern, NaN, [0]);
fluxes_TFA_normalized_pattern_red = changem(fluxes_TFA_normalized_pattern_red, NaN, [1]);

% fluxes with value of 0
fluxes_TFA_normalized_pattern_white = changem(fluxes_TFA_normalized_pattern, NaN, [-1]);
fluxes_TFA_normalized_pattern_white = changem(fluxes_TFA_normalized_pattern_white, NaN, [1]);

y_values = linspace(1,nruns+1,nruns+1)';     % run number
x_values = linspace(1,size(fluxes_13C,1),size(fluxes_13C,1))';
x_list = [num2cell(x_values) names_comparison_fluxes_TFA'];
[X,Y] = meshgrid(x_values,y_values);

z_values_g = fluxes_TFA_normalized_pattern_green(x_values, y_values);
z_values_r = fluxes_TFA_normalized_pattern_red(x_values, y_values);
z_values_w = fluxes_TFA_normalized_pattern_white(x_values, y_values);

Z_g = z_values_g.';
stem3(X,Y,Z_g,'MarkerFaceColor','g', 'LineStyle', 'none')
hold on

Z_r = z_values_r.';
stem3(X,Y,Z_r,'MarkerFaceColor','r', 'LineStyle', 'none')
hold on

Z_w = z_values_w.';
stem3(X,Y,Z_w,'MarkerFaceColor','w', 'LineStyle', 'none')
hold on

title('Pattern of reaction directionalities');
set(gca,'fontname','arial') 
xlabel('Reaction number (subset)')
ylabel('Run number')

clear h
%% export results

adjustment_dG_mets_table = cell2table(adjustment_dG_mets);
writetable(adjustment_dG_mets_table,'adjustment_dG_mets_table.txt','Delimiter',' ');  
type 'adjustment_dG_mets_table.txt';

adjustment_dG_rxns_table = cell2table(adjustment_dG_rxns);
writetable(adjustment_dG_rxns_table,'adjustment_dG_rxns_table.txt','Delimiter',' ');  
type 'adjustment_dG_rxns_table.txt';

conc_est_table = cell2table(conc_est);
writetable(conc_est_table,'conc_est_table.txt','Delimiter',' ');  
type 'conc_est_table.txt';

FBA_fluxes_table = cell2table(FBA_fluxes);
writetable(FBA_fluxes_table,'FBA_fluxes_table.txt','Delimiter',' ');  
type 'FBA_fluxes_table.txt';

fluxes_FBA_mmol_gDCW_h_table = array2table(fluxes_FBA_mmol_gDCW_h)
writetable(fluxes_FBA_mmol_gDCW_h_table,'fluxes_FBA_mmol_gDCW_h_table.txt','Delimiter',' ');  
type 'fluxes_FBA_mmol_gDCW_h_table.txt';

fluxes_FBA_normalized_table = array2table(fluxes_FBA_normalized)
writetable(fluxes_FBA_normalized_table,'fluxes_FBA_normalized_table.txt','Delimiter',' ');  
type 'fluxes_FBA_normalized_table.txt';

TFA_fluxes_table = cell2table(TFA_fluxes);
writetable(TFA_fluxes_table,'TFA_fluxes_table.txt','Delimiter',' ');  
type 'TFA_fluxes_table.txt';

fluxes_TFA_mmol_gDCW_h_table = array2table(fluxes_TFA_mmol_gDCW_h)
writetable(fluxes_TFA_mmol_gDCW_h_table,'fluxes_TFA_mmol_gDCW_h_table.txt','Delimiter',' ');  
type 'fluxes_TFA_mmol_gDCW_h_table.txt';

fluxes_TFA_normalized_table = array2table(fluxes_TFA_normalized)
writetable(fluxes_TFA_normalized_table,'fluxes_TFA_normalized_table.txt','Delimiter',' ');  
type 'fluxes_TFA_normalized_table.txt';

comparison_fluxes_total_table = array2table(comparison_fluxes_total,...
    'VariableNames',{'Test_number' 'correlation_coef_13C_FBA' 'correlation_coef_13C_TFA' 'correlation_coef_FBA_TFA'});
writetable(comparison_fluxes_total_table,'comparison_fluxes_table.txt','Delimiter',' ');  
type 'comparison_fluxes_table.txt';

biomass_flux_yield_table = array2table(biomass_flux_yield,...
    'VariableNames',{'Test_number' 'FBA_Uptake_Glucose' 'FBA_Growth_Rate' 'FBA_Y' 'TFA_Uptake_Glucose' 'TFA_Growth_Rate' 'TFA_Y'});
writetable(biomass_flux_yield_table,'biomass_yield_table.txt','Delimiter',' ');  
type 'biomass_yield_table.txt';

yield_values_table = array2table(yield_values,...
    'VariableNames',{'Test_number' 'Experimental' 'Theoretical' 'FBA' 'TFA'})
writetable(yield_values_table,'yield_values_table.txt','Delimiter',' ');  
type 'yield_values_table.txt';

yield_deviation_table = array2table(yield_deviation,...
    'VariableNames',{'Test_number' 'dev_theoretical' 'dev_FBA' 'dev_TFA'}) % deviations are in %
writetable(yield_deviation_table,'yield_deviation_table.txt','Delimiter',' ');  
type 'yield_deviation_table.txt';

%% Heatmaps
% some problems when trying to use MATLAB's in-built function, so a manual
% approach is followed. The function colorGradient is used
% (https://uk.mathworks.com/matlabcentral/fileexchange/31524-colorgradient-generate-custom-linear-colormaps)
% [grad,im]=colorGradient(c1,c2,depth)

% determining the minimum element of the three vectors, so will be set as
% lower limit (lower_l). upper_l = 1, the maximu value Pearson's r can have

min_total = [comparison_fluxes_13C_FBA; comparison_fluxes_13C_TFA; comparison_fluxes_FBA_TFA];
min_total = min_total(:,2);
lower_l = min(min_total)

upper_l = 1;

% diverging colour palette
c1 = [153 93 18];
c2 = [244 244 244]; 
depth = (nruns/2)+1;
colour_gradient_1 = colorGradient(c1,c2,depth);

clear c1
c1 = c2;
clear c2
c2 = [12 112 104];
colour_gradient_2 = colorGradient(c1,c2,depth);

colour_gradient_divergent = zeros(nruns,3);
colour_gradient_divergent(1:nruns/2,:) = colour_gradient_1(1:nruns/2,:);
colour_gradient_divergent((nruns/2)+1:end,:) = colour_gradient_2(2:end,:);

clear c1
clear c2
clear depth

% Sequential colour palette
c1 = [218 232 245]; 
c2 = [11 85 159]; 
depth = nruns;
colour_sequential = colorGradient(c1,c2,depth);

clear c1
clear c2
clear depth

% 13C-MFA VS FBA
% X axis = Y axis = 13C-MFA + 64 runs
total_corr_13C_FBA = zeros(nruns+1,nruns+1);
total_corr_13C_FBA(1,1) = 1;
total_corr_13C_FBA(nruns+1,nruns+1) = 1;
corr_13C_FBA = comparison_fluxes_13C_FBA(:,2)';
total_corr_13C_FBA(1,2:end) = corr_13C_FBA;

size_limit_FBA = size(fluxes_FBA_normalized,2);

for run_number = 1:size_limit_FBA
tot_this_run_fluxes_FBA_normalized = fluxes_FBA_normalized(:,run_number);

for i = run_number:size_limit_FBA
    tot_i_run_fluxes_FBA_normalized = fluxes_FBA_normalized(:,i);
    tot_correlation_coef_matrix_13C_FBA = corrcoef(tot_this_run_fluxes_FBA_normalized,tot_i_run_fluxes_FBA_normalized);
    tot_correlation_coef_13C_FBA = tot_correlation_coef_matrix_13C_FBA(2,1);
    total_corr_13C_FBA(run_number+1,i+1) = tot_correlation_coef_13C_FBA;
    clear tot_i_run_fluxes_FBA_normalized
    clear tot_correlation_coef_matrix_13C_FBA
    clear tot_correlation_coef_13C_FBA
end
clear tot_this_run_fluxes_FBA_normalized
end

B = changem(total_corr_13C_FBA, NaN, [0])
h = heatmap(B,'ColorLimits', [lower_l upper_l],'GridVisible','off','MissingDataLabel',' ', 'MissingDataColor', 'w')
h.Title = 'Correlation FBA VS 13C-MFA (heatmap)'
colormap(colour_gradient_divergent)
colorbar

saveas(gcf,h.Title,'epsc');
saveas(gcf,h.Title,'mfig');
print(gcf,h.Title,'-dpng','-r200');

clear B
clear h

% 13C-MFA VS TFA
% X axis = Y axis = 13C-MFA + 64 runs
total_corr_13C_TFA = zeros(nruns+1,nruns+1);
total_corr_13C_TFA(1,1) = 1;
total_corr_13C_TFA(nruns+1,nruns+1) = 1;
corr_13C_TFA = comparison_fluxes_13C_TFA(:,2)';
total_corr_13C_TFA(1,2:end) = corr_13C_TFA;

size_limit_TFA = size(fluxes_TFA_normalized,2);

for run_number = 1:size_limit_TFA
tot_this_run_fluxes_TFA_normalized = fluxes_TFA_normalized(:,run_number);

for i = run_number:size_limit_TFA
    tot_i_run_fluxes_TFA_normalized = fluxes_TFA_normalized(:,i);
    tot_correlation_coef_matrix_13C_TFA = corrcoef(tot_this_run_fluxes_TFA_normalized,tot_i_run_fluxes_TFA_normalized);
    tot_correlation_coef_13C_TFA = tot_correlation_coef_matrix_13C_TFA(2,1);
    total_corr_13C_TFA(run_number+1,i+1) = tot_correlation_coef_13C_TFA;
    clear tot_i_run_fluxes_TFA_normalized
    clear tot_correlation_coef_matrix_13C_TFA
    clear tot_correlation_coef_13C_TFA
end
clear tot_this_run_fluxes_TFA_normalized
end

B = changem(total_corr_13C_TFA, NaN, [0])
h = heatmap(B,'ColorLimits', [lower_l upper_l],'GridVisible','off','MissingDataLabel',' ', 'MissingDataColor', 'w')
h.Title = 'Correlation TFA VS 13C-MFA (heatmap)'
colormap(colour_gradient_divergent)
colorbar

saveas(gcf,h.Title,'epsc');
saveas(gcf,h.Title,'mfig');
print(gcf,h.Title,'-dpng','-r200');

clear B
clear h

% Compasion_fluxes_total
matrix_comparison = comparison_fluxes_total(:,2:end);
xvalues = {'FBA VS. 13C-MFA', 'TFA VS. 13C-MFA', 'FBA VS. TFA'};

pre_yvalues = num2cell((linspace(1,nruns,nruns))');
yvalues = {pre_yvalues{:}};
subplot(1,2,1)
h = heatmap(xvalues,yvalues,matrix_comparison,'ColorLimits', [lower_l upper_l],'GridVisible','off','MissingDataLabel',' ', 'MissingDataColor', 'w','Colormap', colour_sequential)
h.Title = 'Comparison correlation coefficient fluxomics'
% colormap(colour_sequential)
colorbar

saveas(gcf,h.Title,'epsc');
saveas(gcf,h.Title,'mfig');
print(gcf,h.Title,'-dpng','-r200');

clear h


