clc
clear
clear global
restoredefaultpath

% tic

%% Script based on matTFA by Salvy et al. 2018
% (https://doi.org/10.1093/bioinformatics/bty499)
% Modified by Claudio Tomi-Andrino (2020)

%% Some experimental data
% Experimental data from Ishii et al. 2007
uptake_glucose_exp = 2.93;  % mmol/gDCW-h
growth_rate_exp = 0.2;      % h-1
MW_glucose = 180;           % g/mol
yield_exp = (growth_rate_exp/uptake_glucose_exp)*(1000/MW_glucose); % g DCW/g glucose consumed

% the theoretical biomass yield can also be calculated
Y_X_ATP = 10.3;              % g DCW/mol ATP (Neidhart 1996, Shuler 2002) for aerobic fermentations
ATP_Glucose = 2/MW_glucose;  % moles of ATP per mol of glucose (expressed in gram units)
yield_theoret = Y_X_ATP * ATP_Glucose;       % g DCW/g glucose consumed

% metabolomics: this information will be used as both constraints (in some
% cases) and to compare the predictive capacity (in all cases). Thus, we
% store them here and call them when necessary
metNames_exp = {'succoa_c', 'trp-L_c', 'dctp_c', 'fdp_c', 'fad_c', 'met-L_c', 'ile-L_c', 'tyr-L_c', 'datp_c', 'f6p_c', 'phe-L_c', 'arg-L_c', 'g1p_c', 'his-L_c', 'nadp_c', 'pro-L_c', 'asn-L_c', 'leu-L_c', 'pep_c', 'dhap_c', 'pyr_c', 'amet_c', 'thr-L_c', 'malcoa_c', 'accoa_c', 'val-L_c', 's7p_c', 'pydx5p_c', 'ctp_c', 'nadph_c', 'gly_c', 'ser-L_c', 'ala-L_c', 'asp-L_c', 'lys-L_c', '3pg_c', 'adp_c', 'amp_c', 'gtp_c', 'utp_c', 'gln-L_c', 'nad_c', 'atp_c', 'glu-L_c'};
Conc_values_exp = [0.009359543, 0.010731977, 0.025375612, 0.025929355, 0.026680487, 0.031787628, 0.033148308, 0.034456205, 0.040279403, 0.043890575, 0.056293859, 0.056846432, 0.063547658, 0.078509817, 0.087335543, 0.094154326, 0.111930146, 0.113621109, 0.120087663, 0.12623261, 0.128204905, 0.130297951, 0.147806892, 0.158776506, 0.192901247, 0.200709788, 0.221586771, 0.243517494, 0.259172413, 0.267429669, 0.289555417, 0.308649675, 0.320280616, 0.328512449, 0.334719094, 0.506263157, 0.56225118, 0.570592568, 0.627229356, 0.635722343, 0.641449567, 0.72017617, 1.232156107, 3.47369374]; % metabolite concentration values (mmol)
C_exp = Conc_values_exp./1000; % so we convert from mM to M

% fluxomics (considering there are lumped reactions defined in the inverse
% direction in the GSM; thus, there are repeated flux values with different
% sign)
fluxes_ishii = ["AcCoA -> Ethanol", "CIT -> ICT", "CIT -> ICT", "AcCoA -> Acetate", "2-KG -> SUC + CO2", "AcCoA -> Ethanol", "AcCoA + OAA -> CIT", "6-PG -> G3P + PYR", "6-PG -> G3P + PYR", "3PG <-> PEP", "F1,6P -> DHAP + G3P", "FUM -> MAL", "G6P -> 6PG", "G3P -> 3PG", "Glucose + PEP -> G6P + PYR", "6PG -> Ru5P + CO2", "ICT -> 2-KG + CO2", "ICT -> Glyoxylate + SUC", "PYR -> Lactate", "Glyoxylate + AcCoA -> MAL", "MAL <-> OAA", "MAL -> PYR + CO2", "MAL -> PYR + CO2", "PYR -> AcCoA + CO2", "F6P -> F1,6P", "G6P <-> F6P", "G3P -> 3PG", "G6P -> 6PG", "3PG <-> PEP", "PEP + CO2 <-> OAA", "AcCoA -> Acetate", "PEP -> PYR", "Ru5P -> X5P", "Ru5P -> R5P", "SUC -> FUM", "2-KG -> SUC + CO2", "S7P + G3P <-> E4P + F6P", "R5P + X5P <-> S7P + G3P", "X5P + E4P <-> F6P + G3P", "DHAP -> G3P"];
fluxes_13C = [-0.1, 85.9, 85.9, 0, 62.5, -0.1, 85.9, 0, 0, 161.7, 85.3, 77.5, 20.5, 172, 100, 20.5, 70.9, 15, 0, 15, 89.1, 3.4, 3.4, 129.4, 85.3, 78, -172, 20.5, -161.7, 10.6, 0, 47.3, 8.1, -12.4, 77.5, 62.5, 5.6, 5.6, 2.5, 85.3];

%Assuming I = 0.25M (Henry et al. 2007, Salvy et al. 2018) this value can
% be converted to I [mol/kg] by considering a buoyant density of 1.11 kg/L
% (Baldwin et al. 1995). Then, S can be calculated used the expression for
% seawater (Millero 1972)
I = 0.25*1.11;
S = (1000*I)/(19.92+(1.005*I));
clear I

%% Generation of tests
% preparing a legend matrix so that each column corresponds to a parameter,
% the first row to the lower value (0) and the second row the upper value
% (1)
npar = 6; 
nruns = 2^(npar);

d = (0:nruns-1)';
b = de2bi(d);
d = (1:nruns)'; % adapt it to runs 1 to nruns
full_tests = [d b];

clear b

legend_codex = zeros(2,npar);
legend_codex(:,1) = [25;37]; % temperature (oC)
legend_codex(:,2) = [0;0.25]; % ionic strength (M)
legend_codex(:,3) = [0;S]; % salinity (g/kg)
legend_codex(:,4) = [0;1]; % prefactor A (0 - Alberty, 1 - this study)
legend_codex(:,5) = [0;1]; % equation (0 - extended DH, 1 - Davies)
legend_codex(:,6) = [0;1]; % [metabolites] (0 - unconstrained, 1 - constrained)
legend_codex;

clear S

% obtaining array with all the parameter values
full_parameters = zeros(size(full_tests));
full_parameters(:,1) = full_tests(:,1);

for  run_number = 1:nruns
    for column_number = 1:npar 
         full_parameters(run_number,column_number+1) = legend_codex(full_tests(run_number,column_number+1)+1,column_number);
         % I need to do column_number+1 because matlab cannot use 0 as an
         % index, and those are binary values
    end 
end

clear column_number

% extract vectors from full_parameters so that paremeter 1 is column 2,
% parameter 2 is column 3,(...). No need to extract to the run number, 
% since is the same as the row number. Thus I can later call the value of 
% the parameter at the run I am working with. In the original toolbox some 
% parameters were manually included in each function (e.g. temperature); 
par_temperature = full_parameters(:,2);
par_ionic_strength = full_parameters(:,3);
par_salinity = full_parameters(:,4);
par_method_prefactor_A = full_parameters(:,5);  % this will be used to calculate par_calc_prefactor_A
par_equation = full_parameters(:,6);
par_conc_metabolites = full_parameters(:,7);

% now we calculate pfA values and include it as an extra column
par_calc_prefactor_A = zeros(nruns,1);

for  run_number = 1:nruns
    t = par_temperature(run_number);
    T = t-phc.T0;
    S = par_salinity(run_number);
    
    if par_method_prefactor_A(run_number)==0
        par_calc_prefactor_A(run_number)= 1.10708 - (1.54508e-3)*T + (5.95584e-6)*T^2;
    else
        par_calc_prefactor_A(run_number)= debye_hueckel(t,S);
    end
end  
clear t
clear T
clear S

final_parameters(:,1) = full_parameters(:,1);
final_parameters(:,2) = full_parameters(:,2);
final_parameters(:,3) = full_parameters(:,3);
final_parameters(:,4) = full_parameters(:,4);
final_parameters(:,5) = par_calc_prefactor_A; % substitute par_method_prefactor_A with calculated par_calc_prefactor_A
final_parameters(:,6) = full_parameters(:,6);
final_parameters(:,7) = full_parameters(:,7);

% prepare arrays to save results. Since strings cannot be stored in matrices, 
% I will operate with everything and export it altogether at the end 
biomass_flux_yield = zeros(nruns,7);
yield_values = zeros(nruns,5);
yield_deviation = zeros(nruns,4);
comparison_fluxes_13C_FBA = zeros(nruns, 2);
comparison_fluxes_13C_TFA = zeros(nruns, 2);
comparison_fluxes_FBA_TFA = zeros(nruns, 2);
comparison_fluxes_total = zeros(nruns, 4);
failed_run_track = zeros(nruns,2);

biomass_flux_yield(:,1) = d; 
yield_values = d;
yield_deviation = d;
comparison_fluxes_13C_FBA(:,1) = d;
comparison_fluxes_13C_TFA(:,1) = d;
comparison_fluxes_FBA_TFA(:,1) = d;
comparison_fluxes_total(:,1) = d;
comparison_metabolomics(:,1) = d;
failed_run_track(:,1) = d;
clear d
    
%% Load solver
cplex_loaded = load_cplex;
%C:\Program Files\IBM\ILOG\CPLEX_Studio128

if ~cplex_loaded
    error('CPLEX not found')
end

%% Load the COBRA Toolbox
addpath(genpath(fullfile('..','ext')))

%%  Load dependencies
addpath(genpath(fullfile('..','matTFA')))
addpath(genpath(fullfile('..','thermoDatabases')))
addpath(genpath(fullfile('..','models')))
addpath(genpath(fullfile('..','plotting')))

% switch to cplex solver
% changeCobraSolver('ibm_cplex')
changeCobraSolver('cplex_direct') % in theory the one that should be used

%% Load the model
tmp = load(fullfile('..','models','GSmodel_Ecoli.mat'));
mymodel = tmp.ttmodel;
clear tmp

%% Load the thermodynamics database
tmp = load('thermo_data.mat');
ReactionDB = tmp.DB_AlbertyUpdate;
clear tmp

%% save data original mymodel
% at some point some information is modified, affecting the labelling when
% gathering the data further down the code. Thus
original_mets = mymodel.mets;
adjustment_dG_mets(:, 1) = original_mets;
conc_est(:, 1) = original_mets;

original_rxns = mymodel.rxns;
adjustment_dG_rxns(:, 1) = original_rxns;
FBA_fluxes(:, 1) = original_rxns;
FBA_fluxes_trad(:, 1) = original_rxns;

%% Apply some preliminary constraints
% There are two stoichiometrically identical transporters for
% glucose (GLCtex & GLCtexi), one will be totally shut down (otherwise the model could use both
% or alternate between runs). 
transport_glucose_2 = {'GLCtexi'}; 
id_transport_glucose_2 = find_cell(transport_glucose_2, mymodel.rxns);
mymodel.lb(id_transport_glucose_2) = 0;
mymodel.ub(id_transport_glucose_2) = 0;

% There are two biomass reactions, one will be totally shut down
biomass_reaction_2 = {'Ec_biomass_iJO1366_core_53p95M'};
id_growth_rate_2 = find_cell(biomass_reaction_2, mymodel.rxns);
mymodel.lb(id_growth_rate_2) = 0;
mymodel.ub(id_growth_rate_2) = 0;

% The uptake rate is determined by the exchange
% reaction DM_glc_e, with a fixed lb of -8.16 (negative because is going
% into the system, thus have to check it in terms of absolute values)
uptake_glucose = {'DM_glc_e'};
id_uptake_glucose = find_cell(uptake_glucose, mymodel.rxns);
% the uptake provided in the original matTFA is -8.16. A robustness
% analysis considering the original NGAM/GAM states that with a glucose
% uptake of -3, a groth rate of 0.1995 is achieved (experimental is -2.93
% and 0.20). Thus -3 will be used.

% -3 failed, let's try -4
% -4 failed, let's try -5
% -5 failed, let's try -6
% -6 works for both FBA with fixed directionalities and TFA. However, for
% the sake of consistency with the original matTFA, -8.16 will be used
mymodel.lb(id_uptake_glucose) = -8.16; 
mymodel.ub(id_uptake_glucose) = 0;  

% Limit the bounds of the fluxes that are higher than 100 or lower than
% -100 mmol/(gDW * h)
if any(mymodel.lb<-100) || any(mymodel.ub>100)
    mymodel.lb(mymodel.lb<-100) = -100;
    mymodel.ub(mymodel.ub>+100) = +100;
end

%% loop to calculate
for run_number = 1:nruns
try
%% set parameter values necessary for other functions

disp(run_number)

global temperature
    temperature = par_temperature(run_number);

global ionic_strength
    ionic_strength = par_ionic_strength(run_number);
    
global equation_method
    equation_method = par_equation(run_number);
    
global prefactor_A
    prefactor_A = par_calc_prefactor_A(run_number);   
     
%% Test simple fba
solFBA = optimizeCbModel(mymodel); % original 
min_obj = roundsd(0.5*solFBA.f, 2, 'floor');
mymodel.lb(mymodel.c==1) = min_obj;

% whole set of fluxes calculated in FBA (traditional) added later than
% the other two

try

this_run_FBA_trad(:, 1) = mymodel.rxns; % counter: internal_counter_mymodel_original
this_run_FBA_trad(:, 2) = num2cell(solFBA.x);

internal_counter_mymodel = 1;
internal_counter_mymodel_original = 1;

while internal_counter_mymodel_original <= size(this_run_FBA_trad,1)
    if  isequal(FBA_fluxes_trad{internal_counter_mymodel,1},this_run_FBA_trad{internal_counter_mymodel_original,1});
        FBA_fluxes_trad{internal_counter_mymodel,run_number+1} = this_run_FBA_trad{internal_counter_mymodel_original,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_mymodel_original = internal_counter_mymodel_original + 1;
    else
        FBA_fluxes_trad{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_mymodel_original
clear this_run_FBA

catch
    disp('error')
end

%% Perform FVA 
fva = runMinMax(mymodel);

% Are there any blocked reactions?
% solver tolerance is 1e-9
SolTol = 1e-9;
id_Blocked_in_FBA = find( (fva(:,1)>-SolTol & fva(:,1)<SolTol) & ...
                          (fva(:,2)>-SolTol & fva(:,2)<SolTol) );
% If there exist block reactions
while ~isempty(id_Blocked_in_FBA)
    % remove them
    mymodel = removeRxns(mymodel, mymodel.rxns(id_Blocked_in_FBA));
    fva = runMinMax(mymodel);
    id_Blocked_in_FBA = find( (fva(:,1)>-SolTol & fva(:,1)<SolTol) & ...
                              (fva(:,2)>-SolTol & fva(:,2)<SolTol) );
end

%% Prepare for TFA
    %need field for description
    prepped_m = prepModelforTFA(mymodel, ReactionDB, mymodel.CompartmentData);

%% Convert to TFA
    tmp = convToTFA(prepped_m, ReactionDB, [], 'DGo', [], min_obj);

    % Add net flux variables, which are equal to forwards flux - backwards flux
    % NF_rxn = F_rxn - B_rxn
    this_tmodel = addNetFluxVariables(tmp);

%% Solve tFA
    soltFA = solveTFAmodelCplex(this_tmodel);

%% Perform TVA
% this would be unnecessary?
    % Get the variables representing the net fluxes
    NF_ix = getAllVar(this_tmodel,{'NF'});
    tva = runTMinMax(this_tmodel, this_tmodel.varNames(NF_ix));

%% We add some generic data for cofactor concentrations
if par_conc_metabolites(run_number) == 0 % how it was
    metNames = {'adp_c', 'amp_c', 'atp_c'};
    C_lb = [1e-06, 2e-04, 1e-03]';
    C_ub = [7e-04, 3e-04, 5e-02]';
    LC_varNames = {'LC_adp_c', 'LC_amp_c', 'LC_atp_c'};
    % find the indices of these variables in the variable names of the tfa
    id_LC_varNames = find_cell(LC_varNames, this_tmodel.varNames);
    % Set to the model these log-concentration values
    this_tmodel.var_lb(id_LC_varNames) = log(C_lb);
    this_tmodel.var_ub(id_LC_varNames) = log(C_ub);
else
% Data from Ishii in mmol; assumed is the proper units for the toolbox. lb
% is 90% the experimental data, and ub 110%.
    metNames = metNames_exp;
%     C_exp = Conc_values_exp./1000; % so we convert from mM to M
    C_lb = 0.9.*C_exp;
    C_ub = 1.1.*C_exp;
    LC_varNames = {'LC_succoa_c', 'LC_trp-L_c', 'LC_dctp_c', 'LC_fdp_c', 'LC_fad_c', 'LC_met-L_c', 'LC_ile-L_c', 'LC_tyr-L_c', 'LC_datp_c', 'LC_f6p_c', 'LC_phe-L_c', 'LC_arg-L_c', 'LC_g1p_c', 'LC_his-L_c', 'LC_nadp_c', 'LC_pro-L_c', 'LC_asn-L_c', 'LC_leu-L_c', 'LC_pep_c', 'LC_dhap_c', 'LC_pyr_c', 'LC_amet_c', 'LC_thr-L_c', 'LC_malcoa_c', 'LC_accoa_c', 'LC_val-L_c', 'LC_s7p_c', 'LC_pydx5p_c', 'LC_ctp_c', 'LC_nadph_c', 'LC_gly_c', 'LC_ser-L_c', 'LC_ala-L_c', 'LC_asp-L_c', 'LC_lys-L_c', 'LC_3pg_c', 'LC_adp_c', 'LC_amp_c', 'LC_gtp_c', 'LC_utp_c', 'LC_gln-L_c', 'LC_nad_c', 'LC_atp_c', 'LC_glu-L_c'};
    % find the indices of these variables in the variable names of the tfa
    id_LC_varNames = find_cell(LC_varNames, this_tmodel.varNames);
    % Set to the model these log-concentration values
    this_tmodel.var_lb(id_LC_varNames) = log(C_lb);
    this_tmodel.var_ub(id_LC_varNames) = log(C_ub);
end

clear metNames
clear LC_varNames

stored_id_LC_varNames = id_LC_varNames;
clear id_LC_varNames

% Run another tva with the data
%     tva_wData = runTMinMax(this_tmodel, this_tmodel.varNames(NF_ix));

%% Get Thermodynamic displacements
% Add thermo_disp as variables
flagToAddLnThermoDisp = true;
gamma_model = convToTFA(prepped_m, ReactionDB, [], 'DGo', [], min_obj, [], flagToAddLnThermoDisp);
gamma_model = addNetFluxVariables(gamma_model);
gamma_model_backup = gamma_model; % this is to keep a copy for later use when gathering the results
NF_ix_gamma_model = getAllVar(gamma_model,{'NF'});
tva_gamma_model = runTMinMax(gamma_model, gamma_model.varNames(NF_ix_gamma_model));

solTFA = solveTFAmodelCplex(gamma_model);
LnGammaids = getAllVar(gamma_model,{'LnGamma'});
lngammaValues = solTFA.x(getAllVar(gamma_model,{'LnGammaids'}));

%% Sampling
% Sampling fluxes & concentrations
% Sampling fluxes is well established as it is an LP problem, and COBRA
% has the appropriate functions for it. However, the TFA formulation is
% MILP problem. Therefore, because there exists no MILP sampler, we need
% make the model LP, by eliminating the bi-directional reactions.

% We check if our model has bi-directional reactions
id_BD = find(tva_gamma_model(:,1)<-1e-9 & tva_gamma_model(:,2)>1e-9);
% Define a minimum flux value
minFluxValue = 1e-6;
if ~isempty(id_BD)
    % if there exist bi-directional reactions for which we have no further
    % information, we need to eliminate them. One way to select a set of
    % directionalities is to just set them sequentially.
    % Assign a minimal lower bound to growth
    gamma_model.var_lb(gamma_model.f==1) = minFluxValue;
    model_fixed_d = assignReactionDirectionalities(gamma_model, minFluxValue, min_obj, ReactionDB);
end

% Get the optimal FBA growth
solFBA = solveFBAmodelCplex(model_fixed_d);

% Settings of the sampler (COBRA)
soloptions.nWarmupPoints = 500;
soloptions.nFiles = 1;
soloptions.nPointsPerFile = 5000;
soloptions.nStepsPerPoint = 100;
soloptions.nPointsReturned = 5000;
soloptions.NvZeroTolerance = 1e-8;
soloptions.nFilesSkipped = 0;
soloptions.removeLoopsFlag = false;
soloptions.removeLoopSamplesFlag = true;

% Sample Fluxes
[modelSamplingFluxes, FluxSamples] = sampleCbModel_LCSB(model_fixed_d, 'FBA_model_samples', soloptions);

% Sample Concentrations
model_fixed_d_Conc = prepModelForConcSampling(model_fixed_d, solFBA.x);
model_fixed_d_Conc.A = [];
model_fixed_d_Conc = rmfield(model_fixed_d_Conc,'A');
[modelSamplingConcs, ConcSamples] = sampleCbModel_LCSB(model_fixed_d_Conc, 'ConcSampling', soloptions);

%% Gather data
%%%%% adjustment of Gibbs free energy values
% metabolites
this_run_adjustment_dG_mets(:, 1) = model_fixed_d_Conc.mets;
this_run_adjustment_dG_mets(:, 2) = num2cell(model_fixed_d_Conc.metDeltaGFtr);

internal_counter_mymodel = 1;
internal_counter_model_fixed_d_Conc = 1;

while internal_counter_model_fixed_d_Conc <= size(this_run_adjustment_dG_mets,1)
    if  isequal(adjustment_dG_mets{internal_counter_mymodel,1},this_run_adjustment_dG_mets{internal_counter_model_fixed_d_Conc,1});
        adjustment_dG_mets{internal_counter_mymodel,run_number+1} = this_run_adjustment_dG_mets{internal_counter_model_fixed_d_Conc,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_model_fixed_d_Conc = internal_counter_model_fixed_d_Conc + 1;
    else
        adjustment_dG_mets{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_model_fixed_d_Conc
clear this_run_adjustment_dG_mets

% reactions
this_run_adjustment_dG_rxns(:, 1) = model_fixed_d_Conc.rxns;
this_run_adjustment_dG_rxns(:, 2) = num2cell(model_fixed_d_Conc.rxnDeltaGR);

internal_counter_mymodel = 1;
internal_counter_model_fixed_d_Conc = 1;

while internal_counter_model_fixed_d_Conc <= size(this_run_adjustment_dG_rxns,1)
    if  isequal(adjustment_dG_rxns{internal_counter_mymodel,1},this_run_adjustment_dG_rxns{internal_counter_model_fixed_d_Conc,1});
        adjustment_dG_rxns{internal_counter_mymodel,run_number+1} = this_run_adjustment_dG_rxns{internal_counter_model_fixed_d_Conc,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_model_fixed_d_Conc = internal_counter_model_fixed_d_Conc + 1;
    else
        adjustment_dG_rxns{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_model_fixed_d_Conc
clear this_run_adjustment_dG_rxns

%%%%% estimated concentration values for metabolites
% estimated value. They are LC values (ln, called log() in matlab)!

list_varNames = gamma_model.varNames;
flux_varNames = solTFA.x;
data_result_TFA = table(list_varNames,flux_varNames);

this_run_pre_conc_est = data_result_TFA( startsWith(data_result_TFA.list_varNames,'LC_'), : );
this_run_pre_conc_est_cell = table2cell(this_run_pre_conc_est);

LC_names = cellstr(this_run_pre_conc_est_cell(:,1));
pre_conc_est(:,1) = strip(LC_names,'left','L');
pre_conc_est(:,1) = strip(pre_conc_est,'left','C');
pre_conc_est(:,1) = strip(pre_conc_est,'left','_');
ln_pre_conc_values(:,1) = cell2mat(this_run_pre_conc_est_cell(:,2));
mmol_pre_conc_values = exp(ln_pre_conc_values);
pre_conc_est(:,2) = num2cell(mmol_pre_conc_values); % expressed in mmol units

this_run_conc_est(:, 1) = pre_conc_est(:, 1);
this_run_conc_est(:, 2) = pre_conc_est(:, 2); % now we have two columns with the [met] for this run

internal_counter_mymodel = 1;
internal_counter_conc_est = 1;

while internal_counter_conc_est <= size(this_run_conc_est,1)
    if  isequal(conc_est{internal_counter_mymodel,1},this_run_conc_est{internal_counter_conc_est,1});
        conc_est{internal_counter_mymodel,run_number+1} = this_run_conc_est{internal_counter_conc_est,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_conc_est = internal_counter_conc_est + 1;
    else
        conc_est{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear list_varNames
clear flux_varNames
clear data_fluxes_TFA
clear this_run_pre_conc_est
clear this_run_pre_conc_est_cell
clear ln_pre_conc_values
clear mmol_pre_conc_values
clear pre_conc_est

clear internal_counter_mymodel
clear internal_counter_conc_est
clear this_run_conc_est

%%%%% extract flux values
% whole set of fluxes calculated in FBA (WITH FIXED DIRECTIONALITIES)
this_run_FBA(:, 1) = model_fixed_d.rxns;
this_run_FBA(:, 2) = num2cell(solFBA.x);

internal_counter_mymodel = 1;
internal_counter_model_fixed_d = 1;

while internal_counter_model_fixed_d <= size(this_run_FBA,1)
    if  isequal(FBA_fluxes{internal_counter_mymodel,1},this_run_FBA{internal_counter_model_fixed_d,1});
        FBA_fluxes{internal_counter_mymodel,run_number+1} = this_run_FBA{internal_counter_model_fixed_d,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_model_fixed_d = internal_counter_model_fixed_d + 1;
    else
        FBA_fluxes{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_model_fixed_d
clear this_run_FBA

% whole set of fluxes calculated in TFA
this_run_TFA(:, 1) = gamma_model.varNames;
this_run_TFA(:, 2) = num2cell(solTFA.x);
TFA_fluxes(:, 1) = gamma_model_backup.varNames; % backup before removing any reactions, so it should be the same for all the runs

internal_counter_mymodel = 1;
internal_counter_gamma_model = 1;

while internal_counter_gamma_model <= size(this_run_TFA,1)
    if  isequal(TFA_fluxes{internal_counter_mymodel,1},this_run_TFA{internal_counter_gamma_model,1});
        TFA_fluxes{internal_counter_mymodel,run_number+1} = this_run_TFA{internal_counter_gamma_model,2};
        internal_counter_mymodel = internal_counter_mymodel + 1;
        internal_counter_gamma_model = internal_counter_gamma_model + 1;
    else
        TFA_fluxes{internal_counter_mymodel,run_number+1} = [];
        internal_counter_mymodel = internal_counter_mymodel + 1;
    end
end

clear internal_counter_mymodel
clear internal_counter_gamma_model
clear this_run_TFA

% subset of NF_fluxes in TFA
list_name_reactions = TFA_fluxes(:, 1);
flux_values_reactions = TFA_fluxes(:, run_number+1);
data_fluxes_NF = table(list_name_reactions,flux_values_reactions);

this_run_NF_fluxes = data_fluxes_NF( startsWith(data_fluxes_NF.list_name_reactions,'NF_'), : );
this_run_NF_fluxes_cell = table2cell(this_run_NF_fluxes);

NF_names(:,1) = cellstr(this_run_NF_fluxes_cell(:,1));
NF_fluxes = strip(NF_names,'left','N');
NF_fluxes = strip(NF_fluxes,'left','F');
NF_fluxes = strip(NF_fluxes,'left','_');
NF_fluxes(:,run_number+1) = this_run_NF_fluxes_cell(:,2);

clear list_name_reactions
clear flux_values_reactions
clear data_fluxes_NF
clear this_run_NF_fluxes
clear this_run_NF_fluxes_cell

% equivalent FBA fluxes to TFA's NF subset
eq_FBA_NF(:,1) = NF_fluxes(:,1);

internal_counter_eq_FBA_NF = 1;
internal_counter_NF_fluxes = 1;

while internal_counter_eq_FBA_NF <= size(eq_FBA_NF,1)
    if  isequal(eq_FBA_NF{internal_counter_eq_FBA_NF ,1},NF_fluxes{internal_counter_NF_fluxes ,1});
        id_flux_temp = find_cell(eq_FBA_NF{internal_counter_eq_FBA_NF ,1}, model_fixed_d.rxns);
        eq_FBA_NF{internal_counter_eq_FBA_NF ,run_number+1} = solFBA.x(id_flux_temp);
        internal_counter_eq_FBA_NF = internal_counter_eq_FBA_NF + 1;
        internal_counter_NF_fluxes = internal_counter_NF_fluxes + 1;
        clear id_flux_temp
    else
        eq_FBA_NF{internal_counter_eq_FBA_NF ,run_number+1} = [];
        internal_counter_eq_FBA_NF  = internal_counter_eq_FBA_NF + 1;
    end
end

clear internal_counter_eq_FBA_NF 
clear internal_counter_NF_fluxes 

%% Calculate correlation coefficients
%%% Metabolomics
% subset of estimated concentration values that matches with the available
% metabolomics data from Ishii 2007
id_metNames_exp = find_cell(metNames_exp, original_mets);
match_conc_values = conc_est(id_metNames_exp,:);

this_run_match_conc_values = cell2mat(match_conc_values(:,run_number+1));  % we extract the estimated concentration values for this run
concentration_experimental = C_exp';
correlation_coef_matrix_metabolomics = corrcoef(this_run_match_conc_values,concentration_experimental);
correlation_coef_metabolomics = correlation_coef_matrix_metabolomics(2,1);
comparison_metabolomics(run_number,2) = correlation_coef_metabolomics;

clear id_metNames_exp
clear this_run_match_conc_values
clear correlation_coef_matrix_metabolomics
clear correlation_coef_metabolomics

%%% Fluxomics
% subset of TFA fluxes that can be compared with Ishii's 13C-MFA
% names_comparison_fluxes_TFA = {"NF_PGK", "NF_PGM", "NF_FBP", "NF_RPI", "NF_ACALD", "NF_ALCD2x", "NF_EDD", "NF_EDA", "NF_PTAr", "NF_LDH_D", "NF_TKT2", "NF_ME1", "NF_ME2", "NF_TKT1", "NF_TALA", "NF_RPE", "NF_PPC", "NF_ICL", "NF_MALS", "NF_G6PDH2r", "NF_PGL", "NF_GND", "NF_PYK", "NF_AKGDH", "NF_SUCOAS", "NF_ICDHyr", "NF_SUCDi", "NF_FUM", "NF_PGI", "NF_FBA", "NF_TPI", "NF_CS", "NF_ACONTa", "NF_ACONTb", "NF_MDH", "NF_GLCptspp", "NF_PDH", "NF_ENO", "NF_GAPD", "NF_ACKr"}  
names_comparison_fluxes_TFA = {"NF_ACALD", "NF_ACONTa",  "NF_ACONTb", "NF_ACKr", "NF_AKGDH", "NF_ALCD2x", "NF_CS", "NF_EDA", "NF_EDD", "NF_ENO", "NF_FBA", "NF_FUM", "NF_G6PDH2r", "NF_GAPD", "NF_GLCptspp", "NF_GND", "NF_ICDHyr", "NF_ICL", "NF_LDH_D", "NF_MALS", "NF_MDH", "NF_ME1", "NF_ME2", "NF_PDH", "NF_PFK", "NF_PGI", "NF_PGK", "NF_PGL", "NF_PGM", "NF_PPC", "NF_PTAr", "NF_PYK", "NF_RPE", "NF_RPI", "NF_SUCDi", "NF_SUCOAS", "NF_TALA", "NF_TKT1", "NF_TKT2", "NF_TPI"}  
id_comparison_fluxes_TFA = find_cell(names_comparison_fluxes_TFA, gamma_model.varNames);
this_run_fluxes_TFA_mmol_gDCW_h = solTFA.x(id_comparison_fluxes_TFA);
fluxes_TFA_mmol_gDCW_h(:,run_number) = cell2mat(num2cell(this_run_fluxes_TFA_mmol_gDCW_h));

name_uptake_glucose = {'NF_GLCtex'};
id_uptake_glucose_gamma = find_cell(name_uptake_glucose, gamma_model.varNames);
this_run_NF_uptake_glucose = solTFA.x(id_uptake_glucose_gamma);
this_run_fluxes_TFA_normalized = (this_run_fluxes_TFA_mmol_gDCW_h./this_run_NF_uptake_glucose)*100; % fluxes are normalised in "%" by considering the uptake of glucose, so a comparison is enabled
fluxes_TFA_normalized(:,run_number) = cell2mat(num2cell(this_run_fluxes_TFA_normalized));

correlation_coef_matrix_13C_TFA = corrcoef(fluxes_13C, this_run_fluxes_TFA_normalized);
correlation_coef_13C_TFA = correlation_coef_matrix_13C_TFA(2,1);
comparison_fluxes_13C_TFA(run_number,2) = correlation_coef_13C_TFA;

clear id_comparison_fluxes_TFA
clear this_run_fluxes_TFA_mmol_gDCW_h
clear id_uptake_glucose_gamma
clear correlation_coef_matrix_13C_TFA

% subset of FBA fluxes that can be compared with Ishii's 13C-MFA
% names_comparison_fluxes_FBA = {"PGK", "PGM", "FBP", "RPI", "ACALD", "ALCD2x", "EDD", "EDA", "PTAr", "LDH_D", "TKT2", "ME1", "ME2", "TKT1", "TALA", "RPE", "PPC", "ICL", "MALS", "G6PDH2r", "PGL", "GND", "PYK", "AKGDH", "SUCOAS", "ICDHyr", "SUCDi", "FUM", "PGI", "FBA", "TPI", "CS", "ACONTa", "ACONTb", "MDH", "GLCptspp", "PDH", "ENO", "GAPD", "ACKr"} 
names_comparison_fluxes_FBA = {"ACALD", "ACONTa", "ACONTb", "ACKr", "AKGDH", "ALCD2x", "CS", "EDA", "EDD", "ENO", "FBA", "FUM", "G6PDH2r", "GAPD", "GLCptspp", "GND", "ICDHyr", "ICL", "LDH_D", "MALS", "MDH", "ME1", "ME2", "PDH", "PFK", "PGI", "PGK", "PGL", "PGM", "PPC", "PTAr", "PYK", "RPE", "RPI", "SUCDi", "SUCOAS", "TALA", "TKT1", "TKT2", "TPI"} 
id_comparison_fluxes_FBA = find_cell(names_comparison_fluxes_FBA, model_fixed_d.rxns);
this_run_fluxes_FBA_mmol_gDCW_h = solFBA.x(id_comparison_fluxes_FBA);
fluxes_FBA_mmol_gDCW_h(:,run_number) = cell2mat(num2cell(this_run_fluxes_FBA_mmol_gDCW_h));

name_uptake_glucose = {'GLCtex'};
id_uptake_glucose_model_fixed_d = find_cell(name_uptake_glucose, model_fixed_d.rxns);
this_run_FBA_uptake_glucose = solFBA.x(id_uptake_glucose_model_fixed_d);
this_run_fluxes_FBA_normalized = (this_run_fluxes_FBA_mmol_gDCW_h./this_run_FBA_uptake_glucose)*100; % fluxes are normalised in "%" by considering the uptake of glucose, so a comparison is enabled
fluxes_FBA_normalized(:,run_number) = cell2mat(num2cell(this_run_fluxes_FBA_normalized));

correlation_coef_matrix_13C_FBA = corrcoef(fluxes_13C, this_run_fluxes_FBA_normalized);
correlation_coef_13C_FBA = correlation_coef_matrix_13C_FBA(2,1);
comparison_fluxes_13C_FBA(run_number,2) = correlation_coef_13C_FBA;

clear id_comparison_fluxes_FBA
clear this_run_fluxes_FBA_mmol_gDCW_h
clear id_uptake_glucose_model_fixed_d
clear correlation_coef_matrix_13C_FBA

% equivalent FBA fluxes with TFA's NF subset
correlation_coef_matrix_FBA_TFA = corrcoef(this_run_fluxes_FBA_normalized,this_run_fluxes_TFA_normalized);
correlation_coef_FBA_TFA = correlation_coef_matrix_FBA_TFA(2,1);
comparison_fluxes_FBA_TFA(run_number,2) = correlation_coef_FBA_TFA;

clear correlation_coef_matrix_FBA_TFA
clear this_run_fluxes_FBA_normalized

% collecting all the info 
comparison_fluxes_total(run_number,2) = correlation_coef_13C_FBA;
comparison_fluxes_total(run_number,3) = correlation_coef_13C_TFA;
comparison_fluxes_total(run_number,4) = correlation_coef_FBA_TFA;

clear correlation_coef_13C_FBA
clear correlation_coef_13C_TFA
clear correlation_coef_FBA_TFA

%%% Bioprocessing data
growth_rate_FBA = {'Ec_biomass_iJO1366_WT_53p95M'};
id_growth_rate_FBA = find_cell(growth_rate_FBA, model_fixed_d.rxns);

growth_rate_TFA = {'NF_Ec_biomass_iJO1366_WT_53p95M'};
id_growth_rate_TFA = find_cell(growth_rate_TFA, gamma_model.varNames);

% biomass flux info
biomass_flux_yield(run_number,2) = this_run_FBA_uptake_glucose;
biomass_flux_yield(run_number,3) = solFBA.x(id_growth_rate_FBA);
biomass_flux_yield(run_number,4) = biomass_flux_yield(run_number,3)/biomass_flux_yield(run_number,2);
biomass_flux_yield(run_number,5) = this_run_NF_uptake_glucose;
biomass_flux_yield(run_number,6) = solTFA.x(id_growth_rate_TFA);
biomass_flux_yield(run_number,7) = biomass_flux_yield(run_number,6)/biomass_flux_yield(run_number,5);

clear this_run_FBA_uptake_glucose
clear this_run_NF_uptake_glucose

save def_e_coli_loop

catch
    disp('there was an error')
    failed_run_track(run_number,2) = run_number;
end

end
%toc

save def_e_coli

%% Yields

for run_number = 1:nruns

% yield values
yield_values(run_number,2) = yield_exp;                                                                             % g DCW/ g glucose consumed
yield_values(run_number,3) = yield_theoret;                                                                         % g DCW/ g glucose consumed
yield_values(run_number,4) = (biomass_flux_yield(run_number,3)/biomass_flux_yield(run_number,2)*(1000/MW_glucose)); % yield FBA, g DCW/ g glucose consumed
yield_values(run_number,5) = (biomass_flux_yield(run_number,6)/biomass_flux_yield(run_number,5)*(1000/MW_glucose)); % yield TFA, g DCW/ g glucose consumed

% deviation from experimental yield values
    %not in absolute value!
yield_deviation(run_number,2) = 100*((yield_values(run_number,2)-yield_values(run_number,3))/yield_values(run_number,2)); % % dev yield theoretical from yield_exp
yield_deviation(run_number,3) = 100*((yield_values(run_number,2)-yield_values(run_number,4))/yield_values(run_number,2)); % % dev yield FBA from yield_exp
yield_deviation(run_number,4) = 100*((yield_values(run_number,2)-yield_values(run_number,5))/yield_values(run_number,2)); % % dev yield TFA from yield_exp

end
%% concordance analysis
correlation_coef_13C_TFA = comparison_fluxes_total(:,3);
correlation_coef_metabolomics = comparison_metabolomics(:,2);

% it is better to round to the 3rd floating number (differences are bigger
% at the metabolomics than at the fluxomics level)

round_correlation_coef_13C_TFA = round(correlation_coef_13C_TFA,3)
round_correlation_coef_metabolomics = round(correlation_coef_metabolomics,3)

X = [round_correlation_coef_13C_TFA round_correlation_coef_metabolomics];
W = KendallCoef(X);

%% Joint ranking
% considering the ranks obtained in the previous step, we can now weight
% both criteria: goodnes-of-fit at the fluxomics and at the metabolomics
% levels. Hence, position #1 will receive 0 points and position #64 50
% point.
% 
% according to 'tiedrank', rank are in ascending order (thus, the last one
% would be the run with the best correlation)
RankMatrix = tiedrank(X);
rank_flux = RankMatrix(:,1);
rank_metab = RankMatrix(:,2);
w_rank_flux = 0.7937*rank_flux - 0.7937;
w_rank_metab =  0.7937*rank_metab - 0.7937;
sum_w_rank = w_rank_flux + w_rank_metab;
rank_sum_w_rank = tiedrank(sum_w_rank);

total_ranking = zeros(nruns,9);
total_ranking(:,1) = linspace(1,nruns,nruns);
total_ranking(:,2) = correlation_coef_13C_TFA;
total_ranking(:,3) = correlation_coef_metabolomics;
total_ranking(:,4) = rank_flux;
total_ranking(:,5) = rank_metab;
total_ranking(:,6) = w_rank_flux;
total_ranking(:,7) = w_rank_metab;
total_ranking(:,8) = sum_w_rank;
total_ranking(:,9) = rank_sum_w_rank;

% find the runs with the highest rank_sum_weight
maxval = max(rank_sum_w_rank);
idx = find(rank_sum_w_rank == maxval);

%% Directionalities pattern variation TFA (match w/ 13C-MFA data)
fluxes_TFA_normalized_total = [fluxes_TFA_normalized fluxes_13C'] % adding known 13C fluxes as run #65
fluxes_TFA_normalized_pattern = fluxes_TFA_normalized_total;
total_number_index = size(fluxes_TFA_normalized_total,1)*size(fluxes_TFA_normalized_total,2);

for index_TFA = 1:total_number_index
    if fluxes_TFA_normalized_pattern(index_TFA) > 0
        fluxes_TFA_normalized_pattern(index_TFA) = 1;
    elseif fluxes_TFA_normalized_pattern(index_TFA) < 0
        fluxes_TFA_normalized_pattern(index_TFA) = -1;
    else
        fluxes_TFA_normalized_pattern(index_TFA) = 0;
    end
end

% fluxes going forward
fluxes_TFA_normalized_pattern_green = changem(fluxes_TFA_normalized_pattern, NaN, [0]);
fluxes_TFA_normalized_pattern_green = changem(fluxes_TFA_normalized_pattern_green, NaN, [-1]);

% fluxes going reverse
fluxes_TFA_normalized_pattern_red = changem(fluxes_TFA_normalized_pattern, NaN, [0]);
fluxes_TFA_normalized_pattern_red = changem(fluxes_TFA_normalized_pattern_red, NaN, [1]);

% fluxes with value of 0
fluxes_TFA_normalized_pattern_white = changem(fluxes_TFA_normalized_pattern, NaN, [-1]);
fluxes_TFA_normalized_pattern_white = changem(fluxes_TFA_normalized_pattern_white, NaN, [1]);

y_values = linspace(1,nruns+1,nruns+1)';     % run number
x_values = linspace(1,size(fluxes_13C,2),size(fluxes_13C,2))';
x_list = [num2cell(x_values) names_comparison_fluxes_TFA'];
[X,Y] = meshgrid(x_values,y_values);

z_values_g = fluxes_TFA_normalized_pattern_green(x_values, y_values);
z_values_r = fluxes_TFA_normalized_pattern_red(x_values, y_values);
z_values_w = fluxes_TFA_normalized_pattern_white(x_values, y_values);

Z_g = z_values_g.';
stem3(X,Y,Z_g,'MarkerFaceColor','g')
hold on

Z_r = z_values_r.';
stem3(X,Y,Z_r,'MarkerFaceColor','r', 'LineStyle', 'none')
hold on

Z_w = z_values_w.';
stem3(X,Y,Z_w,'MarkerFaceColor','w')
hold on

title('Pattern of reaction directionalities');
set(gca,'fontname','arial') 
xlabel('Reaction number (subset)')
ylabel('Run number')

clear h
%% export results
adjustment_dG_mets_table = cell2table(adjustment_dG_mets);
writetable(adjustment_dG_mets_table,'adjustment_dG_mets_table.txt','Delimiter',' ');  
type 'adjustment_dG_mets_table.txt';

adjustment_dG_rxns_table = cell2table(adjustment_dG_rxns);
writetable(adjustment_dG_rxns_table,'adjustment_dG_rxns_table.txt','Delimiter',' ');  
type 'adjustment_dG_rxns_table.txt';

conc_est_table = cell2table(conc_est);
writetable(conc_est_table,'conc_est_table.txt','Delimiter',' ');  
type 'conc_est_table.txt';

match_conc_values_table = cell2table(match_conc_values);
writetable(match_conc_values_table,'match_conc_values_table.txt','Delimiter',' ');  
type 'match_conc_values_table.txt';

comparison_metabolomics_table = array2table(comparison_metabolomics,...
    'VariableNames',{'Test_number' 'Correlation_coefficient'});
writetable(comparison_metabolomics_table,'comparison_metabolomics_table.txt','Delimiter',' ');  
type 'comparison_metabolomics_table.txt';

FBA_fluxes_table = cell2table(FBA_fluxes);
writetable(FBA_fluxes_table,'FBA_fluxes_table.txt','Delimiter',' ');  
type 'FBA_fluxes_table.txt';

fluxes_FBA_mmol_gDCW_h_table = array2table(fluxes_FBA_mmol_gDCW_h)
writetable(fluxes_FBA_mmol_gDCW_h_table,'fluxes_FBA_mmol_gDCW_h_table.txt','Delimiter',' ');  
type 'fluxes_FBA_mmol_gDCW_h_table.txt';

fluxes_FBA_normalized_table = array2table(fluxes_FBA_normalized)
writetable(fluxes_FBA_normalized_table,'fluxes_FBA_normalized_table.txt','Delimiter',' ');  
type 'fluxes_FBA_normalized_table.txt';

TFA_fluxes_table = cell2table(TFA_fluxes);
writetable(TFA_fluxes_table,'TFA_fluxes_table.txt','Delimiter',' ');  
type 'TFA_fluxes_table.txt';

fluxes_TFA_mmol_gDCW_h_table = array2table(fluxes_TFA_mmol_gDCW_h)
writetable(fluxes_TFA_mmol_gDCW_h_table,'fluxes_TFA_mmol_gDCW_h_table.txt','Delimiter',' ');  
type 'fluxes_TFA_mmol_gDCW_h_table.txt';

fluxes_TFA_normalized_table = array2table(fluxes_TFA_normalized)
writetable(fluxes_TFA_normalized_table,'fluxes_TFA_normalized_table.txt','Delimiter',' ');  
type 'fluxes_TFA_normalized_table.txt';

comparison_fluxes_total_table = array2table(comparison_fluxes_total,...
    'VariableNames',{'Test_number' 'correlation_coef_13C_FBA' 'correlation_coef_13C_TFA' 'correlation_coef_FBA_TFA'});
writetable(comparison_fluxes_total_table,'comparison_fluxes_table.txt','Delimiter',' ');  
type 'comparison_fluxes_table.txt';

biomass_flux_yield_table = array2table(biomass_flux_yield,...
    'VariableNames',{'Test_number' 'FBA_Uptake_Glucose' 'FBA_Growth_Rate' 'FBA_Y' 'TFA_Uptake_Glucose' 'TFA_Growth_Rate' 'TFA_Y'});
writetable(biomass_flux_yield_table,'biomass_yield_table.txt','Delimiter',' ');  
type 'biomass_yield_table.txt';

yield_values_table = array2table(yield_values,...
    'VariableNames',{'Test_number' 'Experimental' 'Theoretical' 'FBA' 'TFA'})
writetable(yield_values_table,'yield_values_table.txt','Delimiter',' ');  
type 'yield_values_table.txt';

yield_deviation_table = array2table(yield_deviation,...
    'VariableNames',{'Test_number' 'dev_theoretical' 'dev_FBA' 'dev_TFA'}) % deviations are in %
writetable(yield_deviation_table,'yield_deviation_table.txt','Delimiter',' ');  
type 'yield_deviation_table.txt';

total_ranking_table = array2table(total_ranking,...
    'VariableNames',{'Run_number' 'correlation_coef_13C_TFA' 'correlation_coef_metabolomics' 'rank_flux' 'rank_metab' 'w_rank_flux' 'w_rank_metab' 'sum_w_rank' 'rank_sum_w_rank'}) % deviations are in %
writetable(total_ranking_table,'total_ranking_table.txt','Delimiter',' ');  
type 'total_ranking_table.txt';

save def_e_coli_fin


