function pKa_adj = calcpKa(name,index,ionicStr)
% calculate adjusted pKa value based on ionic strength
% name can be a specie name or pKa value itself

% Script based on matTFA by Salvy et al. 2018
% (https://doi.org/10.1093/bioinformatics/bty499)
% Modified by Claudio Tomi-Andrino (2020)

global pK;
global data;
global ionic_strength
global temperature
global prefactor_A
global equation_method

I = ionic_strength;

t = temperature;
TEMPERATURE = t-phc.T0; % K

pfA = prefactor_A;

if equation_method == 0
    q1 = Debye_Huckel_B;
    q2 = 0;
else
    q1 = 1;
    q2 = 1;
end

if nargin == 2
   Kvalue = 1;
end

% if class(Kvalue) == 'double'
%    Kvalue = dbl2str(Kvalue);
% else
%    Kvalue = 1;
% end

% if name is a specie, then we check if it exists before going further

if existInStruct(pK,name)

    if class(name) == 'char'
        tmp = strcat('pK.',name,'{',dbl2str(index),'}');
        pKa = eval(tmp);
    end
    
    name = lower(name);
    charge = getspCharge(name,index);
    pH = 7;
    sigmanusq = 2*charge; %charge^2 + 1 - (charge-1)^2;
    lnkzero = log(10^-pKa);
   
    pKa_adj = -(lnkzero - ((pfA*sigmanusq)*((sqrt(I)/(1+q1*sqrt(I)))-(q2*0.3*I))))/log(10);

%     pKa_adj = -(lnkzero - (1.17582*ionicStr^0.5)*sigmanusq/(1+1.6*ionicStr^0.5))/log(10);

else

    pKa_adj = 'NA';
    fprintf(1,'specie %s not found in list of pKa values\n',name);
    return;

end
    

end