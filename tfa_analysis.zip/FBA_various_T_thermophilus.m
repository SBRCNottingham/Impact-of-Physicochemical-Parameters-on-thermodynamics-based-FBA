clc
clear
clear global
restoredefaultpath

tic

%% Script based on matTFA by Salvy et al. 2018
% (https://doi.org/10.1093/bioinformatics/bty499)
% Modified by Claudio Tomi-Andrino (2020)
% This script allows to test the feasibility of FBA and TFA under different
% conditions of uptake rate (value included in the toolbox/experimental),
% specific growth rate (unconstrained/constrained) and objective function
% (maximization of biomass yield/minimization of sum of fluxes). In order
% to do so:
% - experimental data from Cordova et al. 2017
% - parameters defined as 'global variables' so the script is compatible with
% the modified files required for mod-matTFA generated in this study
% - Using some functions from matTFA (Salvy et al. 2018) (find_cell).

% In matTFA, FBA is solved 1) optimizeCbModel and 2) solveFBAmodelCplex,
% being the latter a version created for that paper. Here we use (1).
% Including both ways to solve the LP, so we can test any potential
% differences.

%% Some experimental data
% Experimental data from Cordova et al. 2017
uptake_glucose_exp = 3.7;  % mmol/gDCW-h
growth_rate_exp = 0.22;      % h-1
MW_glucose = 180;           % g/mol
yield_exp = (growth_rate_exp/uptake_glucose_exp)*(1000/MW_glucose); % g DCW/g glucose consumed

% the theoretical biomass yield can also be calculated
Y_X_ATP = 10.3;              % g DCW/mol ATP (Neidhart 1996, Shuler 2002) for aerobic fermentations
ATP_Glucose = 2/MW_glucose;  % moles of ATP per mol of glucose (expressed in gram units)
yield_theoret = Y_X_ATP * ATP_Glucose;       % g DCW/g glucose consumed

% fluxomics (considering there are lumped reactions defined in the inverse
% direction in the GSM; thus, there are repeated flux values with different
% sign)
fluxes_cordova = ["GAP <=> 3PG + ATP + NADH (net)", "3PG <=> PEP (net)", "3PG <=> PEP (net)", "DHAP <=> GAP (net)", "Cit <=> ICit (net)", "Fum <=> Mal (net)", "SucCoA <=> Suc + ATP (net)", "NH3.ext -> NH3", "OAC + Glu -> Asp + AKG", "Ru5P <=> X5P (net)", "Ru5P <=> R5P (net)", "Ac-> Ac.ext", "Glyox + AcCoA -> Mal", "ICit <=> Glyox + Suc (net)", "G6P -> 6PG + NADPH", "KDPG -> Pyr + GAP", "G6P -> 6PG + NADPH", "G6P -> 6PG + NADPH", "6PG -> KDPG", "Mal -> Pyr + CO2 + NADPH", "SO4.ext -> SO4", "AcCoA <=> Ac + ATP (net)", "0.615 Ala + 0.354 Arg + 0.185 Asn + 0.185 Asp + 0.110 Cys + 0.301 Glu + 0.301 Gln + 0.594 Gly + 0.104 His + 0.158 Ile + 0.554 Leu + 0.298 Lys + 0.089 Met + 0.200 Phe + 0.331 Pro + 0.295 Ser + 0.309 Thr + 0.068 Trp + 0.198 Tyr + 0.395 Val + 0.273 G6P + 0.071 F6P + 0.186 GAP + 0.522 3PG + 0.051 PEP + 0.083 Pyr + 0.087 AKG + 0.230 OAC + 0.489 R5P + 3.510 AcCoA + 34.402 ATP + 6.985 NADPH + 0.338 MEETHF � 42.882 Biomass + 1.050 NADH", "OAC + ATP -> PEP + CO2", "PEP + CO2 -> OAC", "AKG -> SucCoA + CO2 + NADH", "Suc <=> Fum + FADH2 (net)", "Mal <=> OAC + NADH (net)", "OAC + AcCoA -> Cit", "Cit <=> ICit (net)", "ICit -> AKG + CO2 + NADPH", "ICit -> AKG + CO2 + NADPH", "F6P + ATP <=> FBP (net)", "FBP <=> DHAP + GAP (net)", "G6P <=> F6P (net)", "PEP <=> Pyr + ATP (net)", "GAP <=> 3PG + ATP + NADH (net)", "O2.ext -> O2", "CO2 -> CO2.ext"];
fluxes_13C = [-180.3, -168.1, -168.1, -92.5, -84.5, -75.2, -71.0, -59.5, -10.3, -4.6, -4.6, -0.2, 0.0, 0.0, 0.3, 0.3, 0.3, 0.3, 0.3, 1.1, 1.5, 6.3, 7.7, 28.1, 50.5, 71.7, 71.7, 74.2, 84.5, 84.5, 84.5, 84.5, 92.5, 92.5, 97.6, 138.1, 180.3, 243.9, 270.4]'; 
%% Generation of tests
% preparing a legend matrix so that each column corresponds to a parameter,
% the first row to the lower value (0) and the second row the upper value
% (1)
npar = 4; 
nruns = 2^(npar);

d = (0:nruns-1)';
b = de2bi(d);
d = (1:nruns)'; % adapt it to runs 1 to nruns
full_tests = [d b];

clear b

% extract vectors from full_parameters so that paremeter 1 is column 2,
% parameter 2 is column 3,(...). No need to extract to the run number, 
% since is the same as the row number. Thus I can later call the value of 
% the parameter at the run I am working with. In the original toolbox some 
% parameters were manually included in each function (e.g. temperature); 
par_uptake = full_tests(:,2);
par_growth_rate = full_tests(:,3);
par_objective_function = full_tests(:,4);
par_solver = full_tests(:,5);

% % prepare arrays to save results. Since strings cannot be stored in matrices, 
% % I will operate with everything and export it altogether at the end 
% biomass_flux_yield = zeros(nruns,7);
% yield_values = zeros(nruns,5);
% yield_deviation = zeros(nruns,4);
comparison_fluxes_13C_FBA = zeros(nruns, 2);
failed_run_track = zeros(nruns,2);

% biomass_flux_yield(:,1) = d; 
% yield_values = d;
% yield_deviation = d;
comparison_fluxes_13C_FBA(:,1) = d;
failed_run_track(:,1) = d;
clear d

%% Load the model
addpath(genpath(fullfile('..','..','models')))
tmp = load(fullfile('..','..','models','Thermus_thermophilus_HB27_iTT548_adapted_June_19.mat'));
mymodel = tmp.model;
clear tmp

original_rxns = mymodel.rxns;
FBA_fluxes(:, 1) = original_rxns;

%% Apply some preliminary constraints
% Load dependencies (necessary for the function 'findcell')
addpath(genpath(fullfile('..','..','matTFA')))
addpath(genpath(fullfile('..','..','ext')))
    
biomass_reaction = {'R001'}; 
id_biomass_reaction = find_cell(biomass_reaction, mymodel.rxns);
% constrained later
mymodel.c(id_biomass_reaction) = 1;

uptake_glucose = {'R786'};
id_uptake_glucose = find_cell(uptake_glucose, mymodel.rxns);
% constrained later

% Limit the bounds of the fluxes that are higher than 100 or lower than
% -100 mmol/(gDW * h)
if any(mymodel.lb<-100) || any(mymodel.ub>100)
    mymodel.lb(mymodel.lb<-100) = -100;
    mymodel.ub(mymodel.ub>+100) = +100;
end

%% loop to calculate
for run_number = 1:nruns
try
    %% Set some parameters    
if par_uptake(run_number,1) == 0
    mymodel.lb(id_uptake_glucose) = -11.11; % estimated from assuming constant biomass yield (Cordova et al. 2017) and the growth rate from the GSM
    mymodel.ub(id_uptake_glucose) = 0;  
else
    mymodel.lb(id_uptake_glucose) = -1.1*uptake_glucose_exp; % experimental value from Cordova et al. 2017
    mymodel.ub(id_uptake_glucose) = 0;  
end

% constraining the specific growth rate (otherwise, it stays free)
if par_growth_rate(run_number,1) == 0
    mymodel.lb(id_biomass_reaction) = 0.50*growth_rate_exp; % give some margin
    mymodel.ub(id_biomass_reaction) = 0.60; % value predicted with glucose uptake of 11.11 (GSM paper)
else
    mymodel.lb(mymodel.c==1) = growth_rate_exp;
    mymodel.ub(mymodel.c==1) = growth_rate_exp;
end

%% Solver and FBA
try
if par_solver(run_number,1) == 0
        % Load dependencies
    addpath(genpath(fullfile('..','..','matTFA')))
    addpath(genpath(fullfile('..','..','ext')))
    cplex_loaded = load_cplex; % the original way in matTFA
   
    if ~cplex_loaded
        error('CPLEX not found')
    end   
    changeCobraSolver('cplex_direct')
    
    try
        if par_objective_function(run_number,1) == 0
            solFBA = solveFBAmodelCplex(mymodel); % maximizing the biomass yield  
        else
            solFBA = solveFBAmodelCplex(mymodel,'min','one'); % minimizing the sum of fluxes
       disp('there was an error')
        end
    catch
        failed_run_track(run_number,2) = run_number;
    end
    if solFBA.f == 0
        failed_run_track(run_number,2) = run_number;
    end
 
else % par_solver(run_number,1) = 1
    addpath(genpath(fullfile('..','tutorials','cobratoolbox')))
    try
        initCobraToolbox
    catch
    end
      % changeCobraSolver('ibm_cplex') % not tested out fro MATLAB 2018!
    try
        if par_objective_function(run_number,1) == 0
            solFBA = optimizeCbModel(mymodel, 'max'); % maximizing the biomass yield  
        else
            solFBA = optimizeCbModel(mymodel,'min','one'); % minimizing the sum of fluxes
        end
    catch
        failed_run_track(run_number,2) = run_number;
    end
    if solFBA.f == 0
        failed_run_track(run_number,2) = run_number;
    end
        
end
FBA_fluxes(:,run_number+1) = num2cell(solFBA.x);
end
catch
    disp('there was an error')
    failed_run_track(run_number,2) = run_number;
end

   %% Calculate correlation coefficients
%%% Fluxomics
% subset of FBA fluxes that can be compared with Cordova's 13C-MFA
addpath(genpath(fullfile('..','..','matTFA','utilities')))
try
names_comparison_fluxes_FBA = {"R010", "R011", "R012", "R008", "R021", "R027", "R025", "R771", "R198", "R033", "R034", "R722", "R420", "R425", "R029", "R041", "R710", "R713", "R714", "R660", "R719", "R016", "R001", "R014", "R621", "R024", "R026", "R028", "R019", "R020", "R022", "R023", "R006", "R007", "R005", "R013", "R009", "R718", "R721"}; 
id_comparison_fluxes_FBA = find_cell(names_comparison_fluxes_FBA, mymodel.rxns);
this_run_fluxes_FBA_mmol_gDCW_h = solFBA.x(id_comparison_fluxes_FBA);
fluxes_FBA_mmol_gDCW_h(:,run_number) = cell2mat(num2cell(this_run_fluxes_FBA_mmol_gDCW_h));

name_uptake_glucose = {'R786'};
id_uptake_glucose_mymodel = find_cell(name_uptake_glucose, mymodel.rxns);
this_run_FBA_uptake_glucose = abs(solFBA.x(id_uptake_glucose_mymodel)); % test adjusting sign of uptake
this_run_fluxes_FBA_normalized = (this_run_fluxes_FBA_mmol_gDCW_h./this_run_FBA_uptake_glucose)*100; % fluxes are normalised in "%" by considering the uptake of glucose, so a comparison is enabled
fluxes_FBA_normalized(:,run_number) = cell2mat(num2cell(this_run_fluxes_FBA_normalized));

correlation_coef_matrix_13C_FBA = corrcoef(fluxes_13C, this_run_fluxes_FBA_normalized);
correlation_coef_13C_FBA = correlation_coef_matrix_13C_FBA(2,1);
comparison_fluxes_13C_FBA(run_number,2) = correlation_coef_13C_FBA;

clear id_comparison_fluxes_FBA
clear this_run_fluxes_FBA_mmol_gDCW_h
clear id_uptake_glucose_model_fixed_d
clear correlation_coef_matrix_13C_FBA
clear correlation_coef_13C_FBA

catch
end
clear solFBA
end
toc