%% Script to compare the predicted metabolite concentrations values using 
% an eQuilibrator-like approach (with flux distributions obtained from TFA 
% in this study) with the experimental data from Ishii et al. 2007
% Claudio Tomi-Andrino (2020)

%% Import necessary functions
addpath(genpath(fullfile('matTFA')))

%% Experimental metabolite concentrations values
metNames_exp = {'succoa_c', 'trp-L_c', 'dctp_c', 'fdp_c', 'fad_c', 'met-L_c', 'ile-L_c', 'tyr-L_c', 'datp_c', 'f6p_c', 'phe-L_c', 'arg-L_c', 'g1p_c', 'his-L_c', 'nadp_c', 'pro-L_c', 'asn-L_c', 'leu-L_c', 'pep_c', 'dhap_c', 'pyr_c', 'amet_c', 'thr-L_c', 'malcoa_c', 'accoa_c', 'val-L_c', 's7p_c', 'pydx5p_c', 'ctp_c', 'nadph_c', 'gly_c', 'ser-L_c', 'ala-L_c', 'asp-L_c', 'lys-L_c', '3pg_c', 'adp_c', 'amp_c', 'gtp_c', 'utp_c', 'gln-L_c', 'nad_c', 'atp_c', 'glu-L_c'};
Conc_values_exp = [0.009359543, 0.010731977, 0.025375612, 0.025929355, 0.026680487, 0.031787628, 0.033148308, 0.034456205, 0.040279403, 0.043890575, 0.056293859, 0.056846432, 0.063547658, 0.078509817, 0.087335543, 0.094154326, 0.111930146, 0.113621109, 0.120087663, 0.12623261, 0.128204905, 0.130297951, 0.147806892, 0.158776506, 0.192901247, 0.200709788, 0.221586771, 0.243517494, 0.259172413, 0.267429669, 0.289555417, 0.308649675, 0.320280616, 0.328512449, 0.334719094, 0.506263157, 0.56225118, 0.570592568, 0.627229356, 0.635722343, 0.641449567, 0.72017617, 1.232156107, 3.47369374]'; % metabolite concentration values (mmol)

%% MDF with I = 0 M (FBA)
results_equilibrator_like = importdata('FBA_results_0.txt');
metNames_sim = results_equilibrator_like.textdata;
metNames_sim_clean_1 = metNames_sim(:,1);
metNames_sim_clean_2 = metNames_sim_clean_1(2:end);
Conc_values_sim = results_equilibrator_like.data;
id_metNames_exp = find_cell(metNames_exp, metNames_sim_clean_2);
number_matches = size(id_metNames_exp,2);
name_matches = metNames_sim_clean_2(id_metNames_exp);
id_metNames_match = find_cell(name_matches, metNames_exp);
Conc_values_exp_match = Conc_values_exp(id_metNames_match);
match_conc_values = zeros(number_matches,64);

for i = 1:64
    for j = 1:number_matches
    match_conc_values(j,i) = Conc_values_sim(id_metNames_exp(1,j),i);
    end
end

for run_number = 1:64
    correlation_coef_matrix_metabolomics = corrcoef(Conc_values_exp_match,match_conc_values(:,run_number));
    correlation_coef_metabolomics = correlation_coef_matrix_metabolomics(2,1);
    comparison_metabolomics(run_number,2) = correlation_coef_metabolomics;
end

comparison_metabolomics_FBA_0 = comparison_metabolomics;

clear results_equilibrator_like 
clear metNames_sim
clear metNames_sim_clean_1
clear metNames_sim_clean_2
clear Conc_values_sim 
clear id_metNames_exp 
clear number_matches 
clear name_matches
clear id_metNames_match
clear Conc_values_exp_match
clear match_conc_values
clear i
clear j

%% MDF with I = 0 M (TFA)
results_equilibrator_like = importdata('TFA_results_0.txt');
metNames_sim = results_equilibrator_like.textdata;
metNames_sim_clean_1 = metNames_sim(:,1);
metNames_sim_clean_2 = metNames_sim_clean_1(2:end);
Conc_values_sim = results_equilibrator_like.data;
id_metNames_exp = find_cell(metNames_exp, metNames_sim_clean_2);
number_matches = size(id_metNames_exp,2);
name_matches = metNames_sim_clean_2(id_metNames_exp);
id_metNames_match = find_cell(name_matches, metNames_exp);
Conc_values_exp_match = Conc_values_exp(id_metNames_match);
match_conc_values = zeros(number_matches,64);

for i = 1:64
    for j = 1:number_matches
    match_conc_values(j,i) = Conc_values_sim(id_metNames_exp(1,j),i);
    end
end

for run_number = 1:64
    correlation_coef_matrix_metabolomics = corrcoef(Conc_values_exp_match,match_conc_values(:,run_number));
    correlation_coef_metabolomics = correlation_coef_matrix_metabolomics(2,1);
    comparison_metabolomics(run_number,2) = correlation_coef_metabolomics;
end

comparison_metabolomics_TFA_0 = comparison_metabolomics;

clear results_equilibrator_like 
clear metNames_sim
clear metNames_sim_clean_1
clear metNames_sim_clean_2
clear Conc_values_sim 
clear id_metNames_exp 
clear number_matches 
clear name_matches
clear id_metNames_match
clear Conc_values_exp_match
clear match_conc_values
clear i
clear j
%% MDF with I = 0.25 M (FBA)
results_equilibrator_like = importdata('FBA_results_250.txt');
metNames_sim = results_equilibrator_like.textdata;
metNames_sim_clean_1 = metNames_sim(:,1);
metNames_sim_clean_2 = metNames_sim_clean_1(2:end);
Conc_values_sim = results_equilibrator_like.data;
id_metNames_exp = find_cell(metNames_exp, metNames_sim_clean_2);
number_matches = size(id_metNames_exp,2);
name_matches = metNames_sim_clean_2(id_metNames_exp);
id_metNames_match = find_cell(name_matches, metNames_exp);
Conc_values_exp_match = Conc_values_exp(id_metNames_match);
match_conc_values = zeros(number_matches,64);

for i = 1:64
    for j = 1:number_matches
    match_conc_values(j,i) = Conc_values_sim(id_metNames_exp(1,j),i);
    end
end

for run_number = 1:64
    correlation_coef_matrix_metabolomics = corrcoef(Conc_values_exp_match,match_conc_values(:,run_number));
    correlation_coef_metabolomics = correlation_coef_matrix_metabolomics(2,1);
    comparison_metabolomics(run_number,2) = correlation_coef_metabolomics;
end

comparison_metabolomics_FBA_025 = comparison_metabolomics;

clear results_equilibrator_like 
clear metNames_sim
clear metNames_sim_clean_1
clear metNames_sim_clean_2
clear Conc_values_sim 
clear id_metNames_exp 
clear number_matches 
clear name_matches
clear id_metNames_match
clear Conc_values_exp_match
clear match_conc_values
clear i
clear j
%% MDF with I = 0.25 M (TFA)
results_equilibrator_like = importdata('TFA_results_250.txt');
metNames_sim = results_equilibrator_like.textdata;
metNames_sim_clean_1 = metNames_sim(:,1);
metNames_sim_clean_2 = metNames_sim_clean_1(2:end);
Conc_values_sim = results_equilibrator_like.data;
id_metNames_exp = find_cell(metNames_exp, metNames_sim_clean_2);
number_matches = size(id_metNames_exp,2);
name_matches = metNames_sim_clean_2(id_metNames_exp);
id_metNames_match = find_cell(name_matches, metNames_exp);
Conc_values_exp_match = Conc_values_exp(id_metNames_match);
match_conc_values = zeros(number_matches,64);

for i = 1:64
    for j = 1:number_matches
    match_conc_values(j,i) = Conc_values_sim(id_metNames_exp(1,j),i);
    end
end

for run_number = 1:64
    correlation_coef_matrix_metabolomics = corrcoef(Conc_values_exp_match,match_conc_values(:,run_number));
    correlation_coef_metabolomics = correlation_coef_matrix_metabolomics(2,1);
    comparison_metabolomics(run_number,2) = correlation_coef_metabolomics;
end

comparison_metabolomics_TFA_025 = comparison_metabolomics;

clear results_equilibrator_like 
clear metNames_sim
clear metNames_sim_clean_1
clear metNames_sim_clean_2
clear Conc_values_sim 
clear id_metNames_exp 
clear number_matches 
clear name_matches
clear id_metNames_match
clear Conc_values_exp_match
clear match_conc_values
clear i
clear j