function W = KendallCoef(X)
% Compute the Kendall's coefficient of concordance of the matrix X.
% E.g. KenCoef = KendallCoef(RankMatrix)
%
% Input:
%           X must be a N-by-K matrix, N is the number of
%           "candidate" and the K is the number of "judge"
% Outputs:
%           W = Kendall's coefficient of concordance
%
% Edited by Lijie Huang, 2010/6/5

% Modified by Claudio Tomi-Andrino, May 2019
    % the original script did not account for ties: here MATLAB's function
    % 'tiedrank' has been used instead of the 'for loop'
%==========================================================================
[N,K] = size(X);
RankMatrix = zeros(N,K);
% for i = 1:K
%     temp = X(:,i);
%     [a,b] = sortrows(temp);
%     RankMatrix(b,i) = 1:N
% end
RankMatrix = tiedrank(X); % added line
ranksum = sum(RankMatrix,2);
S1 = sum(ranksum.^2,1);
S2 = (sum(ranksum))^2;
S = S1 - S2/N;
temp = N^3 - N;
W = 12*S/(K^2*temp);
end

% Copyright (c) 2010, Seal Huang
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
% 
%     * Redistributions of source code must retain the above copyright
%       notice, this list of conditions and the following disclaimer.
%     * Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in
%       the documentation and/or other materials provided with the distribution
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
